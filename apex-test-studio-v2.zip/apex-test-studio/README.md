# APEX Test Studio

Test **any Oracle APEX application** as **every user role**: register the app, add a test user per role, and each test runs
once per user - sign in automatically, run, record a video, sign out, next user in a clean browser.
Excel test cases, the visual test builder, the video wall and run history all keep working.
**All data lives in PostgreSQL**; passwords never do (see *Passwords* below).

## Setup (once)
    cd backend
    pip install -r requirements.txt            # openpyxl, playwright, psycopg, cryptography
    playwright install chromium                 # only if Google Chrome is not installed
    copy .env.example .env                      # then paste your PostgreSQL URL into DATABASE_URL
The first start creates/upgrades the tables automatically (`ats_*`). Works with Neon, Supabase or any PostgreSQL.
Existing tests, workbooks and runs are kept.

## Run
1. `cd backend && python server.py`  ->  open http://localhost:8000
2. **Applications** -> your Timesheet app is registered automatically. Click **Manage**:
   - **Edit settings**: Base URL, home page, Authentication = *Automatic login*.
   - **Add test user** for each role (e.g. `TEST_EMP` / EMPLOYEE, `TEST_MGR` / MANAGER, `TEST_ADMIN` / ADMIN), then **Test login**.
3. **Studio** -> drop the Excel file and/or build tests, tick the users under **Run as**, click **Run N tests × M users**.

No Chrome with `--remote-debugging-port` is needed any more. (It still works: set Authentication to *Logged-in Chrome (legacy)*.)

Preview without APEX: `DEMO=1 python server.py` (PowerShell: `$env:DEMO="1"; python server.py`).

## 1. Application Manager
- Name, Base URL, environment, **authentication** (*Automatic login* / *No login* / *Logged-in Chrome (legacy)*), home page.
- Works with friendly URLs (`…/ords/r/<workspace>/<app>`) and classic URLs (`…/ords/f?p=100`). Paste any page URL - the session is stripped
  and the page becomes the home page. Pages are referred to by alias (`timesheet`) or number (`4`).
- **Login form settings** (optional): only for non-standard login pages - login page, username / password / sign-in / *Next* (two-step forms)
  selectors, a "signed-in" selector or URL, sign-out URL. Left empty, the standard APEX login page is detected (`P9999_USERNAME` / `P9999_PASSWORD`).
- **Test suites**: in Studio select tests (+ users) and **Save selection**; open a suite from the chips or from the app page.

## 2. Test users and passwords
Each user has username, role, display name, notes, active switch, and a **credential reference** - never the password:
- **Encrypted secret store**: type the password once. It is encrypted (Fernet: AES + HMAC) and only the ciphertext is stored
  (`ats_secrets`). The key is `ATS_SECRET_KEY` in `backend/.env`, or `backend/.ats_secret_key` (created on first use, owner-only,
  git-ignored). Back this key up - without it saved passwords must be typed again.
- **Environment variable**: the user points to e.g. `ATS_PW_MANAGER`; put `ATS_PW_MANAGER=…` in `backend/.env` or your CI secret store.

The API only accepts passwords; it never returns them. The runner reads a password at the moment it signs in and refuses to type
it into anything that is not a password field (so it can't appear in a video).

## 3-4. Automatic login and user-wise execution (`runner.py`)
For every selected user:
`new isolated browser context -> open the app -> fill the login form -> verify (left the login page, APEX session, APP_USER is the user,
optional signed-in check) -> run the tests that apply to this user (one page + video each) -> save results -> sign out -> check the old
session no longer opens the app -> close the context`. Then the next user starts with no cookies or storage.
A failed login is recorded with its screenshot/video and only that user's tests are marked *Not run*.

**Runs as**: a test can be limited to roles or users (builder: *Runs as*; Excel: optional `RUN_AS` column, e.g. `MANAGER, ADMIN`).
Blank = every user.

## 5. Test Studio
- Visual builder as before, plus:
  - **Check (assertion)** steps you can edit: *what* (page text, element text, field value, APEX item, URL, title, count, message, visible,
    hidden, enabled, disabled, editable, read-only) + *operator* (equals, contains, matches, >, ≥, <, ≤, empty…) + expected value.
  - **Reusable functions**: named step sequences with parameters (`{{hours}}`), used in any test with the *Use function* step.
  - **Set APEX item**, **Wait for text**; variables `{{username}}`, `{{role}}`, `{{today}}`, `{{today+3}}`.
  - **Write the steps for me**: describe the test in plain English -> structured steps you review before using. Tick *Read the page
    first* to sign in and read the page's real items/buttons so the steps use the right ids. Uses Claude when `ANTHROPIC_API_KEY` is set,
    otherwise an offline rule parser. *Show page elements* lists fields, buttons and pages - click one to add a step.
- Checks for **any APEX app**: *Page opens without errors*, *Role-based page access* (allowed roles get in, others must be blocked),
  *Page needs a login* (fresh browser without a session), *Item cannot be changed from the URL* (Session State Protection).
- The 12 Timesheet checks are unchanged.

## 6. Results dashboard
- **Run view**: sign-in strip per user, login failures, security findings, regressions, and results **by user / by role / by test case /
  matrix** (users × tests). Every cell opens the video and screenshot.
- **Dashboard tab**: the newest runs grouped by **application, user, role or test case** (pass rate, login failures, findings,
  regressions, last status), plus lists of findings, login failures and regressions with their evidence, the trend and run history.
- HTML report and CSV include user, role, login results and findings.

## Excel (unchanged, with optional new columns)
`Test_Cases` sheet: `TEST_CASE_ID, TEST_NAME, TEST_KEY, TEST_DATA (25;30;99 = samples), EXPECTED_RESULT, ENABLED, …` - `Samples` and
`Config` sheets as before. Optional: `PAGE_ALIAS`, `RUN_AS`, `ALLOWED_ROLES` (PAGE_ACCESS), `ITEM` (URL_TAMPERING), `EXPECTED_TEXT`,
and `STEPS` - plain-English steps, one per line or separated by `|`, e.g.
`open timesheet | type 25 into Hours | click "Save" | expect "Hours cannot be more than 24" | P4_TOTAL should be 40`
(a row with `STEPS` and no `TEST_KEY` becomes a custom-steps test).

## Command line (optional)
`APEX_BASE=… APEX_USER=… APEX_PASSWORD=… python runner.py` runs `timesheet_automated_test_cases.xlsx` with automatic login
(without `APEX_USER` it uses the logged-in Chrome as before).

## Storage notes
Videos are stored as bytea and streamed in 1 MB pieces with HTTP Range, so seeking works. Only the newest `KEEP_RUNS` runs are kept
(default 8). Runs with several users store one video per user per test - lower `KEEP_RUNS` if the database fills up.

## Security
`.env` (database URL, secret key, env passwords) and `.ats_secret_key` are git-ignored; never share or commit them.
Use dedicated **test** accounts, not real people's accounts. Use the **pooled** connection string from Neon.

## Frontend (only if you edit the React code)
    cd frontend && npm install && npm run build        # dev: npm run dev (backend must be running on :8000)

## Adding a new test type
Write the function in `backend/runner.py` (`def test_x(page, case)`, return `("PASS", "detail")`, raise to fail, `finding(...)` for a
security finding), add its key to the `TESTS` dict, use that key in the TEST_KEY column.
