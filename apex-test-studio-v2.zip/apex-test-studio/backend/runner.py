"""APEX test runner - logs in to ANY Oracle APEX application as each configured test user and records one video per test.

How a run works (user-wise execution):
    for each test user:
        new isolated browser context  ->  automatic login (APEX login page, or any username/password form)
        -> verify the user is really signed in  ->  run the test cases that apply to this user (one page + video each)
        -> save every result  ->  sign out and check the old session no longer works  ->  close the context
    then the next user starts from a clean context (no cookies, no storage, no APEX session).

Authentication types (per application):
    apex_login      automatic login with each test user's credentials (default)
    chrome_session  legacy: copy the session from a Chrome you logged in to by hand (--remote-debugging-port=9222)
    none            public application, no login

Works with friendly URLs (https://host/ords/r/<workspace>/<app>) and classic URLs (https://host/ords/f?p=<app id>).
Pages are referred to by alias ("timesheet") or number ("4").

Command line (legacy, still supported):
    APEX_BASE=https://oracleapex.com/ords/r/abhi13_workspace/timesheet-app
    APEX_USER=... APEX_PASSWORD=...     automatic login     (otherwise the logged-in Chrome on port 9222 is used)
    ALLOW_SAVE=1  ONLY=TC-001,TC-005  SLOW_MO=60  HEADLESS=1
    python runner.py

Excel (Test_Cases sheet, one row per test; Samples and Config sheets are optional):
    TEST_CASE_ID, TEST_NAME, TEST_KEY, TEST_DATA (25;30;99 = three samples), EXPECTED_RESULT, ENABLED ...
    optional: PAGE_ALIAS (page alias or number), RUN_AS (roles or usernames, comma separated - blank = every user),
              ALLOWED_ROLES (for PAGE_ACCESS), ITEM (for URL_TAMPERING), EXPECTED_TEXT,
              STEPS (plain-English steps, one per line, e.g.  open timesheet | click "Save" | expect "Saved")
"""
import os, re, csv, html, shutil, time, sys, math, base64
from pathlib import Path
from datetime import datetime, date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlsplit, urlunsplit
import openpyxl
from playwright.sync_api import sync_playwright, expect

BASE = os.environ.get("APEX_BASE", "").rstrip("/")
CDP_URL = os.environ.get("CDP_URL", "http://127.0.0.1:9222")
ALLOW_SAVE = os.environ.get("ALLOW_SAVE", "").strip().lower() in ("1", "y", "yes", "true")
HEADLESS = os.environ.get("HEADLESS", "").strip().lower() in ("1", "y", "yes", "true")
ONLY = {x.strip().upper() for x in os.environ.get("ONLY", "").split(",") if x.strip()}
EXCEL_FILE = Path(__file__).resolve().parent / "timesheet_automated_test_cases.xlsx"
OUT = Path(__file__).resolve().parent / "test_reports" / datetime.now().strftime("%Y%m%d_%H%M%S")
VIDEO_DIR = OUT / "videos"
RESULTS = []
CONFIG = {}
SESSION = ""
ON_EVENT = lambda kind, payload: None   # set by the web backend to stream progress
APP = {}                                # application settings: auth_type, login_config, home_page
USER = {}                               # the test user currently running (never holds the password)
FINDINGS = []                           # security findings of the test that is running
FUNCTIONS = {}                          # reusable step sequences: lower(name) -> {name, params, steps}
VIEWPORT = {"width": 1366, "height": 850}

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MODAL = "#ts-modal-backdrop.open"
WEEK_MIN_EDITABLE, WEEK_MAX_EDITABLE = -2, 0      # from the grid SQL: offset > 0 or < -2 is read-only

CHROME_USER = {"key": "chrome", "username": "Logged-in Chrome", "display_name": "Your Chrome session", "role": ""}
ANON_USER = {"key": "anon", "username": "anonymous", "display_name": "No login (public)", "role": ""}


class Skip(Exception):
    """Raised by a test when it cannot run (missing precondition / feature switched off)."""


# ----------------------------------------------------------------------------- generic helpers
def settle(page, timeout=1500):
    try:
        page.wait_for_load_state("networkidle", timeout=timeout)
    except Exception:
        pass


# ----------------------------------------------------------------------------- APEX URLs (friendly and f?p)
def normalize_base(url):
    """https://h/ords/r/ws/app/page?session=1  ->  https://h/ords/r/ws/app ;  https://h/ords/f?p=100:1:123  ->  https://h/ords/f?p=100"""
    url = (url or "").strip()
    if "f?p=" in url:
        root, fp = url.split("f?p=", 1)
        return root + "f?p=" + fp.split("&")[0].split(":")[0]
    u = urlsplit(url)
    path = u.path.rstrip("/")
    m = re.match(r"^(.*?/r/[^/]+/[^/]+)(?:/.*)?$", path)
    if m:
        path = m.group(1)
    return urlunsplit((u.scheme, u.netloc, path, "", ""))


def is_legacy():
    return "f?p=" in BASE


def ords_root():
    """https://h/ords/  (where apex_authentication.logout lives)"""
    if is_legacy():
        return BASE.split("f?p=", 1)[0]
    u = urlsplit(BASE)
    path = re.split(r"/r/[^/]+/[^/]+$", u.path)[0]
    return urlunsplit((u.scheme, u.netloc, path.rstrip("/") + "/", "", ""))


def _pairs(extra):
    out = []
    for part in str(extra or "").split("&"):
        if "=" in part:
            k, v = part.split("=", 1)
            out.append((k.strip(), v.strip()))
    return out


def app_url(page_ref="", extra="", session=True):
    """URL of an APEX page. page_ref = alias ('timesheet'), number ('4') or a full URL; extra = 'P4_X=1&P4_Y=2'."""
    ref = str(page_ref or "").strip()
    if ref.lower().startswith(("http://", "https://")):
        return ref
    sess = SESSION if session is True else (session or "")
    if is_legacy():
        root, app = BASE.split("f?p=", 1)
        url = f"{root}f?p={app}:{ref}:{sess}"
        pairs = _pairs(extra)
        if pairs:
            url += "::NO::" + ",".join(k.upper() for k, _ in pairs) + ":" + ",".join(
                (f"\\{v}\\" if "," in v else v) for _, v in pairs)
        return url
    url = BASE + ("/" + ref.lstrip("/") if ref else "")
    q = ["session=" + sess] if sess else []
    for k, v in _pairs(extra):                 # APEX writes item names in lower case in friendly URLs
        q.append((k.lower() if ITEM_NAME.match(k) else k) + "=" + v)
    return url + ("?" + "&".join(q) if q else "")


ITEM_NAME = re.compile(r"^P\d+_\w+$", re.I)


def is_login_url(url):
    u = (url or "").lower()
    return bool(re.search(r"/login(?:[/?#]|$)|/login_desktop|:9999:|f\?p=[^:&]+:9999|/sign-?in(?:[/?#]|$)", u))


def is_login_page(page):
    try:
        if page.locator("input[type=password]:visible").count():
            return True
    except Exception:
        pass
    return is_login_url(page.url)


def page_state(page):
    """APEX ids of the page that is open (empty strings on non-APEX pages)."""
    try:
        return page.evaluate("""() => { const g = id => { const e = document.getElementById(id); return e ? (e.value || '') : '' };
            let u = ''; try { u = (window.apex && apex.env && apex.env.APP_USER) || ''; } catch (e) {}
            return { app: g('pFlowId'), page: g('pFlowStepId'), session: g('pInstance'), user: u, title: document.title } }""")
    except Exception:
        return {"app": "", "page": "", "session": "", "user": "", "title": ""}


def page_text(page, limit=20000):
    try:
        return page.locator("body").inner_text(timeout=3000)[:limit]
    except Exception:
        return ""


def goto(page, alias="timesheet", extra=""):
    response = page.goto(app_url(alias, extra), wait_until="load", timeout=90000)
    settle(page)
    assert response is None or response.status < 400, f"HTTP {response.status} for {alias or 'home page'}"
    assert not is_login_page(page), "Redirected to the login page - the APEX session is not valid (expired or signed out)"
    return response


def finding(severity, title, detail=""):
    """Record a security finding for the test that is running (shown in the results dashboard)."""
    FINDINGS.append(dict(severity=severity, title=str(title)[:200], detail=str(detail)[:500],
                         username=USER.get("username"), role=USER.get("role")))


def assert_no_db_error(page):
    m = re.search(r"ORA-\d{5}[^<]{0,150}", page.content())
    if m:
        finding("medium", "Database error shown to the user", m.group(0))
    assert not m, f"Database error on page: {m.group(0)}"


def page_alert_text(page):
    """Text of any visible APEX notification / error box."""
    loc = page.locator(".t-Alert--danger:visible, .t-Alert--warning:visible, #t_Alert_Notification:visible, "
                       ".apex-page-error:visible, .t-Body-alert:visible")
    out = []
    for i in range(min(loc.count(), 5)):
        try:
            out.append(loc.nth(i).inner_text().strip().replace("\n", " "))
        except Exception:
            pass
    return " | ".join(t for t in out if t)


def split_samples(value):
    if value is None:
        return [None]
    text = str(value).strip()
    if text == "":
        return [None]
    parts = [p.strip() for p in text.split(";") if p.strip() != ""]
    return parts or [None]


def to_int(value, default=0):
    try:
        if value is None or str(value).strip() == "":
            return default
        return int(float(str(value).strip()))
    except Exception:
        return default


def parse_date(text):
    text = str(text).strip()
    for fmt in ("%d-%b-%Y", "%d-%B-%Y", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    if isinstance(text, str) and re.match(r"\d{4}-\d{2}-\d{2} ", text):
        return datetime.strptime(text[:10], "%Y-%m-%d").date()
    raise ValueError(f"Cannot read date '{text}' (use DD-Mon-YYYY, e.g. 02-Oct-2026)")


def monday_of(d):
    return d - timedelta(days=d.weekday())


def week_offset_for(d):
    return (monday_of(d) - monday_of(date.today())).days // 7


def fmt_hours(x):
    x = Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return format(x.normalize(), "f")


# ----------------------------------------------------------------------------- timesheet page helpers
def current_offset(page):
    try:
        return to_int(page.evaluate("() => $v('P4_WEEK_OFFSET')"), 0)
    except Exception:
        return 0


def wait_grid(page):
    page.wait_for_selector("input.timesheet-cell, .holiday-cell, .leave-cell", timeout=20000, state="attached")
    settle(page, 800)
    page.evaluate("() => { if (window.tsInitCells) tsInitCells(); }")


def open_week(page, offset=0):
    """Open the Timesheet page on the given week offset (0 = this week, -1 = last week ...)."""
    goto(page, "timesheet")
    wait_grid(page)
    cur = current_offset(page)
    guard = 0
    while cur != offset and guard < abs(offset - cur) + 4 and guard < 12:
        guard += 1
        label = "Last Week" if offset < cur else "Next Week"
        before = cur
        page.get_by_text(label, exact=True).first.click()
        page.wait_for_load_state("load")
        settle(page)
        wait_grid(page)
        cur = current_offset(page)
        if cur == before:
            break  # switcher did not move relative to the current week; use the JS fallback below
    if cur != offset:
        # Fallback: set the (hidden) item and refresh the report region, which submits P4_WEEK_OFFSET.
        page.evaluate("(o) => { apex.item('P4_WEEK_OFFSET').setValue(o);"
                      " apex.region('timesheet-log-matrix').refresh(); }", offset)
        settle(page)
        wait_grid(page)
        cur = current_offset(page)
    assert cur == offset, f"Could not navigate to week offset {offset} (page is on {cur})"
    return week_dates(page, offset)


def week_dates(page, offset=None):
    """Monday..Sunday dates of the displayed week (read from the date header row)."""
    texts = page.locator(".date-column").all_inner_texts()
    dates = []
    for t in texts:
        t = t.strip()
        if re.match(r"\d{2}-[A-Za-z]{3}-\d{4}$", t):
            dates.append(datetime.strptime(t, "%d-%b-%Y").date())
    if len(dates) >= 7:
        return dates[:7]
    base = monday_of(date.today()) + timedelta(days=7 * (offset or 0))
    return [base + timedelta(days=i) for i in range(7)]


def project_rows(page):
    """Rows that belong to a real project (have a project name)."""
    return page.locator("tr:has(.project-row-name)")


def add_first_project_if_needed(page, project=None):
    """Make sure at least one project row exists. Uses the 'Search or add a project...' box."""
    if project is None and project_rows(page).count():
        return
    names = page.locator("#project-list option").evaluate_all("els => els.map(e => e.value)")
    if project:
        match = [n for n in names if n.strip().lower() == project.strip().lower()]
        if not match and project_rows(page).filter(has_text=project).count():
            return
        assert match, f"Project '{project}' is not selectable for this employee. Selectable: {names[:10]}"
        choice = match[0]
    else:
        assert names, "No active assigned project is available for this employee"
        choice = names[0]
    box = page.locator(".project-select").first
    box.click()
    box.fill(choice)
    box.press("Enter")
    box.evaluate("el => { el.dispatchEvent(new Event('change', {bubbles:true})); el.blur(); }")
    settle(page)
    wait_grid(page)
    assert project_rows(page).count(), "Project row did not appear after choosing a project"


def cell(page, row_idx, day_idx):
    return project_rows(page).nth(row_idx).locator(f"input.timesheet-cell[name='f0{day_idx + 1}']")


def is_locked(c):
    return c.count() == 0 or c.get_attribute("data-locked") == "1" or not c.is_visible()


def cell_value(c):
    return (c.input_value() or "").strip()


def cell_is_free(page, row_idx, day_idx):
    """Editable, empty (0) and with no pending status."""
    c = cell(page, row_idx, day_idx)
    if is_locked(c):
        return False
    if cell_value(c) not in ("", "0", "0.0"):
        return False
    td = c.locator("xpath=ancestor::td[1]")
    return td.locator(".pending-status").count() == 0


def find_cell(page, free=True, days=(0, 1, 2, 3, 4, 5, 6), skip=()):
    """First (row, day) that is editable (and free). Weekdays are tried before weekend."""
    for r in range(project_rows(page).count()):
        for d in days:
            if (r, d) in skip:
                continue
            c = cell(page, r, d)
            if free:
                if cell_is_free(page, r, d):
                    return r, d
            elif not is_locked(c):
                return r, d
    return None


def open_modal(page, c):
    c.scroll_into_view_if_needed()
    c.click()
    page.wait_for_selector(MODAL, timeout=5000)


def modal_text(page):
    return page.locator("#ts-modal-error").inner_text().strip()


def close_modal(page):
    if page.locator(MODAL).count():
        try:
            page.locator("#ts-modal-backdrop .ts-btn-cancel").click(timeout=2000)
        except Exception:
            page.keyboard.press("Escape")


def apply_hours(page, c, value, desc="Automated test"):
    """Open the popup for a cell, type the hours and press Apply. Returns the popup error text ('' if accepted)."""
    open_modal(page, c)
    page.locator("#ts-modal-hours").fill(str(value))
    page.locator("#ts-modal-desc").fill(desc)
    page.locator("#ts-modal-backdrop .ts-btn-ok").click()
    page.wait_for_timeout(250)
    if page.locator(MODAL).count():
        return modal_text(page)
    return ""


def click_save(page):
    page.locator("#save-changes").click()
    page.wait_for_load_state("load")
    settle(page)
    wait_grid(page)


def require_save_allowed():
    if not ALLOW_SAVE:
        raise Skip("This test clicks the main Save button. Set $env:ALLOW_SAVE = \"1\" (test employee only) to run it.")


def cleanup_cells(page, offset, targets):
    """Reset cells to 0 and save. targets = [(row_idx, day_idx)]. Returns a short status text."""
    try:
        open_week(page, offset)
        for r, d in targets:
            c = cell(page, r, d)
            if cell_value(c) in ("", "0"):
                continue
            open_modal(page, c)
            page.locator("#ts-modal-backdrop .ts-btn-delete").click()
        click_save(page)
        left = [(r, d) for r, d in targets if cell_value(cell(page, r, d)) not in ("", "0")]
        return "cleanup OK" if not left else f"CLEANUP INCOMPLETE - remove manually: {left}"
    except Exception as exc:
        return "CLEANUP FAILED - remove test hours manually (" + str(exc).splitlines()[0][:120] + ")"


def grid_snapshot(page):
    rows = []
    for i in range(project_rows(page).count()):
        r = project_rows(page).nth(i)
        name = r.locator(".project-row-name span").first.inner_text().strip()
        vals = r.locator("input.timesheet-cell").evaluate_all("els => els.map(e => e.value)")
        rows.append((name, tuple(vals)))
    return rows


# ----------------------------------------------------------------------------- the tests
def test_hours_above_24(page, case):
    """TC-001: >24 hours is rejected in the popup (main Save is never clicked)."""
    value = case.get("TEST_DATA") or "25"
    open_week(page, to_int(case.get("WEEK_OFFSET")))
    add_first_project_if_needed(page)
    pos = find_cell(page, free=False)
    assert pos, "No editable cell found in this week"
    c = cell(page, *pos)
    before = cell_value(c)
    err = apply_hours(page, c, value, "Automated validation test: hours above 24")
    try:
        assert re.search(r"more than 24|max 24|24 hours", err, re.I), f"Expected a 24-hour validation message for '{value}', got: '{err or 'no message'}'"
        assert page.locator(MODAL).count(), "Popup closed - the invalid value was accepted"
        assert cell_value(c) == before, f"Cell value changed from {before} to {cell_value(c)}"
    finally:
        close_modal(page)
    return "PASS", f"'{value}' rejected with message: {err}. Main Save not clicked."


def test_negative_hours(page, case):
    """TC-002: negative (or otherwise non-numeric) hours are rejected."""
    value = case.get("TEST_DATA") or "-1"
    open_week(page, to_int(case.get("WEEK_OFFSET")))
    add_first_project_if_needed(page)
    pos = find_cell(page, free=False)
    assert pos, "No editable cell found in this week"
    c = cell(page, *pos)
    before = cell_value(c)
    err = apply_hours(page, c, value, "Automated validation test: negative hours")
    try:
        assert err, f"No validation message appeared for '{value}'"
        assert page.locator(MODAL).count(), "Popup closed - the invalid value was accepted"
        assert cell_value(c) == before, f"Cell value changed from {before} to {cell_value(c)}"
    finally:
        close_modal(page)
    return "PASS", f"'{value}' rejected with message: {err}"


def _assert_locked_and_not_editable(page, c, label):
    assert c.count() > 0, f"{label}: no input cell exists (treated as read-only)"
    assert c.get_attribute("data-locked") == "1", f"{label} is EDITABLE (cell is not locked)"
    c.scroll_into_view_if_needed()
    c.click()
    page.wait_for_selector(MODAL, timeout=5000)
    assert page.locator("#ts-modal-hours").get_attribute("readonly") is not None, f"{label}: popup hours box is editable"
    assert not page.locator("#ts-modal-backdrop .ts-btn-ok").is_visible(), f"{label}: Apply button is visible on a locked cell"
    close_modal(page)


def test_future_date_readonly(page, case):
    """TC-003: a date after today is read-only. DATE_OFFSET_DAYS = 1 means tomorrow."""
    target = date.today() + timedelta(days=to_int(case.get("DATE_OFFSET_DAYS"), 1))
    if target <= date.today():
        raise Skip("DATE_OFFSET_DAYS must be a positive number for a future-date test")
    dates = open_week(page, week_offset_for(target))
    add_first_project_if_needed(page)
    day = dates.index(target)
    c = cell(page, 0, day)
    _assert_locked_and_not_editable(page, c, f"{DAYS[day]} {target:%d-%b-%Y} (future)")
    return "PASS", f"{DAYS[day]} {target:%d-%b-%Y} is read-only; popup opens view-only (no Apply button)"


def test_old_week_readonly(page, case):
    """TC-004: weeks older than 2 weeks back (offset < -2) are view-only. Editable window = offsets 0, -1, -2."""
    off = to_int(case.get("WEEK_OFFSET"), -3)
    if off >= WEEK_MIN_EDITABLE:
        raise Skip(f"WEEK_OFFSET {off} is inside the editable window ({WEEK_MIN_EDITABLE}..0). Use -3 or older.")
    open_week(page, off)
    add_first_project_if_needed(page)
    n = project_rows(page).count()
    unlocked = []
    for r in range(n):
        for d in range(7):
            c = cell(page, r, d)
            if c.count() and c.get_attribute("data-locked") != "1":
                unlocked.append((r, DAYS[d]))
    assert not unlocked, f"Week {off} has editable cells: {unlocked[:6]}"
    c = cell(page, 0, 0)
    _assert_locked_and_not_editable(page, c, f"Week {off} Monday")
    return "PASS", f"All cells in week offset {off} are read-only ({n} project row(s) checked)"


def test_old_week_boundary_editable(page, case):
    """Boundary control: the oldest allowed week (offset -2) must still be editable."""
    off = to_int(case.get("WEEK_OFFSET"), WEEK_MIN_EDITABLE)
    open_week(page, off)
    add_first_project_if_needed(page)
    pos = find_cell(page, free=False)
    assert pos, f"Week {off} should be editable but every cell is locked (holiday/leave could also cause this)"
    return "PASS", f"Week offset {off} has an editable cell ({DAYS[pos[1]]})"


def test_weekend_readonly(page, case):
    """TC-005 / TC-006: Saturday / Sunday cell is read-only."""
    day_name = str(case.get("DAY") or "").strip().title()[:3]
    if day_name not in ("Sat", "Sun"):
        m = re.search(r"saturday|sunday", str(case.get("TEST_NAME", "")), re.I)
        day_name = m.group(0).title()[:3] if m else ""
    if day_name not in ("Sat", "Sun"):
        raise Skip("Add DAY = Sat or Sun in the Excel row")
    off = to_int(case.get("WEEK_OFFSET"), 0)
    note = ""
    d_idx = DAYS.index(day_name)
    if off == 0 and monday_of(date.today()) + timedelta(days=d_idx) > date.today():
        off = -1   # this week's weekend is in the future (locked for that reason) - use last week so the test is meaningful
        note = " (used last week because this weekend is still in the future)"
    dates = open_week(page, off)
    add_first_project_if_needed(page)
    if page.locator(".holiday-cell, .leave-cell").count() and not cell(page, 0, d_idx).count():
        raise Skip(f"{day_name} {dates[d_idx]:%d-%b-%Y} is a holiday/leave day - choose another WEEK_OFFSET")
    c = cell(page, 0, d_idx)
    _assert_locked_and_not_editable(page, c, f"{day_name} {dates[d_idx]:%d-%b-%Y}")
    return "PASS", f"{day_name} {dates[d_idx]:%d-%b-%Y} is read-only{note}"


def _save_one_entry(page, case, hours, label):
    require_save_allowed()
    off = to_int(case.get("WEEK_OFFSET"), 0)
    open_week(page, off)
    add_first_project_if_needed(page, CONFIG.get("SAVE_PROJECT") or None)
    pos = find_cell(page, free=True, days=(0, 1, 2, 3, 4))
    if not pos:
        # this week may have no free working day yet (e.g. Monday) - try last week
        off = off - 1 if off - 1 >= WEEK_MIN_EDITABLE else off
        open_week(page, off)
        add_first_project_if_needed(page, CONFIG.get("SAVE_PROJECT") or None)
        pos = find_cell(page, free=True, days=(0, 1, 2, 3, 4))
    assert pos, "No free editable weekday cell available for a test entry"
    c = cell(page, *pos)
    err = apply_hours(page, c, hours, f"Automated test - {label}")
    assert not err, f"Popup rejected {hours} hours: {err}"
    click_save(page)
    assert_no_db_error(page)
    alert = page_alert_text(page)
    c2 = cell(page, *pos)
    saved = cell_value(c2)
    pending = c2.locator("xpath=ancestor::td[1]").locator(".pending-status").count() > 0
    return off, pos, saved, pending, alert


def test_overtime_requires_approval(page, case):
    """TC-007: more than 8 hours -> saved entry shows PENDING."""
    hours = case.get("TEST_DATA") or "9"
    off = pos = None
    try:
        off, pos, saved, pending, alert = _save_one_entry(page, case, hours, "overtime")
        assert float(saved or 0) == float(hours), f"Saved value is '{saved}', expected {hours}. {alert}"
        assert pending, "No 'Pending' status shown next to the saved overtime hours"
        result = ("PASS", f"{hours}h saved and shown as Pending. (APPROVAL_REQUIRED=Y is not visible in the UI - confirm in the table if needed.)")
    finally:
        if pos is not None:
            msg = cleanup_cells(page, off, [pos])
    return result[0], result[1] + " " + msg


def test_normal_hours_approved(page, case):
    """TC-008: 8 hours or less is saved and is NOT pending (auto-approved)."""
    hours = case.get("TEST_DATA") or "8"
    off = pos = None
    try:
        off, pos, saved, pending, alert = _save_one_entry(page, case, hours, "normal hours")
        assert float(saved or 0) == float(hours), f"Saved value is '{saved}', expected {hours}. {alert}"
        assert not pending, "Normal hours are showing as Pending"
        result = ("PASS", f"{hours}h saved with no Pending flag (treated as approved).")
    finally:
        if pos is not None:
            msg = cleanup_cells(page, off, [pos])
    return result[0], result[1] + " " + msg


def test_assigned_active_projects_only(page, case):
    """TC-009: project drop-down lists only active projects assigned to the employee (needs Config values)."""
    open_week(page, 0)
    options = page.locator("#project-list option").evaluate_all("els => els.map(e => e.value.trim())")
    shown = [project_rows(page).nth(i).locator(".project-row-name span").first.inner_text().strip()
             for i in range(project_rows(page).count())]
    available = {x.lower() for x in options + shown}
    allowed = [x.strip() for x in re.split(r"[,|]", CONFIG.get("ALLOWED_PROJECTS", "")) if x.strip()]
    denied = [x.strip() for x in re.split(r"[,|]", CONFIG.get("DENIED_PROJECTS", "")) if x.strip()]
    if case.get("TEST_DATA"):
        denied.append(str(case["TEST_DATA"]).strip())
    if not allowed and not denied:
        raise Skip("Fill ALLOWED_PROJECTS / DENIED_PROJECTS in the Config sheet. Currently selectable: "
                   + ", ".join(sorted(set(options + shown))) or "(none)")
    missing = [p for p in allowed if p.lower() not in available]
    leaked = [p for p in denied if p.lower() in available]
    assert not missing, f"Assigned active project(s) missing from the list: {missing}"
    assert not leaked, f"Unassigned/inactive project(s) are selectable: {leaked}"
    return "PASS", f"{len(allowed)} allowed project(s) present, {len(denied)} blocked project(s) absent"


def test_cross_employee_access_denied(page, case):
    """TC-010: tampering with employee-related URL parameters never shows/changes another employee's data."""
    other = str(case.get("TEST_DATA") or CONFIG.get("OTHER_EMPLOYEE_ID") or "1").strip()
    open_week(page, 0)
    baseline = grid_snapshot(page)
    tried = []
    for param in ("P4_USER_ID", "P4_EMPLOYEE_ID", "P4_EMP_ID", "P4_EMAIL"):
        goto(page, "timesheet", f"{param}={other}&P4_WEEK_OFFSET=0")
        assert_no_db_error(page)
        text = page.content().lower()
        blocked = ("checksum" in text or "session state protection" in text or "not authorized" in text
                   or "access denied" in text or "unauthorized" in text)
        if not blocked:
            wait_grid(page)
            if grid_snapshot(page) != baseline:
                finding("high", "Another employee's timesheet is reachable by changing the URL",
                        f"{param}={other} changed the data shown to {USER.get('username') or 'this user'}")
            assert grid_snapshot(page) == baseline, f"Grid data changed when {param}={other} was supplied!"
        tried.append(param + (" (blocked)" if blocked else " (ignored)"))
    return "PASS", ("Own data unchanged after tampering: " + ", ".join(tried) +
                    ". A full test needs a 2nd login for another employee; this checks URL tampering only.")


def test_weekly_limit(page, case):
    """TC-011: a weekly total above the limit is rejected on Save."""
    require_save_allowed()
    total = Decimal(str(case.get("TEST_DATA") or "49"))
    per_day_max = Decimal("12")
    needed = int(math.ceil(total / per_day_max))
    off = to_int(case.get("WEEK_OFFSET"), 0)
    slots = []
    for candidate in dict.fromkeys([off, -1, -2]):
        if candidate < WEEK_MIN_EDITABLE:
            continue
        open_week(page, candidate)
        add_first_project_if_needed(page, CONFIG.get("SAVE_PROJECT") or None)
        slots = []
        for d in (0, 1, 2, 3, 4, 5, 6):
            if cell_is_free(page, 0, d):
                slots.append((0, d))
        if len(slots) >= needed:
            off = candidate
            break
    if len(slots) < needed:
        raise Skip(f"Need {needed} free editable days in one week to enter {total}h; found {len(slots)}")
    slots = slots[:needed]
    amounts, remaining = [], total
    for i in range(needed):
        left = needed - i
        a = (remaining / left).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        a = remaining if left == 1 else a
        amounts.append(a)
        remaining -= a
    result = None
    try:
        for (r, d), a in zip(slots, amounts):
            err = apply_hours(page, cell(page, r, d), fmt_hours(a), "Automated weekly limit test")
            assert not err, f"Popup rejected {a}h on {DAYS[d]} before Save: {err}"
        click_save(page)
        alert = page_alert_text(page)
        saved_total = Decimal(str(page.locator(".weekly-total").first.inner_text().strip() or "0"))
        saved_any = saved_total >= total
        assert not saved_any, f"Weekly total {saved_total} (>= {total}) was SAVED - no weekly limit enforced"
        result = ("PASS", f"{total}h over {needed} day(s) was not saved (week total {saved_total}). App message: {alert or 'none shown'}")
    finally:
        msg = cleanup_cells(page, off, slots)
    return result[0], result[1] + " " + msg


def test_holiday_readonly(page, case):
    """TC-012: a holiday shows HOLIDAY and cannot be edited. TEST_DATA = holiday date, or blank to auto-detect."""
    wanted = case.get("TEST_DATA")
    if wanted:
        d = parse_date(wanted)
        off = week_offset_for(d)
        if off < WEEK_MIN_EDITABLE or off > WEEK_MAX_EDITABLE or d > date.today():
            raise Skip(f"{d:%d-%b-%Y} is outside the editable window (past 3 weeks, not future); the holiday rule cannot be isolated there")
        dates = open_week(page, off)
        add_first_project_if_needed(page)
        idx = dates.index(d)
        found = [(off, idx)]
    else:
        found = []
        for off in (0, -1, -2):
            dates = open_week(page, off)
            add_first_project_if_needed(page)
            row = project_rows(page).first
            classes = row.locator(".ts-day-column").evaluate_all("els => els.map(e => e.className)")
            for j, cls in enumerate(classes[:7]):
                if "holiday-cell" in cls:
                    found.append((off, j))
            if found:
                break
        if not found:
            raise Skip("No holiday found in the last 3 weeks. Put a date from XXEA_HOLIDAYS in TEST_DATA (DD-Mon-YYYY, inside the past 3 weeks).")
        off = found[0][0]
        dates = week_dates(page, off)
    for off, idx in found[:1]:
        row = project_rows(page).first
        holiday_cells = row.locator(".holiday-cell")
        assert holiday_cells.count() >= 1, f"{dates[idx]:%d-%b-%Y} is not marked HOLIDAY on the grid"
        assert "HOLIDAY" in holiday_cells.first.inner_text().upper(), "Holiday cell has no HOLIDAY label"
        visible_inputs = holiday_cells.first.locator("input.timesheet-cell:visible")
        assert visible_inputs.count() == 0, "An editable input is visible inside the holiday cell"
    return "PASS", f"{dates[found[0][1]]:%d-%b-%Y} shows HOLIDAY and has no editable input"



# ----------------------------------------------------------------------------- generic checks (work with any APEX app)
DENIED_RX = re.compile(r"not authori[sz]ed|access denied|insufficient privilege|authori[sz]ation scheme|you are not allowed|"
                       r"permission denied|page is not available|forbidden|ORA-20987|do not have (?:access|permission)", re.I)


def _page_ref(case, required=True):
    ref = str(case.get("PAGE_ALIAS") or case.get("PAGE") or "").strip()
    if not ref and required:
        raise Skip("Set the page (alias or number) for this check.")
    return ref


def _who():
    u = USER or {}
    return (u.get("display_name") or u.get("username") or "this user") + (f" ({u['role']})" if u.get("role") else "")


def _open_raw(page, ref, extra="", session=True):
    resp = page.goto(app_url(ref, extra, session), wait_until="load", timeout=90000)
    settle(page, 3000)
    return resp


def access_outcome(page, resp, ref):
    """('allowed' | 'denied' | 'login' | 'error', why) for the page that was just opened."""
    status = resp.status if resp else 200
    if is_login_page(page):
        return "login", "redirected to the login page"
    if status in (401, 403):
        return "denied", f"HTTP {status}"
    m = DENIED_RX.search(page_text(page))
    if m:
        return "denied", f"the page says '{m.group(0)}'"
    if status >= 400:
        return "error", f"HTTP {status}"
    st = page_state(page)
    if ref.isdigit() and st["page"] and st["page"] != ref:
        return "denied", f"redirected to page {st['page']}"
    if ref and not ref.isdigit() and not is_legacy():
        path = urlsplit(page.url).path.lower().rstrip("/")
        if not path.endswith("/" + ref.lower()):
            return "denied", f"redirected to '{path.rsplit('/', 1)[-1] or 'another page'}'"
    return "allowed", f"'{st.get('title') or ref or 'home'}' opened"


def _messages(page):
    """Text of visible APEX messages (success and error)."""
    loc = page.locator("#t_Alert_Success:visible, .t-Alert--success:visible, #APEX_SUCCESS_MESSAGE:visible, "
                       "#APEX_ERROR_MESSAGE:visible, .a-Notification:visible, .t-Alert--danger:visible, "
                       ".t-Alert--warning:visible, #t_Alert_Notification:visible, .apex-page-error:visible")
    out = []
    for i in range(min(loc.count(), 6)):
        try:
            out.append(loc.nth(i).inner_text().strip().replace("\n", " "))
        except Exception:
            pass
    return " | ".join(t for t in out if t)


def test_page_smoke(page, case):
    """Any app: the page opens for this user - no error, no login redirect, no database error; optional text is shown."""
    ref = _page_ref(case, required=False)
    errors = []
    page.on("pageerror", lambda e: errors.append((str(e).splitlines() or [""])[0][:160]))
    t0 = time.time()
    goto(page, ref)
    assert_no_db_error(page)
    outcome, why = access_outcome(page, None, ref)
    assert outcome == "allowed", f"{_who()} could not open '{ref or 'home'}': {why}"
    want = str(case.get("EXPECTED_TEXT") or "").strip()
    if want:
        try:
            expect(page.get_by_text(want).first).to_be_visible(timeout=8000)
        except AssertionError:
            raise AssertionError(f"'{want}' is not shown on '{ref or 'home'}'")
    msg = f"{why} in {int((time.time() - t0) * 1000)} ms"
    if want:
        msg += f"; '{want}' is visible"
    if errors:
        msg += f"; {len(errors)} JavaScript error(s), first: {errors[0]}"
    return "PASS", msg


def _allowed_list(case):
    raw = case.get("ALLOWED_ROLES")
    if raw is None or str(raw).strip() == "":
        raw = case.get("TEST_DATA")
    return [x.strip() for x in re.split(r"[,;|]", str(raw or "")) if x.strip()]


def test_page_access(page, case):
    """Any app, role-based: users whose role is allowed must open the page; everyone else must be blocked.
    A blocked role that gets in is a security finding."""
    ref = _page_ref(case)
    allowed = _allowed_list(case)
    if not allowed:
        raise Skip("List the roles (or usernames) allowed to open this page, e.g. MANAGER, ADMIN - or * for everyone.")
    me = {str(USER.get("role") or "").lower(), str(USER.get("username") or "").lower()} - {""}
    low = {a.lower() for a in allowed}
    expect_ok = bool({"*", "all", "everyone"} & low) or bool(me & low)
    resp = _open_raw(page, ref)
    outcome, why = access_outcome(page, resp, ref)
    if outcome == "error":
        raise AssertionError(f"Page '{ref}' failed to load: {why}")
    if outcome == "login" and USER.get("key") not in ("anon",):
        raise AssertionError(f"Session lost while opening '{ref}' ({why}) - cannot judge access")
    if expect_ok:
        assert outcome == "allowed", f"{_who()} should be able to open '{ref}' but was blocked ({why})"
        assert_no_db_error(page)
        return "PASS", f"{_who()} can open '{ref}' as expected"
    if outcome == "allowed":
        finding("high", f"Role '{USER.get('role') or USER.get('username')}' can open restricted page '{ref}'",
                f"Only {', '.join(allowed)} should have access. {why}.")
        raise AssertionError(f"SECURITY: {_who()} opened '{ref}' - only {', '.join(allowed)} should have access")
    return "PASS", f"{_who()} is blocked from '{ref}' as expected ({why})"


def test_requires_login(page, case):
    """Any app: a visitor with no session (fresh browser, no cookies) is sent to the login page."""
    ref = _page_ref(case, required=False)
    url = app_url(ref, session=False)
    anon = page.context.browser.new_context(viewport=VIEWPORT)
    try:
        p2 = anon.new_page()
        resp = p2.goto(url, wait_until="load", timeout=90000)
        settle(p2, 3000)
        outcome, why = access_outcome(p2, resp, ref)
        st = page_state(p2)
        shot = base64.b64encode(p2.screenshot(timeout=10000)).decode()
    finally:
        anon.close()
    # show what the anonymous visitor saw in this test's own video / screenshot
    page.set_content(f"<body style='margin:0;font:14px sans-serif;background:#0b0e14;color:#e7eaf1'>"
                     f"<div style='padding:10px 14px'>Anonymous visitor (no cookies) opened {html.escape(url)}</div>"
                     f"<img style='width:100%' src='data:image/png;base64,{shot}'></body>")
    page.wait_for_timeout(1200)
    if outcome in ("login", "denied"):
        return "PASS", f"Without signing in, '{ref or 'home'}' is protected ({why})"
    if (st.get("user") or "").lower() not in ("", "nobody"):
        finding("critical", f"Page '{ref or 'home'}' opens as user {st['user']} without signing in", url)
    else:
        finding("high", f"Page '{ref or 'home'}' is reachable without signing in", f"{url} - {why}")
    raise AssertionError(f"SECURITY: '{ref or 'home'}' opened without a login ({why}). "
                         "If the page is meant to be public, remove this check.")


def test_url_tampering(page, case):
    """Any app: an item value supplied in the URL must be rejected (Session State Protection) or ignored."""
    ref = _page_ref(case)
    item = str(case.get("ITEM") or "").strip().upper()
    if not ITEM_NAME.match(item):
        raise Skip("Set the APEX item to tamper with, e.g. P4_EMPLOYEE_ID.")
    value = str(case.get("TEST_DATA") if case.get("TEST_DATA") is not None else "1").strip() or "1"
    goto(page, ref)
    before = page.evaluate("n => (window.apex && apex.item(n)) ? String(apex.item(n).getValue() ?? '') : ''", item)
    resp = _open_raw(page, ref, f"{item}={value}")
    text = page_text(page).lower()
    if ("checksum" in text or "session state protection" in text or DENIED_RX.search(text)
            or (resp is not None and resp.status in (400, 401, 403))):
        return "PASS", f"{item}={value} in the URL was rejected by APEX (Session State Protection)"
    if is_login_page(page):
        return "PASS", f"{item}={value} in the URL ended the session (redirected to login)"
    now = page.evaluate("n => (window.apex && apex.item(n)) ? String(apex.item(n).getValue() ?? '') : ''", item)
    if now == value and before != value:
        finding("high", f"{item} can be set from the URL on page '{ref}'",
                f"{item} changed from '{before}' to '{value}' for {_who()} - enable Session State Protection on the item")
        raise AssertionError(f"SECURITY: {item} accepted '{value}' from the URL (was '{before}')")
    assert_no_db_error(page)
    return "PASS", f"{item}={value} in the URL was ignored (value stays '{now}')"


# ----------------------------------------------------------------------------- custom (no-code) tests built in the web UI
STEP_LABELS = {
    "open": "Open page", "open_week": "Go to week", "click": "Click", "type": "Type into field",
    "choose": "Choose option", "press": "Press key", "wait": "Wait", "wait_for": "Wait for text",
    "set_item": "Set APEX item", "see": "Expect to see text", "not_see": "Expect NOT to see text",
    "url": "Expect URL to contain", "assert": "Check", "call": "Use function",
}
ASSERT_SUBJECTS = {
    "text": "Page text", "element_text": "Text of element", "value": "Value of field", "item": "APEX item",
    "url": "Page URL", "title": "Page title", "count": "Number of elements", "alert": "Message shown",
    "visible": "Element is visible", "hidden": "Element is hidden", "enabled": "Element is enabled",
    "disabled": "Element is disabled", "editable": "Field is editable", "readonly": "Field is read-only",
}
STATE_SUBJECTS = ("visible", "hidden", "enabled", "disabled", "editable", "readonly")
ASSERT_OPS = {
    "equals": "equals", "not_equals": "does not equal", "contains": "contains", "not_contains": "does not contain",
    "starts_with": "starts with", "matches": "matches", "gt": "is greater than", "ge": "is at least",
    "lt": "is less than", "le": "is at most", "empty": "is empty", "not_empty": "is not empty",
}


class StepFailed(AssertionError):
    """A step failed; the message already says which one."""


def _find(page, candidates, what, timeout=8000):
    """Return the first candidate locator that exists on the page, polling until timeout."""
    waited = 0
    while True:
        for loc in candidates:
            try:
                if loc.count() > 0:
                    return loc.first
            except Exception:
                pass
        if waited >= timeout:
            raise AssertionError(f"could not find {what} on the page")
        page.wait_for_timeout(250)
        waited += 250


def _is_css(t):
    return t.lower().startswith("css=") or bool(re.match(r"^[#.\[]", t)) or ">" in t


def _css(t):
    return t[4:] if t.lower().startswith("css=") else t


def _click_target(page, t):
    if _is_css(t):
        return _find(page, [page.locator(_css(t))], f"'{t}'")
    return _find(page, [page.get_by_role("button", name=t), page.get_by_role("link", name=t),
                        page.get_by_text(t, exact=True), page.get_by_text(t)], f"a button, link or text '{t}'")


def _field_target(page, t):
    if _is_css(t):
        return _find(page, [page.locator(_css(t))], f"field '{t}'")
    cands = [page.get_by_label(t), page.get_by_placeholder(t), page.locator(f"[name='{t}']")]
    if re.fullmatch(r"[A-Za-z][\w-]*", t):
        cands.append(page.locator(f"#{t}"))
    return _find(page, cands, f"field '{t}'")


def _locate_now(page, t):
    """Element for a target without waiting (None if it is not on the page)."""
    if _is_css(t):
        cands = [page.locator(_css(t))]
    else:
        cands = [page.get_by_label(t), page.get_by_role("button", name=t), page.get_by_role("link", name=t),
                 page.get_by_placeholder(t)]
        if re.fullmatch(r"[A-Za-z][\w-]*", t):
            cands.append(page.locator(f"#{t}"))
        cands += [page.get_by_text(t, exact=True), page.get_by_text(t)]
    for loc in cands:
        try:
            if loc.count() > 0:
                return loc.first
        except Exception:
            pass
    return None


def _num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        raise AssertionError(f"'{v}' is not a number")


def compare(actual, op, expected):
    a = str(actual if actual is not None else "").strip()
    e = str(expected if expected is not None else "").strip()
    if op == "equals":
        return a == e or (re.fullmatch(r"-?[\d.,]+", a or "x") and re.fullmatch(r"-?[\d.,]+", e or "x") and _num(a) == _num(e))
    if op == "not_equals":
        return not compare(a, "equals", e)
    if op == "contains":
        return e.lower() in a.lower()
    if op == "not_contains":
        return e.lower() not in a.lower()
    if op == "starts_with":
        return a.lower().startswith(e.lower())
    if op == "matches":
        return re.search(e, a) is not None
    if op in ("gt", "ge", "lt", "le"):
        x, y = _num(a), _num(e)
        return {"gt": x > y, "ge": x >= y, "lt": x < y, "le": x <= y}[op]
    if op == "empty":
        return a == ""
    if op == "not_empty":
        return a != ""
    raise AssertionError(f"unknown comparison '{op}'")


def _actual(page, subject, target):
    if subject == "text":
        return page_text(page)
    if subject == "url":
        return page.url
    if subject == "title":
        return page.title()
    if subject == "alert":
        return _messages(page)
    if subject == "item":
        return page.evaluate("n => (window.apex && apex.item(n) && apex.item(n).node) ? String(apex.item(n).getValue() ?? '')"
                             " : ((document.getElementById(n) || {}).value ?? null)", target)
    if subject == "count":
        return (page.locator(_css(target)) if _is_css(target) else page.get_by_text(target)).count()
    if subject == "element_text":
        el = _locate_now(page, target)
        return el.inner_text().strip() if el else None
    if subject == "value":
        el = _locate_now(page, target)
        return el.input_value() if el else None
    raise AssertionError(f"unknown check '{subject}'")


def _state(page, subject, target):
    el = _locate_now(page, target)
    if subject == "hidden":
        return el is None or not el.is_visible()
    if el is None:
        return False
    return {"visible": el.is_visible, "enabled": el.is_enabled, "disabled": el.is_disabled, "editable": el.is_editable,
            "readonly": lambda: not el.is_editable()}[subject]()


def check_assertion(page, step, timeout=6000):
    """Editable assertion: subject (what to read) + operator + expected value. Retries until it holds or times out."""
    subject = step.get("subject") or "text"
    target = str(step.get("target") or "").strip()
    expected = str(step.get("value") or "").strip()
    op = step.get("op") or ("contains" if subject in ("text", "alert", "url", "title", "element_text") else "equals")
    if subject == "text" and not expected:
        expected = target
    deadline = time.time() + timeout / 1000
    actual, err = None, ""
    while True:
        try:
            if subject in STATE_SUBJECTS:
                if _state(page, subject, target):
                    return
            else:
                actual = _actual(page, subject, target)
                if actual is not None and compare(actual, op, expected):
                    return
        except AssertionError as exc:
            err = str(exc)
        except Exception as exc:
            err = (str(exc).splitlines() or [""])[0][:160]
        if time.time() > deadline:
            break
        page.wait_for_timeout(250)
    if subject in STATE_SUBJECTS:
        raise AssertionError(f"'{target}' is not {subject}" + (" (not found on the page)" if _locate_now(page, target) is None else ""))
    if subject == "text":
        raise AssertionError(f"the page {'does not show' if op != 'not_contains' else 'still shows'} '{expected}'")
    shown = "(not found)" if actual is None else repr(str(actual)[:120])
    what = ASSERT_SUBJECTS.get(subject, subject) + (f" '{target}'" if target else "")
    raise AssertionError(f"{what} {ASSERT_OPS.get(op, op)} '{expected}' - actual {shown}" + (f" ({err})" if err else ""))


VAR_RX = re.compile(r"\{\{\s*([\w.]+)\s*([+-]\s*\d+)?\s*\}\}")


def _subst(text, vars_):
    """{{username}}, {{role}}, {{today}}, {{today+3}}, {{now}}, {{random}} and function parameters."""
    def rep(m):
        name, delta = m.group(1).lower(), m.group(2)
        if name in ("today", "date"):
            return (date.today() + timedelta(days=int(delta.replace(" ", "")) if delta else 0)).strftime("%d-%b-%Y")
        if name == "now":
            return datetime.now().strftime("%d-%b-%Y %H:%M")
        if name == "random":
            return str(int(time.time() * 1000) % 1000000)
        if name in vars_:
            return str(vars_[name])
        return m.group(0)
    return VAR_RX.sub(rep, str(text if text is not None else ""))


def parse_args(text):
    """'hours=25; day=Mon'  ->  {'hours': '25', 'day': 'Mon'}"""
    out = {}
    for part in re.split(r"[;\n&]", str(text or "")):
        if "=" in part:
            k, v = part.split("=", 1)
            if k.strip():
                out[k.strip().lower()] = v.strip()
    return out


def run_step(page, step):
    act = str(step.get("action") or "").strip()
    target = str(step.get("target") or "").strip()
    value = str(step.get("value") or "").strip()
    if act == "open":
        if target.lower().startswith("http"):
            page.goto(target, wait_until="load", timeout=90000)
            settle(page)
        else:
            goto(page, target)                      # empty target = the application's home page
    elif act == "open_week":
        open_week(page, to_int(value or target, 0))
    elif act == "click":
        _click_target(page, target).click()
        settle(page, 4000)
    elif act == "type":
        _field_target(page, target).fill(value)
    elif act == "choose":
        _field_target(page, target).select_option(label=value)
    elif act == "set_item":
        if not page.evaluate("n => !!(window.apex && apex.item(n) && apex.item(n).node)", target):
            raise AssertionError(f"APEX item {target} is not on this page")
        page.evaluate("([n, v]) => apex.item(n).setValue(v)", [target, value])
    elif act == "press":
        page.keyboard.press(value or target or "Enter")
        settle(page, 4000)
    elif act == "wait":
        page.wait_for_timeout(int(float(value or target or "1") * 1000))
    elif act == "wait_for":
        try:
            expect(page.get_by_text(target).first).to_be_visible(timeout=int(float(value or "15") * 1000))
        except AssertionError:
            raise AssertionError(f"'{target}' did not appear within {value or '15'} s")
    elif act == "see":
        try:
            expect(page.get_by_text(target).first).to_be_visible(timeout=8000)
        except AssertionError:
            raise AssertionError(f"the text '{target}' was not visible on the page")
    elif act == "not_see":
        try:
            expect(page.get_by_text(target)).to_have_count(0, timeout=6000)
        except AssertionError:
            raise AssertionError(f"the text '{target}' is still visible on the page")
    elif act == "url":
        needle = value or target
        assert needle in page.url, f"URL is {page.url}"
    elif act == "assert":
        check_assertion(page, step)
    else:
        raise AssertionError(f"unknown action '{act}'")


def run_steps(page, steps, vars_, depth=0, path="", fn_name=""):
    """Run steps in order; 'call' expands a reusable function with its parameters."""
    for i, raw in enumerate(steps or [], 1):
        label = f"{path}{i}"
        act = str(raw.get("action") or "").strip()
        step = {k: (_subst(v, vars_) if isinstance(v, str) else v) for k, v in raw.items()}
        where = f" in function '{fn_name}'" if fn_name else ""
        if act == "call":
            name = str(step.get("target") or "").strip()
            fn = FUNCTIONS.get(name.lower())
            if not fn:
                raise StepFailed(f"Step {label}{where}: there is no function called '{name}'")
            if depth >= 5:
                raise StepFailed(f"Step {label}{where}: functions call each other more than 5 levels deep")
            args = parse_args(step.get("value"))
            v2 = dict(vars_)
            for prm in fn.get("params") or []:
                pname = str(prm.get("name") if isinstance(prm, dict) else prm).strip().lower()
                if pname:
                    v2[pname] = args.get(pname, (prm.get("default") if isinstance(prm, dict) else "") or "")
            v2.update(args)
            run_steps(page, fn.get("steps") or [], v2, depth + 1, f"{label}.", fn.get("name") or name)
            continue
        try:
            run_step(page, step)
        except StepFailed:
            raise
        except Exception as exc:
            first = (str(exc).strip().splitlines() or [repr(exc)])[0][:260]
            raise StepFailed(f"Step {label} ({STEP_LABELS.get(act, act)}){where} failed: {first}")


def count_steps(steps, depth=0):
    n = 0
    for st in steps or []:
        fn = FUNCTIONS.get(str(st.get("target") or "").lower()) if st.get("action") == "call" else None
        n += count_steps(fn.get("steps"), depth + 1) if fn and depth < 5 else 1
    return n


def test_custom_steps(page, case):
    """A test built in the web UI (or written as plain-English STEPS in Excel): runs the steps in order,
    stops at the first failing step."""
    if case.get("_PARSE_ERROR"):
        raise AssertionError(case["_PARSE_ERROR"])
    steps = case.get("STEPS") or []
    if not steps:
        raise Skip("This test has no steps yet. Edit it and add at least one step.")
    u = USER or {}
    vars_ = {"username": u.get("username") or "", "user": u.get("username") or "", "role": u.get("role") or "",
             "display_name": u.get("display_name") or u.get("username") or "",
             "data": "" if case.get("TEST_DATA") is None else str(case.get("TEST_DATA"))}
    run_steps(page, steps, vars_)
    assert_no_db_error(page)
    n = count_steps(steps)
    return "PASS", f"All {n} step{'s' if n != 1 else ''} passed"


# ----------------------------------------------------------------------------- plain English -> structured steps
def _unq(s):
    s = str(s).strip().rstrip(".").strip()
    m = re.fullmatch(r"""["“'‘](.*)["”'’]""", s)
    return m.group(1) if m else s


_KEYS = r"enter|tab|escape|esc|backspace|delete|space|arrow ?(?:up|down|left|right)|page ?(?:up|down)|home|end|f\d{1,2}|(?:control|ctrl|alt|shift|meta)\+\w+"
_SEE = r"(?:expect|verify|check|assert|confirm|make sure|ensure)"


def _parse_clause(c, functions=()):
    c = re.sub(r"^\s*(?:\d+[.)]|[-*•])\s*", "", c).strip().rstrip(".").strip()
    c = re.sub(r"^(?:then|and|next|finally|first)\s+", "", c, flags=re.I)
    if not c:
        return None
    low = c.lower()
    m = re.match(r"^(?:go to|open|switch to|show)\s+(?:the\s+)?(last|this|next|previous)\s+week$", low)
    if m:
        return {"action": "open_week", "target": "", "value": {"last": "-1", "previous": "-1", "this": "0", "next": "1"}[m[1]]}
    m = re.match(r"^(?:go to|open|switch to)\s+week\s+([+-]?\d+)$", low)
    if m:
        return {"action": "open_week", "target": "", "value": m[1]}
    m = re.match(r"^(?:use|call|run)\s+(?:the\s+)?function\s+(.+?)(?:\s+with\s+(.+))?$", c, re.I) or (
        re.match(r"^(?:use|call|run)\s+(.+?)(?:\s+with\s+(.+))?$", c, re.I) if functions else None)
    if m and (re.match(r"^(?:use|call|run)\s+(?:the\s+)?function", c, re.I) or _unq(m[1]).lower() in functions):
        args = "; ".join(a.strip() for a in re.split(r",|\band\b", m[2] or "") if "=" in a)
        return {"action": "call", "target": _unq(m[1]), "value": args}
    m = re.match(r"^(?:open|go to|goto|navigate to|visit|load|start (?:at|on))\s+(?:the\s+)?(?:page\s+)?(.+?)(?:\s+page)?$", c, re.I)
    if m:
        t = _unq(m[1])
        return {"action": "open", "target": "" if t.lower() in ("home", "home page", "the app", "app", "application") else t, "value": ""}
    m = re.match(rf"^(?:press|hit)\s+(?:the\s+)?({_KEYS})(?:\s+key)?$", c, re.I)
    if m:
        k = m[1].strip()
        return {"action": "press", "target": "", "value": {"esc": "Escape"}.get(k.lower(), k[:1].upper() + k[1:])}
    m = re.match(r"^wait\s+(?:for\s+)?(\d+(?:\.\d+)?)\s*(?:s|secs?|seconds?)?$", low)
    if m:
        return {"action": "wait", "target": "", "value": m[1]}
    m = re.match(r"^wait\s+(?:for|until)\s+(.+?)(?:\s+(?:appears|is shown|is visible|to appear))?$", c, re.I)
    if m:
        return {"action": "wait_for", "target": _unq(m[1]), "value": "15"}
    m = re.match(r"^(?:type|enter|fill(?: in)?|input|put|write)\s+(.+?)\s+(?:in|into|in the|into the)\s+(?:the\s+)?(.+?)(?:\s+(?:field|box|item|input))?$", c, re.I)
    if m:
        return {"action": "type", "target": _unq(m[2]), "value": _unq(m[1])}
    m = re.match(r"^(?:set|change|fill)\s+(?:the\s+)?(.+?)(?:\s+(?:field|item))?\s+(?:to|=|with)\s+(.+)$", c, re.I)
    if m:
        return {"action": "type", "target": _unq(m[1]), "value": _unq(m[2])}
    m = re.match(r"^(?:select|choose|pick)\s+(.+?)\s+(?:in|from|for|as)\s+(?:the\s+)?(.+?)(?:\s+(?:list|dropdown|drop-down|field|select list))?$", c, re.I)
    if m:
        return {"action": "choose", "target": _unq(m[2]), "value": _unq(m[1])}
    m = re.match(r"^(?:click|press|tap|hit|push|select)\s+(?:on\s+)?(?:the\s+)?(.+?)(?:\s+(?:button|link|tab|menu item|menu|icon))?$", c, re.I)
    if m:
        return {"action": "click", "target": _unq(m[1]), "value": ""}
    m = re.match(rf"^(?:{_SEE}\s+)?(?:that\s+)?(?:the\s+)?url\s+(?:should\s+)?(?:contains?|includes?|has)\s+(.+)$", c, re.I)
    if m:
        return {"action": "url", "target": "", "value": _unq(m[1])}
    m = re.match(rf"^(?:{_SEE}\s+)?(?:that\s+)?(?:the\s+)?(?:item\s+)?(P\d+_\w+)\s+(?:should\s+)?(?:be|equals?|is|=|==)\s+(.+)$", c, re.I)
    if m:
        return {"action": "assert", "subject": "item", "op": "equals", "target": m[1].upper(), "value": _unq(m[2])}
    m = re.match(rf"^(?:{_SEE}\s+)?(?:that\s+)?(?:i\s+)?(?:should\s+not|do(?:es)?\s+not|don'?t|cannot|can'?t|no longer)\s+see\s+(?:the\s+)?(?:text\s+|message\s+)?(.+)$", c, re.I)
    if m:
        return {"action": "not_see", "target": _unq(m[1]), "value": ""}
    m = re.match(rf"^(?:{_SEE}\s+)?(?:that\s+)?(?:the\s+)?(.+?)\s+(?:field\s+)?(?:should\s+be|is|are)\s+(read[- ]?only|not editable|disabled|enabled|editable|visible|hidden|not visible)$", c, re.I)
    if m:
        st = m[2].lower().replace(" ", "").replace("-", "")
        subj = {"readonly": "readonly", "noteditable": "readonly", "notvisible": "hidden"}.get(st, st)
        return {"action": "assert", "subject": subj, "op": "", "target": _unq(m[1]), "value": ""}
    m = re.match(rf"^(?:{_SEE}|see|should see|i should see|i see)\s+(?:that\s+)?(?:i\s+)?(?:should\s+)?(?:see\s+)?(?:the\s+)?(?:text\s+|message\s+)?([\"“'‘].+[\"”'’])(?:\s+(?:is shown|is displayed|appears|is visible|on the page))?$", c, re.I)
    if m:
        return {"action": "see", "target": _unq(m[1]), "value": ""}
    m = re.match(rf"^{_SEE}\s+(?:that\s+)?(?:the\s+)?(.+?)\s+(?:field\s+|value\s+)?(?:should\s+)?(?:be|equals?|is)\s+(.+)$", c, re.I)
    if m:
        return {"action": "assert", "subject": "value", "op": "equals", "target": _unq(m[1]), "value": _unq(m[2])}
    m = re.match(rf"^(?:{_SEE}|see|should see|i should see|i see)\s+(?:that\s+)?(?:i\s+)?(?:should\s+)?(?:see\s+)?(?:the\s+)?(?:text\s+|message\s+)?(.+?)(?:\s+(?:is shown|is displayed|appears|is visible|on the page))?$", c, re.I)
    if m:
        return {"action": "see", "target": _unq(m[1]), "value": ""}
    return None


def parse_steps_text(text, functions=()):
    """Plain-English test steps -> structured steps. Returns (steps, lines it could not understand).
    One step per line, or separated by '|', ';' or 'then'. Quoted text is kept exactly."""
    functions = {str(f).lower() for f in functions}
    quotes = []
    def protect(m):
        quotes.append(m.group(0))
        return f"\x00{len(quotes) - 1}\x00"
    raw = re.sub(r"""["“][^"”]*["”]|'[^'\n]*'""", protect, str(text or ""))
    verbs = (r"(?:open|go|goto|navigate|visit|load|click|tap|press|hit|push|type|enter|fill|input|put|write|set|change|"
             r"select|choose|pick|wait|expect|verify|check|assert|confirm|make sure|ensure|see|should|use|call|run)\b")
    parts = re.split(r"\n|\s\|\s|\|(?=\s*\w)|;|,?\s+and then\s+|,?\s+then\s+|\.\s+(?=[A-Z])"
                     r"|,\s*(?:and\s+)?(?=" + verbs + r")|\s+and\s+(?=" + verbs + r")", raw, flags=re.I)
    steps, problems = [], []
    for part in parts:
        clause = re.sub(r"\x00(\d+)\x00", lambda m: quotes[int(m.group(1))], part).strip()
        if not clause or not re.search(r"\w", clause):
            continue
        st = _parse_clause(clause, functions)
        if st:
            steps.append(st)
        else:
            problems.append(clause)
    return steps, problems


# Add each Excel TEST_KEY here only after its browser actions and assertions are implemented.
TESTS = {
    "HOURS_ABOVE_24": test_hours_above_24,
    "NEGATIVE_HOURS": test_negative_hours,
    "FUTURE_DATE_READONLY": test_future_date_readonly,
    "OLD_WEEK_READONLY": test_old_week_readonly,
    "OLD_WEEK_BOUNDARY_EDITABLE": test_old_week_boundary_editable,
    "WEEKEND_READONLY": test_weekend_readonly,
    "OVERTIME_REQUIRES_APPROVAL": test_overtime_requires_approval,
    "NORMAL_HOURS_APPROVED": test_normal_hours_approved,
    "ASSIGNED_ACTIVE_PROJECTS_ONLY": test_assigned_active_projects_only,
    "CROSS_EMPLOYEE_ACCESS_DENIED": test_cross_employee_access_denied,
    "WEEKLY_LIMIT": test_weekly_limit,
    "HOLIDAY_READONLY": test_holiday_readonly,
    "CUSTOM_STEPS": test_custom_steps,
    # generic - any APEX application
    "PAGE_SMOKE": test_page_smoke,
    "PAGE_ACCESS": test_page_access,
    "REQUIRES_LOGIN": test_requires_login,
    "URL_TAMPERING": test_url_tampering,
}


# ----------------------------------------------------------------------------- Excel loading (with samples)
def sheet_rows(workbook, name):
    if name not in workbook.sheetnames:
        return []
    sheet = workbook[name]
    headers = [str(c.value).strip() if c.value is not None else "" for c in sheet[1]]
    rows = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        if not any(v is not None and str(v).strip() != "" for v in row):
            continue
        rows.append(dict(zip(headers, row)))
    return rows


def _prepare_case(s):
    """Optional new columns: STEPS (plain English) turns a row into a custom-steps test."""
    raw = s.get("STEPS")
    if isinstance(raw, str) and raw.strip():
        steps, problems = parse_steps_text(raw, FUNCTIONS.keys())
        s["STEPS"] = steps
        if problems:
            s["_PARSE_ERROR"] = "Could not understand the step(s): " + " | ".join(problems[:3])
        if not str(s.get("TEST_KEY") or "").strip():
            s["TEST_KEY"] = "CUSTOM_STEPS"
    return s


def load_cases(path=None):
    path = Path(path) if path else EXCEL_FILE
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")
    wb = openpyxl.load_workbook(path, data_only=True)
    if "Test_Cases" not in wb.sheetnames:
        raise ValueError("Excel workbook must contain a sheet named Test_Cases")
    for r in sheet_rows(wb, "Config"):
        k = str(r.get("KEY") or "").strip().upper()
        if k and r.get("VALUE") is not None:
            CONFIG[k] = str(r["VALUE"]).strip()
    parents = [r for r in sheet_rows(wb, "Test_Cases") if str(r.get("ENABLED", "")).strip().upper() == "Y"]
    extra = {}
    for r in sheet_rows(wb, "Samples"):
        extra.setdefault(str(r.get("TEST_CASE_ID") or "").strip(), []).append(r)
    cases = []
    for parent in parents:
        cid = str(parent.get("TEST_CASE_ID") or "").strip()
        if ONLY and cid.upper() not in ONLY:
            continue
        samples = []
        for v in split_samples(parent.get("TEST_DATA")):          # samples written as "25;30;99"
            s = dict(parent)
            s["TEST_DATA"] = v
            samples.append(s)
        for ex in extra.get(cid, []):                              # samples from the Samples sheet
            if str(ex.get("ENABLED", "Y")).strip().upper() == "N":
                continue
            s = dict(parent)
            for k, v in ex.items():
                if k in ("TEST_CASE_ID", "ENABLED") or v is None or str(v).strip() == "":
                    continue
                s[k] = v
            for v in split_samples(s.get("TEST_DATA")):
                s2 = dict(s)
                s2["TEST_DATA"] = v
                samples.append(s2)
        multi = len(samples) > 1
        for i, s in enumerate(samples, 1):
            s["_SAMPLE_NO"] = i
            s["_CASE_ID"] = f"{cid}-S{i}" if multi else cid
            label = s.get("SAMPLE_NAME") or (f"data={s['TEST_DATA']}" if s.get("TEST_DATA") is not None else f"sample {i}")
            s["_LABEL"] = f"{parent.get('TEST_NAME')} [{label}]" if multi and label else str(parent.get("TEST_NAME") or cid)
            cases.append(_prepare_case(s))
    return cases


# ----------------------------------------------------------------------------- which tests run for which user
def run_as_of(case):
    """(roles, usernames) a case is limited to - both empty means every user."""
    ra = case.get("RUN_AS")
    if isinstance(ra, dict):
        roles = {str(x).strip().lower() for x in ra.get("roles") or [] if str(x).strip()}
        users = {str(x).strip().lower() for x in ra.get("users") or [] if str(x).strip()}
        return roles, users
    toks = set()
    for col in ("RUN_AS", "ROLES", "USERS"):
        toks |= {t.strip().lower() for t in re.split(r"[,;|]", str(case.get(col) or "")) if t.strip()}
    return toks, set(toks)


def applies(case, user):
    roles, users = run_as_of(case)
    if not roles and not users:
        return True
    if user.get("key") in ("chrome", "anon") or {"*", "all", "everyone"} & (roles | users):
        return True          # single-session runs (legacy Chrome / public app) execute everything
    return (str(user.get("role") or "").lower() in roles or str(user.get("username") or "").lower() in users
            or str(user.get("id")) in users)


def describe(c):
    roles, users = run_as_of(c)
    return dict(id=c["_CASE_ID"], name=c["_LABEL"], key=str(c.get("TEST_KEY") or ""),
                expected=str(c.get("EXPECTED_RESULT") or ""), data=c.get("TEST_DATA"),
                page=str(c.get("PAGE_ALIAS") or "") or None, run_as=sorted(roles | users))


# ----------------------------------------------------------------------------- login / logout (any APEX app)
LOGIN_DEFAULTS = dict(login_page="", username_selector="", password_selector="", submit_selector="", next_selector="",
                      success_selector="", success_url="", logout_url="")
USER_FIELDS = ["#P9999_USERNAME", "input[name='P9999_USERNAME']", "input[id$='_USERNAME']:not([type=hidden])",
               "input[autocomplete='username']", "input[type='email']", "input[name='username']", "input[name='loginfmt']",
               "#username", "#sso_username", "input[name='j_username']", "input[name='user']"]
PASS_FIELDS = ["#P9999_PASSWORD", "input[id$='_PASSWORD'][type='password']", "input[type='password']"]
SUBMIT_RX = re.compile(r"^\s*(sign\s*in|log\s*in|login|submit|continue|next|ok)\s*$", re.I)
ERROR_SEL = ("#APEX_ERROR_MESSAGE:visible, .a-Notification--error:visible, .t-Alert--danger:visible, "
             "#t_Alert_Notification:visible, .t-Form-error:visible, .htmldbStdErr:visible, [role=alert]:visible, "
             ".alert-error:visible, .error:visible")


def login_cfg():
    cfg = dict(LOGIN_DEFAULTS)
    cfg.update({k: str(v or "").strip() for k, v in (APP.get("login_config") or {}).items() if k in LOGIN_DEFAULTS})
    return cfg


def _first_visible(page, cands, timeout_ms):
    deadline = time.time() + timeout_ms / 1000
    while True:
        for c in cands:
            try:
                loc = page.locator(c) if isinstance(c, str) else c
                for i in range(min(loc.count(), 4)):
                    el = loc.nth(i)
                    if el.is_visible():
                        return el
            except Exception:
                pass
        if time.time() >= deadline:
            return None
        page.wait_for_timeout(250)


def _login_error(page):
    try:
        loc = page.locator(ERROR_SEL)
        for i in range(min(loc.count(), 4)):
            t = loc.nth(i).inner_text().strip().replace("\n", " ")
            if t:
                return t[:200]
    except Exception:
        pass
    m = re.search(r"invalid login credentials|invalid (?:user ?name|username) or password|incorrect (?:user ?name|username|password)"
                  r"|account (?:is )?locked|password (?:has )?expired", page_text(page, 6000), re.I)
    return m.group(0) if m else ""


def login(page, username, password):
    """Sign in through the application's login form. Returns dict(ok, detail, session, landing_url, app_user)."""
    global SESSION
    cfg = login_cfg()
    t0 = time.time()
    res = dict(ok=False, detail="", session="", landing_url="", app_user="")

    def fail(msg):
        res.update(detail=msg, landing_url=page.url)
        return res

    start = app_url(cfg["login_page"] or APP.get("home_page") or "", session=False)
    resp = page.goto(start, wait_until="load", timeout=90000)
    settle(page, 3000)
    if resp is not None and resp.status >= 500:
        return fail(f"The application answered HTTP {resp.status} at {start}")
    user_el = _first_visible(page, [cfg["username_selector"]] if cfg["username_selector"] else USER_FIELDS, 20000)
    if not user_el:
        st = page_state(page)
        return fail(f"No username field on {page.url} ('{st.get('title') or 'no title'}'). "
                    "Set the login page or the username selector in the application's login settings.")
    user_el.fill("")
    user_el.fill(username)
    pass_sel = [cfg["password_selector"]] if cfg["password_selector"] else PASS_FIELDS
    pw_el = _first_visible(page, pass_sel, 1200)
    submit_cands = ([cfg["submit_selector"]] if cfg["submit_selector"] else
                    [page.get_by_role("button", name=SUBMIT_RX), "button[type=submit]", "input[type=submit]",
                     "#P9999_LOGIN", "button:has-text('Sign In')"])
    if not pw_el:                                      # two-step forms: username -> Next -> password
        nxt = _first_visible(page, [cfg["next_selector"]] if cfg["next_selector"] else submit_cands, 3000)
        if nxt:
            nxt.click()
        else:
            user_el.press("Enter")
        settle(page, 3000)
        pw_el = _first_visible(page, pass_sel, 15000)
        if not pw_el:
            err = _login_error(page)
            return fail("The password field never appeared" + (f": {err}" if err else
                        ". Set the password selector in the login settings."))
    if (pw_el.get_attribute("type") or "").lower() != "password":
        return fail("Refusing to type the password: the password selector does not point to a password field "
                    "(the password would be visible in the video).")
    pw_el.fill(password)
    btn = _first_visible(page, submit_cands, 1500)
    if btn:
        btn.click()
    else:
        pw_el.press("Enter")
    deadline = time.time() + 35
    while True:
        page.wait_for_timeout(300)
        err = _login_error(page)
        try:
            on_form = page.locator("input[type=password]:visible").count() > 0
        except Exception:
            on_form = True
        if err and on_form:
            return fail(f"Login rejected: {err}")
        if not on_form and not is_login_url(page.url):
            break
        if time.time() > deadline:
            return fail("Still on the login page after 35 s" + (f": {err}" if err else " (no message shown)"))
    settle(page, 4000)
    st = page_state(page)
    if (st.get("user") or "").lower() == "nobody":
        return fail("APEX still reports APP_USER = nobody - the login did not create an authenticated session")
    if cfg["success_selector"]:
        if not _first_visible(page, [cfg["success_selector"]], 10000):
            return fail(f"Signed in, but '{cfg['success_selector']}' is not on the landing page {page.url}")
    if cfg["success_url"] and cfg["success_url"] not in page.url:
        return fail(f"Signed in, but the landing page {page.url} does not contain '{cfg['success_url']}'")
    m = re.search(r"[?&]session=(\d+)", page.url) or re.search(r"f\?p=[^:]+:[^:]*:(\d+)", page.url)
    SESSION = st.get("session") or (m.group(1) if m else "")
    app_user = st.get("user") or ""
    detail = f"Signed in as {app_user or username} in {round(time.time() - t0, 1)} s"
    if SESSION:
        detail += f" (APEX session {SESSION})"
    if app_user and app_user.lower() != username.lower() and app_user.lower().split("@")[0] != username.lower().split("@")[0]:
        detail += f" - note: APEX reports APP_USER {app_user}"
    res.update(ok=True, detail=detail, session=SESSION, landing_url=page.url, app_user=app_user)
    return res


def logout(page):
    """Sign out, then check that the old session no longer opens the app. Returns (ok, note, findings)."""
    global SESSION
    cfg = login_cfg()
    old = SESSION
    found = []
    try:
        if cfg["logout_url"]:
            target = app_url(cfg["logout_url"]) if not cfg["logout_url"].lower().startswith("http") else cfg["logout_url"]
        else:
            if not page.url.startswith("http"):
                page.goto(app_url(APP.get("home_page") or ""), wait_until="load", timeout=60000)
                settle(page)
            target = page.evaluate("""() => { const a = [...document.querySelectorAll('a[href]')]
                .find(a => /apex_authentication\\.logout|logout|log_out|sign_?out/i.test(a.getAttribute('href') || ''));
                return a ? a.href : '' }""")
            if not target:
                st = page_state(page)
                target = (f"{ords_root()}apex_authentication.logout?p_app_id={st['app']}&p_session_id={st['session'] or old}"
                          if st.get("app") else "")
        if not target:
            return False, "Sign-out link not found - set the logout URL in the login settings", found
        page.goto(target, wait_until="load", timeout=60000)
        settle(page, 3000)
        if not old:
            return True, "Signed out", found
        page.goto(app_url(APP.get("home_page") or "", session=old), wait_until="load", timeout=60000)
        settle(page, 3000)
        st = page_state(page)
        who = (st.get("user") or "").lower()
        still = (who not in ("", "nobody") and st.get("session") == old) or (
            not who and not is_login_page(page) and st.get("session") == old)
        if still:
            found.append(dict(severity="medium", title="Session still valid after sign-out",
                              detail=f"APEX session {old} still opened the app as {st.get('user') or 'the same user'}",
                              username=USER.get("username"), role=USER.get("role")))
            return False, "Signed out, but the old session still works", found
        return True, "Signed out - the old session no longer opens the app", found
    except Exception as exc:
        return False, "Sign-out could not be confirmed: " + (str(exc).splitlines() or [""])[0][:150], found
    finally:
        SESSION = ""


# ----------------------------------------------------------------------------- runner
def _safe(s):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", str(s)).strip("_")[:120] or "x"


def _close_and_keep_video(page, target):
    """Close the page and move its recording to target. Returns the path relative to OUT ('' if none)."""
    try:
        page.close()
    except Exception:
        pass
    try:
        v = page.video
        if v and target:
            v.save_as(str(target))
            v.delete()
            return str(Path(target).relative_to(OUT))
        if v:
            v.delete()
    except Exception:
        pass
    return ""


def launch_browser(p, headless, slow_mo):
    """Installed Google Chrome when available (BROWSER_CHANNEL, default 'chrome'), otherwise Playwright's Chromium."""
    channel = os.environ.get("BROWSER_CHANNEL", "chrome").strip()
    if channel and channel.lower() not in ("chromium", "bundled"):
        try:
            return p.chromium.launch(channel=channel, headless=headless, slow_mo=int(slow_mo))
        except Exception:
            pass
    return p.chromium.launch(headless=headless, slow_mo=int(slow_mo))


def run_one(ctx, case, user=None):
    """One test case for one user: a new page (own video) inside the user's isolated context."""
    global FINDINGS
    user = user or {}
    ukey = user.get("key", "")
    test_id = case["_CASE_ID"]
    test_name = case["_LABEL"]
    test_key = str(case.get("TEST_KEY") or "").strip().upper()
    expected = str(case.get("EXPECTED_RESULT") or "")
    safe = _safe(f"{ukey}_{test_id}_{test_name}")
    started = time.time()
    FINDINGS = []
    base = dict(test_case_id=test_id, name=test_name, test_key=test_key, expected=expected, data=case.get("TEST_DATA"),
                user_key=ukey, test_user_id=user.get("id"), username=user.get("username"), role=user.get("role"))
    status, detail, video_rel, shot_rel = "SKIP", "No Playwright test implemented for TEST_KEY: " + test_key, "", ""
    ON_EVENT("start", {"case_id": test_id, "user_key": ukey})
    if test_key not in TESTS:
        RESULTS.append(dict(base, status=status, detail=detail, secs=0, video="", shot="", findings=[]))
        print(f"[SKIP] {ukey} {test_id} - {detail}")
        ON_EVENT("done", RESULTS[-1])
        return
    page = None
    try:
        page = ctx.new_page()
        page.set_default_timeout(20000)
        try:
            status, detail = TESTS[test_key](page, case)
        except Skip as s:
            status, detail = "SKIP", str(s)
        except Exception as exc:
            status, detail = "FAIL", (str(exc).strip().splitlines() or [repr(exc)])[0][:500]
        try:
            shot_path = OUT / f"{safe}.png"
            page.screenshot(path=str(shot_path), full_page=True, timeout=10000)
            shot_rel = str(shot_path.relative_to(OUT))
        except Exception:
            pass
    except Exception as exc:
        status, detail = "FAIL", (str(exc).strip().splitlines() or [repr(exc)])[0][:500]
    finally:
        if page is not None:
            video_rel = _close_and_keep_video(page, OUT / f"{safe}.webm")
    elapsed = round(time.time() - started, 1)
    RESULTS.append(dict(base, status=status, detail=detail, secs=elapsed, video=video_rel, shot=shot_rel,
                        findings=list(FINDINGS)))
    print(f"[{status}] {user.get('username') or ''} {test_id} - {test_name} ({elapsed}s) {detail}")
    ON_EVENT("done", RESULTS[-1])


def sign_in(ctx, user, password_for):
    """Login step of a user: own page + video + screenshot. Returns True when the user is authenticated."""
    ukey = user["key"]
    t0 = time.time()
    page = ctx.new_page()
    page.set_default_timeout(20000)
    res = dict(ok=False, detail="", landing_url="")
    try:
        try:
            password = password_for(user)
        except Exception as exc:
            res["detail"] = f"No password available: {exc}"
        else:
            try:
                res = login(page, user["username"], password)
            except Exception as exc:
                res["detail"] = "Login error: " + (str(exc).splitlines() or [repr(exc)])[0][:300]
            finally:
                password = None
        shot = ""
        try:
            sp = OUT / f"login_{_safe(ukey)}.png"
            page.screenshot(path=str(sp), timeout=10000)
            shot = str(sp.relative_to(OUT))
        except Exception:
            pass
    finally:
        video = _close_and_keep_video(page, OUT / f"login_{_safe(ukey)}.webm")
    ev = dict(user_key=ukey, test_user_id=user.get("id"), username=user.get("username"), role=user.get("role"),
              status="OK" if res.get("ok") else "FAIL", detail=res.get("detail"), landing_url=res.get("landing_url"),
              secs=round(time.time() - t0, 1), video=video, shot=shot, findings=[])
    print(f"[LOGIN {ev['status']}] {user.get('username')}: {ev['detail']}")
    ON_EVENT("login", ev)
    return bool(res.get("ok"))


def run_user(browser, user, cases, auth, password_for=None, storage_state=None, chrome_session=""):
    """user -> isolated context -> login -> applicable tests -> results -> logout -> context closed."""
    global USER, SESSION
    USER, SESSION = dict(user), ""
    ukey = user["key"]
    ON_EVENT("user", ukey)
    vdir = VIDEO_DIR / f"user_{_safe(ukey)}"
    vdir.mkdir(parents=True, exist_ok=True)
    ctx = browser.new_context(storage_state=storage_state, viewport=VIEWPORT, record_video_dir=str(vdir),
                              record_video_size=VIEWPORT)
    try:
        if auth == "apex_login":
            if not sign_in(ctx, user, password_for):
                for c in cases:
                    r = dict(test_case_id=c["_CASE_ID"], name=c["_LABEL"], test_key=str(c.get("TEST_KEY") or ""),
                             expected=str(c.get("EXPECTED_RESULT") or ""), data=c.get("TEST_DATA"), user_key=ukey,
                             test_user_id=user.get("id"), username=user.get("username"), role=user.get("role"),
                             status="SKIP", detail=f"Not run - login failed for {user.get('username')}", secs=0,
                             video="", shot="", findings=[])
                    RESULTS.append(r)
                    ON_EVENT("done", r)
                return
        elif auth == "chrome_session":
            SESSION = chrome_session
        for c in cases:
            run_one(ctx, c, user)
        if auth == "apex_login":
            page = ctx.new_page()
            try:
                ok, note, found = logout(page)
            finally:
                _close_and_keep_video(page, None)
            print(f"[LOGOUT] {user.get('username')}: {note}")
            ON_EVENT("logout", dict(user_key=ukey, ok=ok, detail=note, findings=found))
    finally:
        ctx.close()                     # cookies, local storage and the APEX session cookie are gone
        shutil.rmtree(vdir, ignore_errors=True)
        USER, SESSION = {}, ""


def write_report():
    csv_path = OUT / "results.csv"
    fields = ["test_case_id", "username", "role", "name", "test_key", "data", "expected", "status", "detail", "secs", "shot", "video"]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(RESULTS)
    counts = {s: sum(r["status"] == s for r in RESULTS) for s in ("PASS", "FAIL", "SKIP")}
    colors = {"PASS": "#166534", "FAIL": "#b91c1c", "SKIP": "#92400e"}
    rows = []
    for r in RESULTS:
        video = f'<a href="{html.escape(r["video"])}">Watch</a>' if r["video"] else "-"
        shot = f'<a href="{html.escape(r["shot"])}">Screenshot</a>' if r["shot"] else "-"
        rows.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td style='color:{};font-weight:700'>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
            html.escape(r["test_case_id"]), html.escape(str(r.get("username") or "")), html.escape(r["name"]),
            html.escape(str(r["data"] if r["data"] is not None else "")), html.escape(r["expected"]),
            colors.get(r["status"], "#000"), r["status"], html.escape(r["detail"]), shot, video))
    report = f'''<!doctype html><html><head><meta charset="utf-8"><title>APEX Test Results</title>
<style>body{{font-family:Arial,sans-serif;margin:24px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}}th{{background:#164e63;color:white}}tr:nth-child(even){{background:#f5f7f8}}</style></head><body>
<h2>APEX Automated Test Results</h2><p>Run: {datetime.now():%Y-%m-%d %H:%M:%S} | Total: {len(RESULTS)} | PASS: {counts['PASS']} | FAIL: {counts['FAIL']} | SKIP: {counts['SKIP']}</p>
<table><tr><th>ID</th><th>User</th><th>Test case</th><th>Sample data</th><th>Expected</th><th>Status</th><th>Actual / details</th><th>Screenshot</th><th>Video</th></tr>{''.join(rows)}</table></body></html>'''
    (OUT / "report.html").write_text(report, encoding="utf-8")
    print(f"\nPASS {counts['PASS']} | FAIL {counts['FAIL']} | SKIP {counts['SKIP']}")
    print(f"Report: {OUT / 'report.html'}\nCSV: {csv_path}\nEvidence folder: {OUT}")


def select_cases(excel_cases, only, extra_cases):
    """Excel cases filtered by the ids picked in the UI, followed by the UI-built cases."""
    if only is not None:
        wanted = {str(x).strip() for x in only}
        excel_cases = [c for c in excel_cases if c["_CASE_ID"] in wanted]
    return list(excel_cases) + list(extra_cases or [])


def configure(base, app=None, functions=None):
    """Point the module at an application (used by run_job, try_login and inspect)."""
    global BASE, APP, FUNCTIONS, SESSION, USER
    BASE = normalize_base(base).rstrip("/")
    APP = dict(app or {})
    FUNCTIONS = {str(f["name"]).strip().lower(): f for f in (functions or []) if str(f.get("name") or "").strip()}
    SESSION, USER = "", {}


def copy_chrome_session(p):
    """Legacy: borrow the cookies of a Chrome started with --remote-debugging-port=9222 and logged in by hand."""
    try:
        source_browser = p.chromium.connect_over_cdp(CDP_URL)
    except Exception as exc:
        raise RuntimeError(f"Could not connect to Chrome at {CDP_URL}. Start Chrome with --remote-debugging-port=9222 "
                           f"and log in to the app first - or switch the application to automatic login. "
                           f"({str(exc).splitlines()[0][:150]})")
    source_context = source_browser.contexts[0]
    app_part = BASE.split("/ords/")[-1].split("/")[0]
    session = ""
    for tab in source_context.pages:
        m = re.search(r"[?&]session=(\d+)", tab.url) or re.search(r"f\?p=[^:]+:[^:]*:(\d+)", tab.url)
        if m and app_part in tab.url:
            session = m.group(1)
            break
    return source_context.storage_state(), session


def run_job(excel_path, out_dir, base, cdp_url="http://127.0.0.1:9222", allow_save=False,
            headless=False, slow_mo=60, only=None, on_event=None, extra_cases=None,
            app=None, users=None, password_for=None, functions=None):
    """Run the selected cases user by user. Evidence goes to out_dir. Used by the web backend.
    only         = case ids picked in the UI (e.g. "TC-001-S2"); None = every enabled Excel case
    extra_cases  = test cases built in the UI (already shaped like runner cases); excel_path may be None
    app          = {auth_type, login_config, home_page}; auth_type apex_login | chrome_session | none
    users        = [{key, id, username, display_name, role}]  (apex_login) - passwords are NOT in here
    password_for = callable(user) -> password, asked just before typing it into the login form
    functions    = reusable step sequences [{name, params, steps}]"""
    global CDP_URL, ALLOW_SAVE, HEADLESS, ONLY, OUT, VIDEO_DIR, RESULTS, CONFIG, ON_EVENT
    app = dict(app or {"auth_type": "chrome_session"})
    configure(base, app, functions)
    CDP_URL, ALLOW_SAVE, HEADLESS = cdp_url, allow_save, headless
    ONLY = set()
    OUT = Path(out_dir)
    VIDEO_DIR = OUT / "videos"
    RESULTS, CONFIG = [], {}
    ON_EVENT = on_event or (lambda k, p: None)
    cases = select_cases(load_cases(excel_path) if excel_path else [], only, extra_cases)
    ON_EVENT("cases", [describe(c) for c in cases])
    if not cases:
        raise ValueError("No test cases selected.")
    auth = app.get("auth_type") or "chrome_session"
    if auth == "chrome_session":
        users = [CHROME_USER]
    elif auth == "none":
        users = [ANON_USER]
    else:
        users = list(users or [])
        if not users:
            raise ValueError("Add at least one test user to this application (Applications > Test users).")
        if password_for is None:
            raise ValueError("No credential source configured.")
    plan = [(u, [c for c in cases if applies(c, u)]) for u in users]
    ON_EVENT("plan", [dict(key=u["key"], id=u.get("id"), username=u.get("username"), display_name=u.get("display_name"),
                           role=u.get("role"), cases=[c["_CASE_ID"] for c in cs]) for u, cs in plan])
    OUT.mkdir(parents=True, exist_ok=True)
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        storage_state, chrome_session = None, ""
        if auth == "chrome_session":
            storage_state, chrome_session = copy_chrome_session(p)
        browser = launch_browser(p, headless, slow_mo)
        try:
            for u, cs in plan:
                run_user(browser, u, cs, auth, password_for, storage_state, chrome_session)
        finally:
            browser.close()
    write_report()
    return RESULTS


# ----------------------------------------------------------------------------- one-off helpers for the UI
INSPECT_JS = r"""() => {
  const vis = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const txt = s => (s || '').replace(/\s+/g, ' ').trim().slice(0, 80);
  const lab = e => { const l = e.id && document.querySelector('label[for="' + CSS.escape(e.id) + '"]');
                     return txt((l && l.innerText) || e.getAttribute('aria-label') || e.placeholder || e.title || ''); };
  const items = [], seen = new Set();
  document.querySelectorAll('input, select, textarea').forEach(e => {
    const id = e.id || e.name || '';
    if (!id || seen.has(id) || /^(pFlow|pInstance|pPage|pSalt|pContext|p_md5|pdummy|pReload)/i.test(id)) return;
    const apexItem = /^P\d+_/i.test(id);
    if (!apexItem && (e.type === 'hidden' || !vis(e))) return;
    if (e.type === 'password') return;
    seen.add(id);
    items.push({ id, label: lab(e), type: e.tagName === 'SELECT' ? 'select' : (e.type || e.tagName.toLowerCase()),
                 visible: vis(e), readonly: !!(e.readOnly || e.disabled),
                 options: e.tagName === 'SELECT' ? [...e.options].slice(0, 12).map(o => txt(o.text)) : undefined });
  });
  const buttons = [...document.querySelectorAll('button, input[type=submit], input[type=button], a.t-Button, [role=button]')]
    .filter(vis).map(b => ({ id: b.id || '', text: txt(b.innerText || b.value || b.getAttribute('aria-label') || b.title) }))
    .filter(b => b.text || b.id).slice(0, 40);
  const links = [...document.querySelectorAll('a[href]')].map(a => ({ text: txt(a.innerText || a.title), href: a.href }))
    .filter(l => l.text && !/^javascript:/i.test(l.href)).slice(0, 80);
  const regions = [...document.querySelectorAll('.t-Region-title, .t-Card-title, .t-HeroRegion-title, h1, h2')]
    .filter(vis).map(e => txt(e.innerText)).filter(Boolean).slice(0, 20);
  const g = id => { const e = document.getElementById(id); return e ? e.value : ''; };
  return { title: document.title, url: location.href, app_id: g('pFlowId'), page_id: g('pFlowStepId'),
           items: items.slice(0, 80), buttons, links, regions };
}"""


def _pages_from_links(links):
    out, seen = [], set()
    for l in links:
        href = l.get("href") or ""
        ref = ""
        if is_legacy():
            m = re.search(r"f\?p=([^:&]+):([^:&]*)", href)
            if m and m.group(1) == BASE.split("f?p=", 1)[1]:
                ref = m.group(2)
        elif href.split("?")[0].startswith(BASE + "/"):
            ref = href.split("?")[0][len(BASE) + 1:].split("/")[0]
        if ref and ref.lower() not in seen and not re.search(r"logout|login", ref, re.I):
            seen.add(ref.lower())
            out.append({"ref": ref, "text": l.get("text") or ref})
    return out[:40]


def _authenticated_page(p, ctx, user, password, headless):
    """Login (when the app needs it) in ctx; returns (page, login_result)."""
    page = ctx.new_page()
    page.set_default_timeout(20000)
    auth = APP.get("auth_type")
    if auth == "apex_login":
        return page, login(page, user["username"], password)
    return page, dict(ok=True, detail="No login needed" if auth == "none" else "Using your Chrome session")


def try_login(base, app, user, password, headless=True):
    """'Test login' button: sign in as one user, verify, sign out. Returns details + a PNG screenshot (bytes)."""
    configure(base, app)
    global USER
    USER = dict(user)
    out = dict(ok=False, detail="", secs=0, landing_url="", app_user="", logout="", findings=[], shot=None)
    t0 = time.time()
    with sync_playwright() as p:
        browser = launch_browser(p, headless, 0)
        ctx = browser.new_context(viewport=VIEWPORT)
        try:
            page = ctx.new_page()
            page.set_default_timeout(20000)
            res = login(page, user["username"], password)
            out.update(ok=res["ok"], detail=res["detail"], landing_url=res.get("landing_url"), app_user=res.get("app_user"))
            try:
                out["shot"] = page.screenshot(timeout=10000)
            except Exception:
                pass
            if res["ok"]:
                ok, note, found = logout(page)
                out.update(logout=note, findings=found)
        finally:
            ctx.close()
            browser.close()
            USER = {}
    out["secs"] = round(time.time() - t0, 1)
    return out


def inspect(base, app, page_ref="", user=None, password=None, headless=True, storage_state=None):
    """Read a page's fields, buttons and links (helps you and the AI write steps with the right targets)."""
    configure(base, app)
    global USER, SESSION
    USER = dict(user or {})
    with sync_playwright() as p:
        if APP.get("auth_type") == "chrome_session" and storage_state is None:
            storage_state, SESSION = copy_chrome_session(p)
        browser = launch_browser(p, headless, 0)
        ctx = browser.new_context(viewport=VIEWPORT, storage_state=storage_state)
        try:
            page, res = _authenticated_page(p, ctx, user or {}, password, headless)
            if not res.get("ok"):
                return dict(ok=False, error=res.get("detail") or "Login failed")
            if page_ref or not page.url.startswith("http"):
                _open_raw(page, page_ref)
            if is_login_page(page):
                return dict(ok=False, error="The page redirected to the login page")
            info = page.evaluate(INSPECT_JS)
            info["pages"] = _pages_from_links(info.get("links") or [])
            info["ok"] = True
            if APP.get("auth_type") == "apex_login":
                logout(page)
            return info
        finally:
            ctx.close()
            browser.close()
            USER, SESSION = {}, ""


def main():
    if not BASE:
        print('Set APEX_BASE first, e.g. $env:APEX_BASE = "https://oracleapex.com/ords/r/abhi13_workspace/timesheet-app"')
        sys.exit(1)
    user = os.environ.get("APEX_USER", "").strip()
    if user and os.environ.get("APEX_PASSWORD"):
        app = {"auth_type": "apex_login", "home_page": os.environ.get("APEX_HOME", "")}
        users = [{"key": "cli", "username": user, "display_name": user, "role": os.environ.get("APEX_ROLE", "")}]
        print(f"Automatic login as {user}.")
    else:
        app, users = {"auth_type": "chrome_session"}, None
        print("Using your logged-in Chrome (set APEX_USER and APEX_PASSWORD for automatic login).")
    run_job(EXCEL_FILE, OUT, BASE, CDP_URL, ALLOW_SAVE, HEADLESS, int(os.environ.get("SLOW_MO", "60")),
            app=app, users=users, password_for=lambda u: os.environ.get("APEX_PASSWORD", ""))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("ERROR:", exc)
        sys.exit(1)
