"""APEX Test Studio backend - everything is stored in PostgreSQL (see db.py); passwords only in the secret store (vault.py).

Applications
  GET/POST /api/applications              PUT/DELETE /api/applications/<id>
  POST /api/applications/test {base_url}  Test Connection (is the URL reachable?)
  POST /api/applications/<id>/inspect     log in and list a page's fields, buttons and links
Test users (per application; the API never returns a password)
  GET/POST /api/applications/<id>/users   PUT/DELETE /api/users/<id>   POST /api/users/<id>/test-login
Suites and reusable functions
  GET/POST /api/applications/<id>/suites     PUT/DELETE /api/suites/<id>
  GET/POST /api/applications/<id>/functions  PUT/DELETE /api/functions/<id>
Tests and runs
  POST /api/upload?filename=x.xlsx&application_id=1   GET /api/uploads   GET /api/uploads/<id>
  GET/POST /api/custom   PUT/DELETE /api/custom/<id>
  POST /api/ai/generate  {application_id, prompt, page?, user_id?, inspect?}   structured steps from plain English
  POST /api/runs  {application_id, upload_id?, only?, user_ids?, suite_id?, ...}   user-wise run in the background
  GET /api/runs   GET /api/runs/<id>   DELETE /api/runs/<id>   GET /api/runs/<id>/report   GET /api/runs/<id>/csv
Dashboard
  GET /api/dashboard?application_id=&group=application|user|role|case     GET /api/analytics
  GET/PUT /api/settings   GET /api/config   GET /media/<id> (Range supported)   GET / (frontend/dist)

Start:   python server.py            (http://localhost:8000)
Preview: DEMO=1 python server.py     (simulated results + real recorded videos, still stored in the DB)
"""
import base64
import csv
import html
import io
import json
import mimetypes
import os
import re
import shutil
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

import psycopg

import db
import runner
import vault

ROOT = Path(__file__).resolve().parent
DIST = ROOT.parent / "frontend" / "dist"
DEMO = os.environ.get("DEMO", "").strip().lower() in ("1", "y", "yes", "true")
PORT = int(os.environ.get("PORT", "8000"))
RUN_LOCK = threading.Lock()          # runner.py keeps module-level state -> one browser job at a time
MIME = {".webm": "video/webm", ".png": "image/png"}
AI_MODEL = os.environ.get("AI_MODEL", "claude-sonnet-5-5").strip()
AI_URL = os.environ.get("AI_API_URL", "https://api.anthropic.com/v1/messages").strip()


class ApiError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status


def _json_default(o):
    return o.isoformat() if hasattr(o, "isoformat") else str(o)


def first_line(exc, n=300):
    return (str(exc).strip().splitlines() or [repr(exc)])[0][:n]


# ------------------------------------------------------------------ test cases
def describe_cases(path):
    return [dict(runner.describe(c), implemented=str(c.get("TEST_KEY") or "").strip().upper() in runner.TESTS)
            for c in runner.load_cases(path)]


def custom_id(r):
    return f"CUS-{r['id']:03d}"


def run_as_tokens(ra):
    ra = ra or {}
    return [str(x) for x in (ra.get("roles") or []) + (ra.get("users") or [])]


def custom_desc(r):
    """Shape sent to the UI."""
    p = r["params"] or {}
    return dict(id=custom_id(r), db_id=r["id"], name=r["name"], key=r["test_key"], expected=r["expected"] or "",
                data=p.get("data"), page=p.get("page"), custom=True, implemented=True, params=p, steps=r["steps"],
                run_as=run_as_tokens(r.get("run_as")), run_as_cfg=r.get("run_as") or {})


def custom_case(r):
    """Shape the runner executes (same keys an Excel row would have)."""
    p, cid = r["params"] or {}, custom_id(r)
    ra = r.get("run_as") or {}
    return {"TEST_CASE_ID": cid, "_CASE_ID": cid, "TEST_NAME": r["name"], "_LABEL": r["name"], "TEST_KEY": r["test_key"],
            "EXPECTED_RESULT": r["expected"] or "", "TEST_DATA": p.get("data") or None, "WEEK_OFFSET": p.get("week_offset"),
            "DATE_OFFSET_DAYS": p.get("date_offset"), "DAY": p.get("day"), "STEPS": r["steps"],
            "PAGE_ALIAS": p.get("page") or "", "ALLOWED_ROLES": p.get("allowed") or "", "ITEM": p.get("item") or "",
            "EXPECTED_TEXT": p.get("expect_text") or "",
            "RUN_AS": {"roles": ra.get("roles") or [], "users": [str(u) for u in ra.get("users") or []]}}


PARAM_KEYS = ("data", "week_offset", "date_offset", "day", "page", "allowed", "item", "expect_text")


def clean_steps(raw, strict=True):
    """Validate steps from the UI / AI. strict=False drops bad steps and reports them instead of failing."""
    steps, problems = [], []
    for i, st in enumerate(raw or [], 1):
        if not isinstance(st, dict):
            problems.append(f"step {i} is not an object")
            continue
        act = str(st.get("action") or "").strip()
        if act not in runner.STEP_LABELS:
            if strict:
                raise ValueError(f"Unknown step action '{act}'.")
            problems.append(f"step {i}: unknown action '{act}'")
            continue
        clean = {"action": act, "target": str(st.get("target") or "").strip()[:500], "value": str(st.get("value") or "").strip()[:500]}
        if act == "assert":
            subj = str(st.get("subject") or "text").strip()
            op = str(st.get("op") or "").strip()
            if subj not in runner.ASSERT_SUBJECTS or (op and op not in runner.ASSERT_OPS):
                if strict:
                    raise ValueError(f"Step {i}: unknown check '{subj}' / '{op}'.")
                problems.append(f"step {i}: unknown check '{subj} {op}'")
                continue
            clean.update(subject=subj, op=op)
        if act == "call" and not clean["target"]:
            if strict:
                raise ValueError(f"Step {i}: choose the function to use.")
            problems.append(f"step {i}: function name missing")
            continue
        steps.append(clean)
    return steps, problems


def clean_run_as(body, app_id):
    ra = body.get("run_as") or {}
    roles = sorted({str(x).strip() for x in ra.get("roles") or [] if str(x).strip()})[:30]
    valid = {u["id"] for u in db.list_users(app_id)} if app_id else set()
    users = sorted({int(x) for x in ra.get("users") or [] if str(x).isdigit() and int(x) in valid})
    return {"roles": roles, "users": users} if (roles or users) else {}


def clean_custom(body, app_id):
    name = str(body.get("name") or "").strip()
    if not name:
        raise ValueError("Give the test a name.")
    key = str(body.get("test_key") or "CUSTOM_STEPS").strip().upper()
    if key not in runner.TESTS:
        raise ValueError(f"Unknown test type {key}.")
    steps, _ = clean_steps(body.get("steps"))
    if key == "CUSTOM_STEPS" and not steps:
        raise ValueError("Add at least one step.")
    params = {k: str(v).strip() for k, v in (body.get("params") or {}).items() if k in PARAM_KEYS and str(v).strip() != ""}
    return name, str(body.get("expected") or "").strip(), key, params, steps, clean_run_as(body, app_id)


# ------------------------------------------------------------------ applications
ENVIRONMENTS = ("development", "test", "staging", "production")
AUTH_TYPES = ("apex_login", "chrome_session", "none")


def clean_app(body):
    name = str(body.get("name") or "").strip()
    if not name:
        raise ValueError("Give the application a name.")
    if len(name) > 80:
        raise ValueError("Application name is too long (max 80 characters).")
    url = str(body.get("base_url") or "").strip().rstrip("/")
    if not re.match(r"https?://\S+$", url):
        raise ValueError("Base URL must start with http:// or https:// (no spaces).")
    env = str(body.get("environment") or "test").strip().lower()
    if env not in ENVIRONMENTS:
        raise ValueError("Environment must be development, test, staging or production.")
    auth = str(body.get("auth_type") or "apex_login").strip()
    if auth not in AUTH_TYPES:
        raise ValueError("Unsupported authentication type.")
    lc = {k: str(v or "").strip()[:400] for k, v in (body.get("login_config") or {}).items()
          if k in runner.LOGIN_DEFAULTS and str(v or "").strip()}
    home = str(body.get("home_page") or "").strip().strip("/")[:200]
    norm = runner.normalize_base(url)             # a pasted page URL (with ?session=...) becomes the app's base URL
    if not home:
        if "f?p=" in url:
            parts = url.split("f?p=", 1)[1].split("&")[0].split(":")
            home = parts[1] if len(parts) > 1 else ""
        elif url.split("?")[0].startswith(norm):
            rest = url.split("?")[0][len(norm):].strip("/")
            home = rest if rest and "/" not in rest else ""
    url = norm or url
    return name, url, env, auth, str(body.get("description") or "").strip()[:300], lc, home


def app_runtime(app):
    return dict(auth_type=app["auth_type"], login_config=app.get("login_config") or {}, home_page=app.get("home_page") or "")


def check_url(url):
    """Test Connection: any HTTP answer (even 302/401/403) means the server is reachable; 5xx or no answer is a problem."""
    if not re.match(r"https?://\S+$", url or ""):
        return dict(ok=False, error="Base URL must start with http:// or https://")
    req = urllib.request.Request(url, headers={"User-Agent": "APEX-Test-Studio/1.0"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            status, final = resp.status, resp.geturl()
    except urllib.error.HTTPError as exc:               # the server answered, just not with 2xx
        status, final = exc.code, exc.geturl()
    except Exception as exc:
        return dict(ok=False, error=str(getattr(exc, "reason", None) or exc)[:200])
    ms = int((time.time() - t0) * 1000)
    note = ("Reachable." if status < 400 else
            "Reachable (the app asks for a login, which is normal)." if status in (401, 403) else
            f"The server answered with HTTP {status}.")
    return dict(ok=status < 500, status=status, ms=ms, final_url=final, note=note)


# ------------------------------------------------------------------ test users
def user_desc(u):
    """What the UI may see about a test user: never the password, only whether the reference works."""
    cred = vault.status(u["credential_ref"])
    return dict(id=u["id"], application_id=u["application_id"], username=u["username"], display_name=u["display_name"],
                role=u["role"], enabled=u["enabled"], notes=u["notes"],
                credential=dict(kind=cred.get("kind"), ok=cred["ok"], note=cred["note"], name=cred.get("name")),
                last_login_status=u["last_login_status"], last_login_detail=u["last_login_detail"],
                last_login_at=u["last_login_at"])


def run_user_of(u):
    """Shape the runner gets: no password, no reference."""
    return dict(key=str(u["id"]), id=u["id"], username=u["username"], display_name=u["display_name"] or u["username"],
                role=u["role"] or "")


def save_user(app_id, user_id, body):
    username = str(body.get("username") or "").strip()
    if not username:
        raise ApiError(400, "Enter the username the test user signs in with.")
    if len(username) > 120:
        raise ApiError(400, "Username is too long.")
    existing = db.get_user(user_id) if user_id else None
    if user_id and not existing:
        raise ApiError(404, "Test user not found.")
    app_id = existing["application_id"] if existing else app_id
    cred = body.get("credential") or {}
    mode = str(cred.get("mode") or ("keep" if existing else "")).strip()
    ref = existing["credential_ref"] if existing else ""
    if mode == "env":
        name = str(cred.get("name") or "").strip()
        try:
            vault.parse("env:" + name)
        except vault.CredentialError as exc:
            raise ApiError(400, str(exc))
        if ref.startswith("vault:"):
            vault.delete(ref)
        ref = "env:" + name
    elif mode == "vault":
        pw = cred.get("password")
        if not isinstance(pw, str) or not pw:
            if not (existing and ref.startswith("vault:")):
                raise ApiError(400, "Type the password (it is encrypted and never shown again).")
        else:
            try:
                ref = vault.store(pw, label=f"app {app_id} / {username}", ref=ref if ref.startswith("vault:") else None)
            except vault.CredentialError as exc:
                raise ApiError(400, str(exc))
            finally:
                pw = None
    elif mode != "keep":
        raise ApiError(400, "Choose where the password comes from: the encrypted secret store or an environment variable.")
    try:
        new_id = db.save_user(user_id, app_id, username, str(body.get("display_name") or "").strip()[:120],
                              str(body.get("role") or "").strip()[:60], ref, bool(body.get("enabled", True)),
                              str(body.get("notes") or "").strip()[:300])
    except psycopg.errors.UniqueViolation:
        raise ApiError(409, f"User '{username}' already exists in this application.")
    return user_desc(db.get_user(new_id))


# ------------------------------------------------------------------ suites / functions
def clean_suite(body, app_id):
    name = str(body.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Give the suite a name.")
    upload_id = str(body.get("upload_id") or "").strip() or None
    if upload_id:
        up = db.get_upload(upload_id)
        if not up or up["application_id"] != app_id:
            upload_id = None
    case_ids = [str(c) for c in body.get("case_ids") or []][:500]
    valid = {u["id"] for u in db.list_users(app_id)}
    user_ids = [int(u) for u in body.get("user_ids") or [] if str(u).isdigit() and int(u) in valid]
    return name[:80], str(body.get("description") or "").strip()[:300], upload_id, case_ids, user_ids


def clean_function(body):
    name = str(body.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Give the function a name.")
    params = []
    for prm in body.get("params") or []:
        pn = str(prm.get("name") if isinstance(prm, dict) else prm).strip()
        if not pn:
            continue
        if not re.fullmatch(r"[A-Za-z_]\w{0,40}", pn):
            raise ApiError(400, f"Parameter '{pn}': use letters, digits and _ only.")
        params.append({"name": pn, "default": str(prm.get("default") or "") if isinstance(prm, dict) else ""})
    try:
        steps, _ = clean_steps(body.get("steps"))
    except ValueError as exc:
        raise ApiError(400, str(exc))
    if not steps:
        raise ApiError(400, "Add at least one step to the function.")
    if any(s["action"] == "call" and s["target"].strip().lower() == name.lower() for s in steps):
        raise ApiError(400, "A function cannot use itself.")
    return name[:80], str(body.get("description") or "").strip()[:300], params, steps


def function_desc(f):
    return dict(id=f["id"], name=f["name"], description=f["description"], params=f["params"] or [], steps=f["steps"] or [])


# ------------------------------------------------------------------ AI: plain English -> structured steps
AI_SYSTEM = """You turn a tester's plain-English description into a structured UI test for an Oracle APEX application.
Reply with ONE JSON object and nothing else:
{"name": "<short test name>", "expected": "<expected result in one sentence>",
 "steps": [<step>, ...], "run_as": {"roles": ["<ROLE>", ...]}}
Each step is {"action": ..., "target": ..., "value": ...} using ONLY these actions:
- open: target = page alias or number ("" = home page)
- click: target = visible text of the button/link, or a CSS selector such as #B123_SAVE
- type: target = field label or #ITEM_ID (e.g. #P4_HOURS), value = text to type
- choose: target = select list label or #ITEM_ID, value = option label
- set_item: target = APEX item name (P4_HOURS), value = new value (sets it with apex.item().setValue)
- press: value = key name (Enter, Tab, Escape)
- wait: value = seconds
- wait_for: target = text that must appear, value = max seconds
- see / not_see: target = text that must / must not be visible
- url: value = text the URL must contain
- assert: an editable check, add "subject" and "op":
    subject: text | element_text | value | item | url | title | count | alert | visible | hidden | enabled | disabled | editable | readonly
    op: equals | not_equals | contains | not_contains | starts_with | matches | gt | ge | lt | le | empty | not_empty
    (visible/hidden/enabled/disabled/editable/readonly need no op; target = the element)
- call: target = the name of an existing reusable function, value = "param=value; param2=value"
- open_week: value = week offset (only for the timesheet page)
Variables you may use in target/value: {{username}}, {{role}}, {{today}}, {{today+N}}, {{today-N}}.
Rules: use the real item ids / button texts from PAGE ELEMENTS when they are given; prefer existing FUNCTIONS for repeated
work; end with at least one see/not_see/assert step that proves the expected result; leave run_as roles empty unless the
description is about specific roles; never include passwords or log in/out steps (the runner signs in as each test user)."""


def _extract_json(text):
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        raise ValueError("The AI reply did not contain JSON.")
    return json.loads(m.group(0))


def _guess_name(prompt):
    words = re.sub(r"\s+", " ", re.sub(r"[\"“”'‘’]", "", prompt)).strip()
    return (words[:60] + ("…" if len(words) > 60 else "")) or "Generated test"


def ai_generate(app, prompt, page_info=None, functions=(), roles=()):
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    names = [f["name"] for f in functions]
    if not key:
        steps, problems = runner.parse_steps_text(prompt, names)
        last = next((s for s in reversed(steps) if s["action"] in ("see", "not_see", "assert", "url")), None)
        expected = ""
        if last and last["action"] == "see":
            expected = f"'{last['target']}' is shown"
        elif last and last["action"] == "not_see":
            expected = f"'{last['target']}' is not shown"
        elif last and last["action"] == "assert":
            expected = f"{runner.ASSERT_SUBJECTS.get(last.get('subject'), '')} {last['target']} " \
                       f"{runner.ASSERT_OPS.get(last.get('op'), last.get('subject', ''))} {last['value']}".strip()
        return dict(source="rules", name=_guess_name(prompt), expected=expected, steps=steps, problems=problems, run_as={},
                    note="Built by the offline rule parser. Add ANTHROPIC_API_KEY to backend/.env for AI generation.")
    ctx = {"application": app["name"], "home_page": app.get("home_page") or "", "roles": sorted(set(roles)),
           "functions": [{"name": f["name"], "params": [p.get("name") for p in f.get("params") or []],
                          "description": f.get("description") or ""} for f in functions]}
    if page_info:
        ctx["page_elements"] = {k: page_info.get(k) for k in ("title", "page_id", "items", "buttons", "regions", "pages")}
    body = {"model": AI_MODEL, "max_tokens": 2000, "system": AI_SYSTEM,
            "messages": [{"role": "user", "content": "CONTEXT:\n" + json.dumps(ctx, default=str)[:24000]
                          + "\n\nTEST TO WRITE:\n" + prompt.strip()[:4000]}]}
    req = urllib.request.Request(AI_URL, data=json.dumps(body).encode(), method="POST",
                                 headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode(errors="replace")[:300]
        raise ApiError(502, f"AI service answered HTTP {exc.code}: {detail}")
    except Exception as exc:
        raise ApiError(502, f"Could not reach the AI service: {first_line(exc, 200)}")
    text = "".join(c.get("text", "") for c in data.get("content") or [] if c.get("type") == "text")
    try:
        out = _extract_json(text)
    except Exception as exc:
        raise ApiError(502, f"The AI reply could not be read: {first_line(exc, 200)}")
    steps, problems = clean_steps(out.get("steps"), strict=False)
    known = {n.lower() for n in names}
    for s in steps:
        if s["action"] == "call" and s["target"].lower() not in known:
            problems.append(f"function '{s['target']}' does not exist yet")
    ra = out.get("run_as") or {}
    return dict(source="ai", model=AI_MODEL, name=str(out.get("name") or _guess_name(prompt))[:120],
                expected=str(out.get("expected") or "")[:300], steps=steps, problems=problems,
                run_as={"roles": [str(r) for r in ra.get("roles") or [] if str(r).strip()]} if ra.get("roles") else {})


# ------------------------------------------------------------------ browser helpers (one at a time, like runs)
def with_browser_lock(fn):
    if not RUN_LOCK.acquire(blocking=False):
        raise ApiError(409, "A test run is using the browser. Try again when it has finished.")
    try:
        return fn()
    finally:
        RUN_LOCK.release()


def inspect_page(app, page_ref, user_id=None, headless=True):
    user, pw = None, None
    if app["auth_type"] == "apex_login":
        users = [u for u in db.list_users(app["id"], enabled_only=True) if not user_id or u["id"] == int(user_id)]
        if not users:
            raise ApiError(400, "Add a test user first - the page is read after signing in as that user.")
        u = users[0]
        try:
            pw = vault.resolve(u["credential_ref"])
        except vault.CredentialError as exc:
            raise ApiError(400, f"{u['username']}: {exc}")
        user = run_user_of(u)
    try:
        return with_browser_lock(lambda: runner.inspect(app["base_url"], app_runtime(app), page_ref, user, pw))
    finally:
        pw = None


def with_temp_xlsx(data, fn):
    """The runner reads Excel from a path: give it a throw-away temp file (deleted immediately)."""
    tmp = Path(tempfile.mkdtemp(prefix="ats_x_"))
    try:
        p = tmp / "tests.xlsx"
        p.write_bytes(data)
        return fn(p)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------ demo mode (no APEX needed)
def demo_run(excel_path, out, on_event, only=None, extra=None, users=None):
    """Simulates a user-wise run: real short video per test so the UI can be previewed end to end."""
    from playwright.sync_api import sync_playwright
    cases = runner.select_cases(runner.load_cases(excel_path) if excel_path else [], only, extra)
    on_event("cases", [runner.describe(c) for c in cases])
    users = users or [dict(key="demo-1", id=None, username="employee1", display_name="Employee", role="EMPLOYEE"),
                      dict(key="demo-2", id=None, username="manager1", display_name="Manager", role="MANAGER")]
    plan = [(u, [c for c in cases if runner.applies(c, u)]) for u in users]
    on_event("plan", [dict(key=u["key"], id=u.get("id"), username=u["username"], display_name=u.get("display_name"),
                           role=u.get("role"), cases=[c["_CASE_ID"] for c in cs]) for u, cs in plan])
    out.mkdir(parents=True, exist_ok=True)

    def clip(browser, name, html_body, color, ms=1200):
        vdir = out / "tmp"
        ctx = browser.new_context(viewport={"width": 960, "height": 540}, record_video_dir=str(vdir),
                                  record_video_size={"width": 960, "height": 540})
        page = ctx.new_page()
        page.set_content(f"<body style='font-family:sans-serif;padding:48px;background:#f6f7fb'>{html_body}"
                         f"<div id=b style='height:14px;width:0;background:{color};transition:width {ms / 1000}s'></div></body>")
        page.wait_for_timeout(150)
        page.evaluate("document.getElementById('b').style.width='100%'")
        page.wait_for_timeout(ms + 100)
        page.screenshot(path=str(out / f"{name}.png"))
        page.close()
        page.video.save_as(str(out / f"{name}.webm"))
        page.video.delete()
        ctx.close()
        return f"{name}.webm", f"{name}.png"

    with sync_playwright() as p:
        browser = p.chromium.launch()
        for ui, (u, cs) in enumerate(plan):
            on_event("user", u["key"])
            bad = re.search(r"bad|locked|wrong", u["username"], re.I)
            safe = re.sub(r"[^A-Za-z0-9_-]+", "_", u["key"])
            v, s = clip(browser, f"login_{safe}", f"<h2>DEMO - sign in as {html.escape(u['username'])}</h2>"
                        + ("<p style='color:#b91c1c'>Invalid Login Credentials</p>" if bad else "<p>Welcome!</p>"),
                        "#dc2626" if bad else "#3f5fe0", 800)
            on_event("login", dict(user_key=u["key"], test_user_id=u.get("id"), username=u["username"], role=u.get("role"),
                                   status="FAIL" if bad else "OK", secs=1.1, video=v, shot=s, findings=[],
                                   detail="Login rejected: Invalid Login Credentials" if bad
                                   else f"Signed in as {u['username'].upper()} in 1.1 s (APEX session 1{ui}4567)"))
            for i, c in enumerate(cs):
                cid = c["_CASE_ID"]
                base = dict(test_case_id=cid, name=c["_LABEL"], test_key=str(c.get("TEST_KEY") or ""),
                            expected=str(c.get("EXPECTED_RESULT") or ""), data=c.get("TEST_DATA"), user_key=u["key"],
                            test_user_id=u.get("id"), username=u["username"], role=u.get("role"))
                if bad:
                    on_event("done", dict(base, status="SKIP", secs=0, video="", shot="", findings=[],
                                          detail=f"Not run - login failed for {u['username']}"))
                    continue
                on_event("start", {"case_id": cid, "user_key": u["key"]})
                fail = (i + ui) % 3 == 2
                findings = []
                if fail and ui == len(plan) - 1:
                    findings = [dict(severity="high", title=f"Role '{u.get('role')}' can open a restricted page",
                                     detail="Demo finding", username=u["username"], role=u.get("role"))]
                v, s = clip(browser, re.sub(r"[^A-Za-z0-9_-]+", "_", f"{u['key']}_{cid}"),
                            f"<h2>DEMO - {html.escape(cid)} as {html.escape(u['username'])}</h2><p>{html.escape(c['_LABEL'])}</p>",
                            "#dc2626" if fail else "#16a34a")
                on_event("done", dict(base, status="FAIL" if fail else "PASS", secs=1.4, video=v, shot=s, findings=findings,
                                      detail=("Demo: simulated failure - the cell was still editable." if fail
                                              else "Demo: simulated pass - behaved as expected.")))
            if not bad:
                on_event("logout", dict(user_key=u["key"], ok=True, findings=[],
                                        detail="Signed out - the old session no longer opens the app"))
        browser.close()


# ------------------------------------------------------------------ run worker: evidence goes straight into PostgreSQL
def worker(run_id, upload_id, req, only, extra, app, users, functions, refs):
    tmp = Path(tempfile.mkdtemp(prefix="ats_run_"))         # Playwright needs a folder while recording; wiped at the end
    out = tmp / "out"
    state = {"order": []}

    def store_file(case_id, kind, rel):
        if not rel:
            return None
        f = out / str(rel).replace("\\", "/")
        if not f.is_file():
            return None
        try:
            return db.add_media(run_id, case_id, kind, f.name,
                                MIME.get(f.suffix.lower(), "application/octet-stream"), f.read_bytes())
        finally:
            f.unlink(missing_ok=True)                      # nothing is left on disk

    def on_event(kind, payload):
        try:
            if kind == "cases":
                state["order"] = [c["id"] for c in payload]
                db.update_run(run_id, cases=payload)
            elif kind == "plan":
                db.update_run(run_id, users=payload)
            elif kind == "user":
                db.update_run(run_id, current_user_key=payload, current_case=None)
            elif kind == "login":
                r = dict(payload)
                tag = f"login:{r['user_key']}"
                db.add_login(run_id, r, store_file(tag, "video", r.get("video")), store_file(tag, "screenshot", r.get("shot")))
                if r.get("test_user_id"):
                    db.record_login(r["test_user_id"], r["status"], r.get("detail"))
            elif kind == "logout":
                db.add_logout(run_id, payload)
            elif kind == "start":
                p = payload if isinstance(payload, dict) else {"case_id": payload}
                db.update_run(run_id, current_case=p.get("case_id"), current_user_key=p.get("user_key"))
            elif kind == "done":
                r = dict(payload)
                cid = r["test_case_id"]
                tag = f"{r.get('user_key') or ''}:{cid}"
                vid = store_file(tag, "video", r.get("video"))
                shot = store_file(tag, "screenshot", r.get("shot"))
                seq = state["order"].index(cid) if cid in state["order"] else len(state["order"])
                db.add_result(run_id, seq, r, vid, shot)
                db.update_run(run_id, current_case=None)
        except Exception:
            traceback.print_exc()

    def password_for(user):
        return vault.resolve(refs[user["id"]])            # read at the moment of login, never stored

    status, error = "finished", None
    try:
        with RUN_LOCK:
            xlsx = None
            if upload_id:
                up = db.get_upload(upload_id, with_content=True)
                xlsx = tmp / "tests.xlsx"
                xlsx.write_bytes(bytes(up["content"]))
            if DEMO:
                demo_run(xlsx, out, on_event, only, extra, users if app["auth_type"] == "apex_login" and users else None)
            else:
                runner.run_job(xlsx, out, req["base_url"], req.get("cdp_url") or "http://127.0.0.1:9222",
                               bool(req.get("allow_save")), bool(req.get("headless")),
                               int(req.get("slow_mo") if req.get("slow_mo") is not None else 60),
                               only=only, on_event=on_event, extra_cases=extra, app=app, users=users,
                               password_for=password_for, functions=functions)
    except Exception as exc:
        traceback.print_exc()
        status, error = "error", first_line(exc, 500)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    try:
        db.update_run(run_id, status=status, error=error, current_case=None, current_user_key=None, finished=True)
        db.prune()
    except Exception:
        traceback.print_exc()


def plan_preview(descs, users):
    out = []
    for u in users:
        ids = [d["id"] for d in descs if runner.applies({"RUN_AS": ",".join(d.get("run_as") or [])}, u)]
        out.append(dict(u, cases=ids))
    return out


def start_run(req):
    try:
        app = db.get_application(int(req.get("application_id")))
    except (TypeError, ValueError):
        app = None
    if not app:
        raise ApiError(400, "Choose an application to test (Applications tab).")
    suite = None
    if req.get("suite_id"):
        suite = db.get_suite(int(req["suite_id"]))
        if not suite or suite["application_id"] != app["id"]:
            raise ApiError(404, "Suite not found.")
        if req.get("only") is None and suite["case_ids"]:
            req["only"] = suite["case_ids"]
        if req.get("user_ids") is None and suite["user_ids"]:
            req["user_ids"] = suite["user_ids"]
        if not req.get("upload_id") and suite["upload_id"]:
            req["upload_id"] = suite["upload_id"]
    up = None
    if req.get("upload_id"):
        up = db.get_upload(req["upload_id"])
        if not up:
            raise ApiError(404, "Upload not found - upload the Excel file again.")
        if up["application_id"] != app["id"]:
            raise ApiError(400, "That workbook belongs to a different application.")
    req["base_url"] = app["base_url"]                # the URL always comes from the application, not from the browser
    if not DEMO and not str(app["base_url"]).startswith("http"):
        raise ApiError(400, f"'{app['name']}' has no Base URL yet. Edit the application and add it.")
    if db.q1("select 1 as x from ats_runs where status='running' limit 1"):
        raise ApiError(409, "A run is already in progress.")
    only = req.get("only")                                  # ids picked in the UI; None = everything
    wanted = None if only is None else {str(i) for i in only}
    excel = list(up["cases"]) if up else []
    customs = db.list_custom(app["id"])
    if wanted is not None:
        excel = [c for c in excel if c["id"] in wanted]
        customs = [c for c in customs if custom_id(c) in wanted]
    descs = excel + [custom_desc(c) for c in customs]
    if not descs:
        raise ApiError(400, "Select at least one test case to run.")

    users, refs = [], {}
    if app["auth_type"] == "apex_login":
        chosen = db.list_users(app["id"], enabled_only=True)
        if req.get("user_ids") is not None:
            ids = {int(i) for i in req["user_ids"] if str(i).isdigit()}
            chosen = [u for u in chosen if u["id"] in ids]
        if not chosen:
            raise ApiError(400, "Add or select at least one active test user (Applications > Test users).")
        if not DEMO:
            bad = [f"{u['username']} ({vault.status(u['credential_ref'])['note']})" for u in chosen
                   if not vault.status(u["credential_ref"])["ok"]]
            if bad:
                raise ApiError(400, "No usable password for: " + "; ".join(bad))
        users = [run_user_of(u) for u in chosen]
        refs = {u["id"]: u["credential_ref"] for u in chosen}
        preview = plan_preview(descs, users)
    elif app["auth_type"] == "none":
        preview = plan_preview(descs, [runner.ANON_USER])
    else:
        preview = plan_preview(descs, [runner.CHROME_USER] if not DEMO else
                               [dict(key="demo-1", username="employee1", role="EMPLOYEE"),
                                dict(key="demo-2", username="manager1", role="MANAGER")])
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_settings = {k: req.get(k) for k in ("cdp_url", "allow_save", "headless", "slow_mo")}
    db.create_run(run_id, up["id"] if up else None, up["filename"] if up else "Custom tests", DEMO,
                  req.get("base_url", ""), safe_settings, app["id"], app["name"], preview, app["auth_type"],
                  suite["name"] if suite else None)
    db.update_run(run_id, cases=descs)
    functions = [function_desc(f) for f in db.list_functions(app["id"])]
    threading.Thread(target=worker, args=(run_id, up["id"] if up else None, req,
                                          None if wanted is None else sorted(wanted),
                                          [custom_case(c) for c in customs], app_runtime(app), users, functions, refs),
                     daemon=True).start()
    return dict(run_id=run_id, users=preview, cases=descs)


# ------------------------------------------------------------------ results dashboard
SEV_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def dashboard(application_id, group):
    runs, results, logins = db.dashboard_rows(application_id)
    info = {r["id"]: r for r in runs}
    order = {r["id"]: i for i, r in enumerate(runs)}          # 0 = newest
    media = db._media_url

    def gkey(r):
        run = info[r["run_id"]]
        if group == "application":
            return str(run["application_id"]), run["application_name"] or "(deleted application)", ""
        if group == "role":
            return (r["role"] or "").upper() or "-", (r["role"] or "No role"), ""
        if group == "case":
            return r["test_case_id"], r["test_case_id"], r.get("name") or ""
        return r["username"] or "-", r["username"] or "(no user)", r["role"] or ""

    groups = {}
    history = {}
    for r in results:
        k, label, sub = gkey(r)
        g = groups.setdefault(k, dict(key=k, label=label, sub=sub, PASS=0, FAIL=0, SKIP=0, findings=0, login_fail=0,
                                      runs=set(), regressions=0, fixed=0, last=None))
        g[r["status"]] = g.get(r["status"], 0) + 1
        g["findings"] += len(r["findings"] or [])
        g["runs"].add(r["run_id"])
        o = order[r["run_id"]]                          # newest run in the group decides the "last" status
        if g["last"] is None or o < g["last"][0]:
            g["last"] = (o, r["status"])
        elif o == g["last"][0]:
            rank = {"FAIL": 0, "PASS": 1, "SKIP": 2}
            if rank.get(r["status"], 3) < rank.get(g["last"][1], 3):
                g["last"] = (o, r["status"])
        history.setdefault((k, r["test_case_id"], r["user_key"]), []).append((order[r["run_id"]], r["status"], r))
    regressions = []
    for (k, cid, uk), seq in history.items():
        seq.sort(key=lambda t: t[0])
        if len(seq) >= 2:
            (_, s1, r1), (_, s0, _) = seq[0], seq[1]
            if s1 == "FAIL" and s0 == "PASS":
                groups[k]["regressions"] += 1
                regressions.append(dict(run_id=r1["run_id"], started_at=info[r1["run_id"]]["started_at"],
                                        application=info[r1["run_id"]]["application_name"], test_case_id=cid,
                                        name=r1["name"], username=r1["username"], role=r1["role"],
                                        detail=r1["detail"], video=media(r1["video_id"]), shot=media(r1["shot_id"])))
            elif s1 == "PASS" and s0 == "FAIL":
                groups[k]["fixed"] += 1
    login_failures = []
    for l in logins:
        if group in ("user", "role", "application"):
            pseudo = dict(l, test_case_id="", name="")
            k = gkey(pseudo)[0]
            if l["status"] == "FAIL":
                g = groups.setdefault(k, dict(key=k, label=gkey(pseudo)[1], sub=gkey(pseudo)[2], PASS=0, FAIL=0, SKIP=0,
                                              findings=0, login_fail=0, runs=set(), regressions=0, fixed=0, last=None))
                g["login_fail"] += 1
                g["runs"].add(l["run_id"])
            if l["findings"]:
                if k in groups:
                    groups[k]["findings"] += len(l["findings"])
        if l["status"] == "FAIL":
            login_failures.append(dict(run_id=l["run_id"], started_at=info[l["run_id"]]["started_at"],
                                       application=info[l["run_id"]]["application_name"], username=l["username"],
                                       role=l["role"], detail=l["detail"], video=media(l["video_id"]), shot=media(l["shot_id"])))
    findings = []
    for r in list(results) + [dict(l, test_case_id="login", name="Sign-in / sign-out") for l in logins]:
        for f in r.get("findings") or []:
            findings.append(dict(run_id=r["run_id"], started_at=info[r["run_id"]]["started_at"],
                                 application=info[r["run_id"]]["application_name"], test_case_id=r["test_case_id"],
                                 name=r.get("name"), username=f.get("username") or r.get("username"),
                                 role=f.get("role") or r.get("role"), severity=f.get("severity") or "medium",
                                 title=f.get("title"), detail=f.get("detail"),
                                 video=media(r.get("video_id")), shot=media(r.get("shot_id"))))
    findings.sort(key=lambda f: (SEV_RANK.get(f["severity"], 9), order[f["run_id"]]))
    unique = {}
    for f in findings:                                  # same finding in several runs -> one row, newest evidence
        k = (f["title"], f["username"], f["test_case_id"])
        if k in unique:
            unique[k]["runs"] += 1
        else:
            unique[k] = dict(f, runs=1)
    findings = list(unique.values())
    rows = []
    for g in groups.values():
        total = g["PASS"] + g["FAIL"] + g["SKIP"]
        rows.append(dict(key=g["key"], label=g["label"], sub=g["sub"], pass_=g["PASS"], fail=g["FAIL"], skip=g["SKIP"],
                         total=total, rate=round(100 * g["PASS"] / (g["PASS"] + g["FAIL"])) if g["PASS"] + g["FAIL"] else None,
                         runs=len(g["runs"]),
                         findings=g["findings"], login_fail=g["login_fail"], regressions=g["regressions"], fixed=g["fixed"],
                         last=g["last"][1] if g["last"] else None))
    rows.sort(key=lambda r: (-(r["fail"] + r["login_fail"] + r["findings"]), str(r["label"]).lower()))
    for r in rows:
        r["pass"] = r.pop("pass_")
    return dict(group=group, runs=len(runs), rows=rows, findings=findings[:40],
                login_failures=login_failures[:25], regressions=regressions[:40])


# ------------------------------------------------------------------ reports (rendered from the DB)
def render_report(run):
    rows, logins = [], []
    colors = {"PASS": "#15803d", "FAIL": "#b91c1c", "SKIP": "#b45309", "OK": "#15803d"}
    esc = lambda v: html.escape(str(v if v is not None else ""))
    link = lambda mid, label: f'<a href="/media/{mid}" target="_blank">{label}</a>' if mid else "-"
    for l in db.run_logins_for_export(run["id"]):
        logins.append(f"<tr><td>{esc(l['username'])}</td><td>{esc(l['role'])}</td><td style='color:{colors.get(l['status'], '#000')};"
                      f"font-weight:700'>{esc(l['status'])}</td><td>{esc(l['detail'])}</td><td>{link(l['shot_id'], 'Screenshot')}</td>"
                      f"<td>{link(l['video_id'], 'Watch')}</td></tr>")
    for r in db.run_rows_for_export(run["id"]):
        fnd = "<br>".join(f"<b>{esc(f.get('severity'))}</b> {esc(f.get('title'))}" for f in r["findings"] or [])
        rows.append(f"<tr><td>{esc(r['test_case_id'])}</td><td>{esc(r['username'])}</td><td>{esc(r['role'])}</td>"
                    f"<td>{esc(r['name'])}</td><td>{esc(r['data'])}</td><td>{esc(r['expected'])}</td>"
                    f"<td style='color:{colors.get(r['status'], '#000')};font-weight:700'>{esc(r['status'])}</td>"
                    f"<td>{esc(r['detail'])}{('<br>' + fnd) if fnd else ''}</td><td>{link(r['shot_id'], 'Screenshot')}</td>"
                    f"<td>{link(r['video_id'], 'Watch')}</td></tr>")
    counts = {s: sum(1 for r in run["results"].values() if r["status"] == s) for s in ("PASS", "FAIL", "SKIP")}
    login_html = ("<h3>Sign-in per user</h3><table><tr><th>User</th><th>Role</th><th>Login</th><th>Details</th>"
                  f"<th>Screenshot</th><th>Video</th></tr>{''.join(logins)}</table>") if logins else ""
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Test report {run['id']}</title>
<style>body{{font-family:system-ui,Arial,sans-serif;margin:28px;color:#0f172a}}table{{border-collapse:collapse;width:100%;margin-bottom:24px}}
td,th{{border:1px solid #e2e8f0;padding:9px;text-align:left;vertical-align:top;font-size:14px}}th{{background:#0f172a;color:#fff}}
tr:nth-child(even){{background:#f8fafc}}h2{{margin:0 0 4px}}</style></head><body>
<h2>APEX Test Studio - run {esc(run['id'])}</h2><p>{esc(run.get('application_name') or '')} | {esc(run.get('suite_name') or run.get('filename'))} |
{len(run.get('users') or [])} user(s) | Total {len(run['results'])} | PASS {counts['PASS']} | FAIL {counts['FAIL']} | SKIP {counts['SKIP']}</p>
{login_html}<h3>Results</h3>
<table><tr><th>ID</th><th>User</th><th>Role</th><th>Test case</th><th>Sample</th><th>Expected</th><th>Status</th><th>Actual / details</th><th>Screenshot</th><th>Video</th></tr>
{''.join(rows)}</table></body></html>"""


def render_csv(run_id):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["test_case_id", "username", "role", "name", "test_key", "data", "expected", "status", "detail", "secs", "findings"])
    for r in db.run_rows_for_export(run_id):
        w.writerow([r["test_case_id"], r["username"], r["role"], r["name"], r["test_key"], r["data"], r["expected"],
                    r["status"], r["detail"], r["secs"], "; ".join(f"{f.get('severity')}: {f.get('title')}" for f in r["findings"] or [])])
    for l in db.run_logins_for_export(run_id):
        w.writerow(["LOGIN", l["username"], l["role"], "Sign in", "", "", "", l["status"], l["detail"], l["secs"],
                    "; ".join(f"{f.get('severity')}: {f.get('title')}" for f in l["findings"] or [])])
    return ("﻿" + buf.getvalue()).encode("utf-8")


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def send_json(self, obj, status=200):
        body = json.dumps(obj, default=_json_default).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, extra=None):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def error(self, status, msg):
        self.send_json({"error": msg}, status)

    def do_OPTIONS(self):
        self.send_response(204)
        for k, v in (("Access-Control-Allow-Origin", "*"), ("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS"),
                     ("Access-Control-Allow-Headers", "Content-Type"), ("Content-Length", "0")):
            self.send_header(k, v)
        self.end_headers()

    def read_body(self):
        return self.rfile.read(int(self.headers.get("Content-Length") or 0))

    def body(self):
        try:
            return json.loads(self.read_body() or b"{}")
        except json.JSONDecodeError:
            raise ApiError(400, "Invalid JSON body.")

    def dispatch(self, method, path, qs):
        """Returns (obj, status) or None when nothing matched."""
        def m(pattern):
            return re.fullmatch(pattern, path)

        # ---- applications
        if path == "/api/applications":
            if method == "GET":
                return db.list_applications()
            if method == "POST":
                return self.save_app(None)
        if method == "POST" and path == "/api/applications/test":
            return check_url(str(self.body().get("base_url") or "").strip())
        if (r := m(r"/api/applications/(\d+)")):
            app_id = int(r.group(1))
            if method == "PUT":
                return self.save_app(app_id)
            if method == "DELETE":
                if db.q1("select 1 as x from ats_runs where status='running' and application_id=%s", (app_id,)):
                    raise ApiError(409, "A run for this application is in progress. Wait for it to finish.")
                if len(db.list_applications()) <= 1:
                    raise ApiError(409, "You need at least one application. Create another one before deleting this one.")
                if not db.delete_application(app_id):
                    raise ApiError(404, "Application not found.")
                return {"deleted": 1}
        if method == "POST" and (r := m(r"/api/applications/(\d+)/inspect")):
            app = self.app_or_404(int(r.group(1)))
            b = self.body()
            if DEMO:
                return dict(ok=True, title="Demo page", page_id="4", items=[{"id": "P4_HOURS", "label": "Hours", "type": "text"}],
                            buttons=[{"id": "B1", "text": "Save"}], links=[], regions=["Timesheet"],
                            pages=[{"ref": "timesheet", "text": "Timesheet"}])
            return inspect_page(app, str(b.get("page") or "").strip(), b.get("user_id"), bool(b.get("headless", True)))

        # ---- test users
        if (r := m(r"/api/applications/(\d+)/users")):
            app = self.app_or_404(int(r.group(1)))
            if method == "GET":
                return [user_desc(u) for u in db.list_users(app["id"])]
            if method == "POST":
                return save_user(app["id"], None, self.body())
        if (r := m(r"/api/users/(\d+)")):
            uid = int(r.group(1))
            if method == "PUT":
                return save_user(None, uid, self.body())
            if method == "DELETE":
                u = db.get_user(uid)
                if not u:
                    raise ApiError(404, "Test user not found.")
                db.delete_user(uid)
                vault.delete(u["credential_ref"])
                return {"deleted": 1}
        if method == "POST" and (r := m(r"/api/users/(\d+)/test-login")):
            return self.test_login(int(r.group(1)), self.body())

        # ---- suites
        if (r := m(r"/api/applications/(\d+)/suites")):
            app = self.app_or_404(int(r.group(1)))
            if method == "GET":
                return db.list_suites(app["id"])
            if method == "POST":
                return self.save_suite(app["id"], None)
        if (r := m(r"/api/suites/(\d+)")):
            sid = int(r.group(1))
            if method == "PUT":
                s = db.get_suite(sid)
                if not s:
                    raise ApiError(404, "Suite not found.")
                return self.save_suite(s["application_id"], sid)
            if method == "DELETE":
                return {"deleted": db.delete_suite(sid)}

        # ---- reusable functions
        if (r := m(r"/api/applications/(\d+)/functions")):
            app = self.app_or_404(int(r.group(1)))
            if method == "GET":
                return [function_desc(f) for f in db.list_functions(app["id"])]
            if method == "POST":
                return self.save_function(app["id"], None)
        if (r := m(r"/api/functions/(\d+)")):
            fid = int(r.group(1))
            if method == "PUT":
                f = db.get_function(fid)
                if not f:
                    raise ApiError(404, "Function not found.")
                return self.save_function(f["application_id"], fid)
            if method == "DELETE":
                return {"deleted": db.delete_function(fid)}

        # ---- custom tests
        if path == "/api/custom":
            if method == "GET":
                return [custom_desc(r) for r in db.list_custom(self.app_filter(qs))]
            if method == "POST":
                return self.save_custom(None)
        if (r := m(r"/api/custom/(\d+)")):
            if method == "PUT":
                return self.save_custom(int(r.group(1)))
            if method == "DELETE":
                db.delete_custom(int(r.group(1)))
                return {"deleted": 1}

        # ---- AI
        if method == "POST" and path == "/api/ai/generate":
            b = self.body()
            app = self.app_or_404(b.get("application_id"))
            prompt = str(b.get("prompt") or "").strip()
            if len(prompt) < 6:
                raise ApiError(400, "Describe the test in a sentence or two.")
            page_info = None
            if b.get("inspect") and not DEMO:
                page_info = inspect_page(app, str(b.get("page") or "").strip(), b.get("user_id"))
                if page_info and not page_info.get("ok"):
                    raise ApiError(400, "Could not read the page: " + str(page_info.get("error")))
            fns = [function_desc(f) for f in db.list_functions(app["id"])]
            roles = [u["role"] for u in db.list_users(app["id"]) if u["role"]]
            out = ai_generate(app, prompt, page_info, fns, roles)
            if page_info:
                out["page_info"] = {k: page_info.get(k) for k in ("title", "items", "buttons", "pages")}
            return out

        # ---- runs
        if path == "/api/runs":
            if method == "POST":
                return start_run(self.body())
            if method == "GET":
                return db.list_runs(application_id=self.app_filter(qs))
        if method == "DELETE" and (r := m(r"/api/runs/([\w-]+)")):
            n = db.delete_run(r.group(1))
            if not n:
                raise ApiError(409, "Run not found or still running.")
            return {"deleted": n}

        # ---- misc GET
        if method == "GET":
            if path == "/api/config":
                info = dict(demo=DEMO, default_base_url=os.environ.get("APEX_BASE", ""), db=None, db_error=None,
                            ai=bool(os.environ.get("ANTHROPIC_API_KEY", "").strip()), ai_model=AI_MODEL,
                            secret_key=("env" if os.environ.get("ATS_SECRET_KEY") else
                                        "file" if vault.KEY_FILE.is_file() else "not created yet"),
                            auth_types=list(AUTH_TYPES), environments=list(ENVIRONMENTS),
                            steps=runner.STEP_LABELS, assert_subjects=runner.ASSERT_SUBJECTS, assert_ops=runner.ASSERT_OPS,
                            login_fields=list(runner.LOGIN_DEFAULTS))
                try:
                    info["db"] = {**db.ping(), **db.storage()}
                except Exception as exc:
                    info["db_error"] = first_line(exc, 200)
                return info
            if path == "/api/settings":
                return db.get_settings()
            if path == "/api/uploads":
                return db.list_uploads(application_id=self.app_filter(qs))
            if (r := m(r"/api/uploads/([\w-]+)")):
                up = db.get_upload(r.group(1))
                if not up:
                    raise ApiError(404, "Unknown workbook")
                return dict(upload_id=up["id"], filename=up["filename"], cases=up["cases"],
                            unsupported=[c["id"] for c in up["cases"] if not c.get("implemented")])
            if path == "/api/analytics":
                return db.analytics(self.app_filter(qs))
            if path == "/api/dashboard":
                group = (qs.get("group") or ["user"])[0]
                if group not in ("application", "user", "role", "case"):
                    raise ApiError(400, "group must be application, user, role or case")
                return dashboard(self.app_filter(qs), group)
        if method == "PUT" and path == "/api/settings":
            db.save_settings(self.body())
            return {"ok": True}
        return None

    def app_filter(self, qs):
        v = (qs.get("application_id") or [""])[0]
        return int(v) if v.isdigit() else None

    def app_or_404(self, app_id):
        try:
            app = db.get_application(int(app_id))
        except (TypeError, ValueError):
            app = None
        if not app:
            raise ApiError(404, "Application not found.")
        return app

    def save_app(self, app_id):
        try:
            name, url, env, auth, desc, lc, home = clean_app(self.body())
        except ValueError as exc:
            raise ApiError(400, str(exc))
        try:
            new_id = db.save_application(app_id, name, url, env, auth, desc, lc, home)
        except psycopg.errors.UniqueViolation:
            raise ApiError(409, f"An application named '{name}' already exists.")
        if not new_id:
            raise ApiError(404, "Application not found.")
        return next(a for a in db.list_applications() if a["id"] == new_id)

    def save_custom(self, cid):
        body = self.body()
        app_id = None
        if not cid:                                      # a new test belongs to the application it was created in
            try:
                app_id = int(body.get("application_id"))
            except (TypeError, ValueError):
                raise ApiError(400, "Choose an application first.")
            if not db.get_application(app_id):
                raise ApiError(404, "Application not found.")
        else:
            row = db.q1("select application_id from ats_custom_tests where id=%s", (cid,))
            if not row:
                raise ApiError(404, "Test not found.")
            app_id = row["application_id"]
        try:
            name, expected, key, params, steps, run_as = clean_custom(body, app_id)
        except ValueError as exc:
            raise ApiError(400, str(exc))
        new_id = db.save_custom(cid, name, expected, key, params, steps, app_id, run_as)
        if not new_id:
            raise ApiError(404, "Test not found.")
        return custom_desc(next(r for r in db.list_custom() if r["id"] == new_id))

    def save_suite(self, app_id, sid):
        name, desc, upload_id, case_ids, user_ids = clean_suite(self.body(), app_id)
        try:
            new_id = db.save_suite(sid, app_id, name, desc, upload_id, case_ids, user_ids)
        except psycopg.errors.UniqueViolation:
            raise ApiError(409, f"A suite named '{name}' already exists.")
        return db.get_suite(new_id)

    def save_function(self, app_id, fid):
        name, desc, params, steps = clean_function(self.body())
        try:
            new_id = db.save_function(fid, app_id, name, desc, params, steps)
        except psycopg.errors.UniqueViolation:
            raise ApiError(409, f"A function named '{name}' already exists.")
        return function_desc(db.get_function(new_id))

    def test_login(self, uid, body):
        u = db.get_user(uid)
        if not u:
            raise ApiError(404, "Test user not found.")
        app = self.app_or_404(u["application_id"])
        if app["auth_type"] != "apex_login":
            raise ApiError(400, "This application does not use automatic login (see its Authentication setting).")
        if DEMO:
            ok = not re.search(r"bad|locked|wrong", u["username"], re.I)
            detail = f"Signed in as {u['username'].upper()} in 1.2 s (demo)" if ok else "Login rejected: Invalid Login Credentials (demo)"
            db.record_login(uid, "OK" if ok else "FAIL", detail)
            return dict(ok=ok, detail=detail, secs=1.2, logout="Signed out (demo)", findings=[], shot=None)
        try:
            pw = vault.resolve(u["credential_ref"])
        except vault.CredentialError as exc:
            db.record_login(uid, "FAIL", str(exc))
            raise ApiError(400, str(exc))
        try:
            res = with_browser_lock(lambda: runner.try_login(app["base_url"], app_runtime(app), run_user_of(u), pw,
                                                             bool(body.get("headless", True))))
        finally:
            pw = None
        db.record_login(uid, "OK" if res["ok"] else "FAIL", res["detail"])
        shot = res.pop("shot", None)
        res["shot"] = ("data:image/png;base64," + base64.b64encode(shot).decode()) if shot else None
        return res

    def route(self, method):
        url = urlparse(self.path)
        path = unquote(url.path)
        qs = parse_qs(url.query)
        try:
            if method == "POST" and path == "/api/upload":
                return self.upload(qs.get("filename", ["tests.xlsx"])[0], qs.get("application_id", [""])[0])
            if method == "GET":
                rm = re.fullmatch(r"/api/runs/([\w-]+)(?:/(report|csv))?", path)
                if rm:
                    return self.get_run(rm.group(1), rm.group(2))
                mm = re.fullmatch(r"/media/(\d+)", path)
                if mm:
                    return self.serve_media(int(mm.group(1)))
            res = self.dispatch(method, path, qs)
            if res is not None:
                return self.send_json(res)
        except ApiError as exc:
            return self.error(exc.status, str(exc))
        except vault.CredentialError as exc:
            return self.error(400, str(exc))
        except Exception as exc:
            traceback.print_exc()
            return self.error(500, first_line(exc))
        if method == "GET" and not path.startswith("/api/"):
            if DIST.exists():
                return self.serve_file(DIST, path.lstrip("/") or "index.html", spa=True)
            return self.error(404, "Frontend not built yet. Run 'npm run build' in /frontend (or 'npm run dev').")
        self.error(404, "Not found")

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def get_run(self, run_id, kind):
        run = db.get_run(run_id)
        if not run:
            return self.error(404, "Unknown run")
        if kind == "report":
            return self.send_bytes(render_report(run).encode("utf-8"), "text/html; charset=utf-8")
        if kind == "csv":
            return self.send_bytes(render_csv(run["id"]), "text/csv; charset=utf-8",
                                   {"Content-Disposition": f'attachment; filename="run_{run["id"]}.csv"'})
        return self.send_json(run)

    def upload(self, filename, application_id=""):
        data = self.read_body()
        if not (application_id.isdigit() and db.get_application(int(application_id))):
            return self.error(400, "Choose an application before uploading a workbook.")
        if not filename.lower().endswith((".xlsx", ".xlsm")):
            return self.error(400, "Please upload an Excel workbook (.xlsx).")
        app = db.get_application(int(application_id))
        try:
            with RUN_LOCK:
                runner.configure(app["base_url"], app_runtime(app), [function_desc(f) for f in db.list_functions(app["id"])])
                cases = with_temp_xlsx(data, describe_cases)
        except Exception as exc:
            return self.error(400, f"Could not read the workbook: {exc}")
        if not cases:
            return self.error(400, "No enabled test cases found. Set ENABLED = Y in the Test_Cases sheet.")
        upload_id = db.save_upload(filename, data, cases, int(application_id))
        self.send_json(dict(upload_id=upload_id, filename=filename, cases=cases,
                            unsupported=[c["id"] for c in cases if not c["implemented"]]))

    def serve_media(self, media_id):
        info = db.media_info(media_id)
        if not info:
            return self.error(404, "Not found")
        size = info["size_bytes"] or 0
        start, end, status = 0, size - 1, 200
        rng = re.fullmatch(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if rng and (rng.group(1) or rng.group(2)):
            if rng.group(1):
                start = int(rng.group(1))
                end = int(rng.group(2)) if rng.group(2) else size - 1
            else:
                start = max(0, size - int(rng.group(2)))
            end = min(end, size - 1)
            if start > end:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                return self.end_headers()
            status = 206
        self.send_response(status)
        self.send_header("Content-Type", info["mime"] or "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "private, max-age=3600")
        self.send_header("Content-Disposition", f'inline; filename="{info["filename"]}"')
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        try:
            pos, left = start, end - start + 1
            while left > 0:                                    # stream in 1 MB pieces straight from PostgreSQL
                chunk = db.media_slice(media_id, pos, min(1 << 20, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                pos += len(chunk)
                left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def serve_file(self, base, rel, spa=False):
        f = (base / rel).resolve()
        if base.resolve() not in f.parents and f != base.resolve():
            return self.error(403, "Forbidden")
        if not f.is_file():
            if spa and not Path(rel).suffix:
                f = base / "index.html"
            else:
                return self.error(404, "Not found")
        self.send_bytes(f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream")


if __name__ == "__main__":
    if not db.configured():
        raise SystemExit("DATABASE_URL is missing. Create backend/.env from .env.example (PostgreSQL connection string).")
    print("Connecting to PostgreSQL ...")
    db.init()
    print("Database ready:", db.ping()["database"])
    print(f"APEX Test Studio on http://localhost:{PORT}" + ("  [DEMO MODE - simulated results]" if DEMO else ""))
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
