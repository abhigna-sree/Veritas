"""Secret store for test-user passwords.  Passwords are NEVER stored in plaintext and never leave the backend.

A test user (table ats_test_users) only keeps a *credential reference*:

  env:NAME     the password is the environment variable NAME - put it in backend/.env (git-ignored) or in the
               real environment / your CI secret store. Nothing about the password is in the database.
  vault:<id>   the password was typed once in the UI. It is encrypted with Fernet (AES-128-CBC + HMAC-SHA256)
               and only the ciphertext is kept, in table ats_secrets. The key is NOT in the database:
               it is ATS_SECRET_KEY in backend/.env, or the file backend/.ats_secret_key that is created
               (owner-only permissions) the first time a password is saved.

The API can only *set* a password or ask whether a reference resolves; there is no endpoint that returns one.
The runner asks for the password just before typing it into the login form and does not keep it.
"""
import hashlib
import os
import re
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

import db

KEY_FILE = Path(__file__).resolve().parent / ".ats_secret_key"
ENV_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,120}$")
_fernet = None


class CredentialError(Exception):
    """The reference is missing, malformed, or cannot be decrypted."""


# ------------------------------------------------------------------ key handling
def _load_key():
    k = os.environ.get("ATS_SECRET_KEY", "").strip()
    if k:
        return k.encode()
    if KEY_FILE.is_file():
        return KEY_FILE.read_text(encoding="utf-8").strip().encode()
    key = Fernet.generate_key()
    fd = os.open(str(KEY_FILE), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)   # owner read/write only
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key.decode())
    return key


def _f():
    global _fernet
    if _fernet is None:
        try:
            _fernet = Fernet(_load_key())
        except ValueError:
            raise CredentialError("ATS_SECRET_KEY is not a valid key. Generate one with: "
                                  "python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\"")
    return _fernet


def _key_id():
    """Short fingerprint of the key, stored next to each secret so a key change is detected (never the key itself)."""
    return hashlib.sha256(_load_key()).hexdigest()[:12]


# ------------------------------------------------------------------ references
def parse(ref):
    ref = str(ref or "").strip()
    if ref.startswith("env:"):
        name = ref[4:].strip()
        if not ENV_NAME.match(name):
            raise CredentialError("Environment variable names may only use letters, digits and _ (e.g. ATS_PW_MANAGER).")
        return "env", name
    if ref.startswith("vault:") and ref[6:].isdigit():
        return "vault", int(ref[6:])
    if not ref:
        raise CredentialError("No password has been set for this user.")
    raise CredentialError("Unknown credential reference. Use env:NAME or save the password in the vault.")


def store(plaintext, label="", ref=None):
    """Encrypt and save a password typed in the UI. Re-uses the user's existing vault entry when there is one."""
    if not plaintext:
        raise CredentialError("Password is empty.")
    token = _f().encrypt(plaintext.encode("utf-8")).decode()
    kid = _key_id()
    if ref and str(ref).startswith("vault:") and str(ref)[6:].isdigit():
        row = db.q1("update ats_secrets set token=%s, key_id=%s, label=%s, updated_at=now() where id=%s returning id",
                    (token, kid, label, int(str(ref)[6:])))
        if row:
            return f"vault:{row['id']}"
    row = db.q1("insert into ats_secrets(label, token, key_id) values (%s,%s,%s) returning id", (label, token, kid))
    return f"vault:{row['id']}"


def resolve(ref):
    """Plaintext password for a reference. Only the runner calls this, right before logging in."""
    kind, val = parse(ref)
    if kind == "env":
        pw = os.environ.get(val)
        if not pw:
            raise CredentialError(f"Environment variable {val} is not set. Add it to backend/.env and restart the server.")
        return pw
    row = db.q1("select token, key_id from ats_secrets where id=%s", (val,))
    if not row:
        raise CredentialError("The saved password was removed. Enter it again.")
    try:
        return _f().decrypt(row["token"].encode()).decode("utf-8")
    except InvalidToken:
        raise CredentialError("The saved password was encrypted with a different key (ATS_SECRET_KEY changed). Enter it again.")


def status(ref):
    """What the UI may know: whether the reference works - never the value."""
    try:
        kind, val = parse(ref)
    except CredentialError as exc:
        return dict(ok=False, kind=None, note=str(exc))
    if kind == "env":
        ok = bool(os.environ.get(val))
        return dict(ok=ok, kind="env", name=val,
                    note=f"From environment variable {val}" if ok else f"{val} is not set in backend/.env")
    row = db.q1("select key_id, updated_at from ats_secrets where id=%s", (val,))
    if not row:
        return dict(ok=False, kind="vault", note="Saved password was removed - enter it again")
    try:
        same_key = row["key_id"] == _key_id()
    except Exception:
        same_key = False
    return dict(ok=same_key, kind="vault", updated_at=row["updated_at"],
                note="Encrypted in the secret store" if same_key else "Encrypted with an old key - enter it again")


def delete(ref):
    try:
        kind, val = parse(ref)
    except CredentialError:
        return
    if kind == "vault":
        db.x("delete from ats_secrets where id=%s", (val,))
