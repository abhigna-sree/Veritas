import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as api from "./api.js";

const DEFAULTS = { activeAppId: null, cdpUrl: "http://127.0.0.1:9222", allowSave: false, headless: false, slowMo: 60, theme: "dark", groupBy: "user" };
const ENV_LABEL = { development: "Development", test: "Test", staging: "Staging", production: "Production" };
const AUTH_LABEL = { apex_login: "Automatic login", chrome_session: "Logged-in Chrome (legacy)", none: "No login (public)" };
const BLANK_APP = { id: null, name: "", base_url: "", environment: "test", auth_type: "apex_login", description: "", home_page: "", login_config: {} };
const FILTERS = [["all", "All"], ["PASS", "Passed"], ["FAIL", "Failed"], ["SKIP", "Skipped"], ["REG", "Regressions"], ["SEC", "Findings"]];
const GROUPS = [["user", "By user"], ["role", "By role"], ["case", "By test case"], ["matrix", "Matrix"]];
const LOGIN_FIELDS = [
  ["login_page", "Login page", "auto - the app sends you there (alias, number or URL)"],
  ["username_selector", "Username field", "auto - #P9999_USERNAME, email or username inputs"],
  ["password_selector", "Password field", "auto - #P9999_PASSWORD or the password input"],
  ["submit_selector", "Sign-in button", "auto - Sign In / Log In / Login / Continue"],
  ["next_selector", "Next button (two-step forms)", "auto - used when the password appears after the username"],
  ["success_selector", "Signed-in check (selector)", "optional - an element only signed-in users see"],
  ["success_url", "Signed-in check (URL contains)", "optional - e.g. /home"],
  ["logout_url", "Sign-out URL", "auto - the app's Sign Out link"],
];

/* what a user can pick when creating a test */
const ACTIONS = [
  { k: "open", label: "Open page", t: "Page alias, number or URL (blank = home)", tph: "timesheet" },
  { k: "click", label: "Click", t: "Button, link, text or #selector", tph: "Save" },
  { k: "type", label: "Type into field", t: "Field label or #ITEM", tph: "Hours", v: "Text to type", vph: "8 or {{username}}" },
  { k: "choose", label: "Choose option", t: "Field label or #ITEM", v: "Option text" },
  { k: "set_item", label: "Set APEX item", t: "Item name", tph: "P4_HOURS", v: "Value" },
  { k: "press", label: "Press key", v: "Key", vph: "Enter" },
  { k: "wait", label: "Wait (seconds)", v: "Seconds", vph: "2" },
  { k: "wait_for", label: "Wait for text", t: "Text that must appear", v: "Max seconds", vph: "15" },
  { k: "see", label: "Expect to see text", t: "Text that must be visible", tph: "Hours cannot be more than 24" },
  { k: "not_see", label: "Expect NOT to see text", t: "Text that must not be visible" },
  { k: "url", label: "Expect URL to contain", v: "Text", vph: "timesheet" },
  { k: "assert", label: "Check (assertion)" },
  { k: "call", label: "Use function" },
  { k: "open_week", label: "Go to week (Timesheet)", v: "Week offset", vph: "0 = this week, -1 = last week" },
];
const SUBJECTS = [["text", "Page text"], ["element_text", "Text of element"], ["value", "Value of field"], ["item", "APEX item value"], ["url", "Page URL"],
  ["title", "Page title"], ["count", "Number of elements"], ["alert", "Message shown"], ["visible", "Element is visible"], ["hidden", "Element is hidden"],
  ["enabled", "Element is enabled"], ["disabled", "Element is disabled"], ["editable", "Field is editable"], ["readonly", "Field is read-only"]];
const STATE_SUBJ = new Set(["visible", "hidden", "enabled", "disabled", "editable", "readonly"]);
const NO_TARGET = new Set(["text", "url", "title", "alert"]);
const OPS = [["equals", "equals"], ["not_equals", "does not equal"], ["contains", "contains"], ["not_contains", "does not contain"], ["starts_with", "starts with"],
  ["matches", "matches regex"], ["gt", ">"], ["ge", "≥"], ["lt", "<"], ["le", "≤"], ["empty", "is empty"], ["not_empty", "is not empty"]];
const GENERIC = [
  { key: "PAGE_SMOKE", label: "Page opens without errors", fields: [{ k: "page", label: "Page alias or number (blank = home)", ph: "home" }, { k: "expect_text", label: "Text that must be visible (optional)", ph: "Welcome" }] },
  { key: "PAGE_ACCESS", label: "Role-based page access", note: "Runs for every selected user: allowed roles must get in, everyone else must be blocked. A blocked role that gets in is reported as a security finding.",
    fields: [{ k: "page", label: "Page alias or number", ph: "admin" }, { k: "allowed", label: "Roles or usernames allowed (comma separated, * = everyone)", ph: "ADMIN, MANAGER" }] },
  { key: "REQUIRES_LOGIN", label: "Page needs a login", note: "Opens the page in a fresh browser with no session: it must send the visitor to the login page.", fields: [{ k: "page", label: "Page alias or number", ph: "timesheet" }] },
  { key: "URL_TAMPERING", label: "Item cannot be changed from the URL", note: "Passes the value in the URL: APEX must reject it (Session State Protection) or ignore it.",
    fields: [{ k: "page", label: "Page alias or number", ph: "timesheet" }, { k: "item", label: "APEX item", ph: "P4_EMPLOYEE_ID" }, { k: "data", label: "Value to inject", ph: "1" }] },
];
const BUILTIN = [
  { key: "HOURS_ABOVE_24", label: "Hours above 24 are rejected", fields: [{ k: "data", label: "Hours to try", ph: "25" }] },
  { key: "NEGATIVE_HOURS", label: "Negative hours are rejected", fields: [{ k: "data", label: "Value to try", ph: "-1" }] },
  { key: "FUTURE_DATE_READONLY", label: "Future dates are read-only", fields: [{ k: "date_offset", label: "Days after today", ph: "1" }] },
  { key: "OLD_WEEK_READONLY", label: "Old weeks are read-only", fields: [{ k: "week_offset", label: "Week offset (-3 = three weeks back)", ph: "-3" }] },
  { key: "OLD_WEEK_BOUNDARY_EDITABLE", label: "Oldest allowed week is editable", fields: [{ k: "week_offset", label: "Week offset", ph: "-2" }] },
  { key: "WEEKEND_READONLY", label: "Weekend days are read-only", fields: [{ k: "day", label: "Day", options: ["Sat", "Sun"] }, { k: "week_offset", label: "Week offset", ph: "-1" }] },
  { key: "HOLIDAY_READONLY", label: "Holiday cell is not editable", fields: [{ k: "data", label: "Holiday date (optional, DD-Mon-YYYY)", ph: "02-Oct-2026" }] },
  { key: "ASSIGNED_ACTIVE_PROJECTS_ONLY", label: "Unassigned project is not selectable", fields: [{ k: "data", label: "Project that must NOT appear", ph: "Project name" }] },
  { key: "CROSS_EMPLOYEE_ACCESS_DENIED", label: "Another employee's data is not reachable", fields: [{ k: "data", label: "Other employee id", ph: "1" }] },
  { key: "OVERTIME_REQUIRES_APPROVAL", label: "Overtime needs approval", saves: true, fields: [{ k: "data", label: "Hours to save", ph: "9" }] },
  { key: "NORMAL_HOURS_APPROVED", label: "Normal hours are auto-approved", saves: true, fields: [{ k: "data", label: "Hours to save", ph: "8" }] },
  { key: "WEEKLY_LIMIT", label: "Weekly total above the limit is rejected", saves: true, fields: [{ k: "data", label: "Total hours to try", ph: "49" }] },
];
const ALL_CHECKS = [...GENERIC, ...BUILTIN];

/* ------------------------------------------------------------------ helpers */
function useCountUp(target, ms = 500) {
  const [v, setV] = useState(0);
  const from = useRef(0);
  useEffect(() => {
    const start = performance.now(), a = from.current;
    let raf;
    const tick = (t) => {
      const p = Math.min((t - start) / ms, 1);
      setV(Math.round(a + (target - a) * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick); else from.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}
const fmtDate = (s) => (s ? new Date(s).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "");
const pctOf = (r) => (r.total ? Math.round((r.pass / r.total) * 100) : 0);
const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
const initials = (s) => String(s || "?").replace(/[^A-Za-z0-9 ]/g, " ").trim().split(/\s+/).slice(0, 2).map((x) => x[0]).join("").toUpperCase() || "?";
const isReg = (r) => r?.status === "FAIL" && r?.prev_status === "PASS";
const isFixed = (r) => r?.status === "PASS" && r?.prev_status === "FAIL";

/* same rule as runner.applies(): a test with no "run as" list runs for every user */
function applies(c, u) {
  const toks = (c.run_as || []).map((t) => String(t).toLowerCase());
  if (!u || !toks.length || toks.some((t) => ["*", "all", "everyone"].includes(t))) return true;
  return toks.includes(String(u.role || "").toLowerCase()) || toks.includes(String(u.username || "").toLowerCase()) || toks.includes(String(u.id));
}

const P = {
  upload: <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12" />,
  play: <path d="M7 4.5v15l12-7.5z" fill="currentColor" stroke="none" />,
  db: <><ellipse cx="12" cy="5" rx="8" ry="3" /><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
  moon: <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />,
  x: <path d="M18 6L6 18M6 6l12 12" />,
  trash: <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" />,
  film: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" /></>,
  plus: <path d="M12 5v14M5 12h14" />,
  edit: <path d="M4 20h4L19 9l-4-4L4 16zM14 6l4 4" />,
  up: <path d="M12 19V5M5 12l7-7 7 7" />,
  down: <path d="M12 5v14M5 12l7 7 7-7" />,
  back: <path d="M19 12H5M12 19l-7-7 7-7" />,
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" /></>,
  plug: <path d="M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0zM12 18v4" />,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></>,
  users: <><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c1.2-3.4 3.6-5 6.5-5s5.3 1.6 6.5 5M16 4.5a3.5 3.5 0 0 1 0 7M18 15c1.8.6 3 2.2 3.5 5" /></>,
  lock: <><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></>,
  key: <><circle cx="8" cy="15" r="4" /><path d="M11 12l9-9M17 6l3 3M15 8l2 2" /></>,
  shield: <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" />,
  spark: <path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" />,
  layers: <path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5" />,
  fn: <path d="M9 20c2 0 3-1.5 3.5-4L14 8c.5-2.5 1.5-4 3.5-4M8 11h9" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" /></>,
  check: <path d="M5 12.5l4.5 4.5L19 7.5" />,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" /></>,
};
const Svg = ({ name, size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>{P[name]}</svg>
);

/* ------------------------------------------------------------------ app */
export default function App() {
  const [tab, setTab] = useState("studio");
  const [config, setConfig] = useState({ demo: false, db: null, db_error: null });
  const [settings, setSettings] = useState(DEFAULTS);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [apps, setApps] = useState(null);                         // null = still loading
  const [manageId, setManageId] = useState(null);                 // Applications tab: the app being managed
  const [showSettings, setShowSettings] = useState(false);
  const [upload, setUpload] = useState(null);
  const [custom, setCustom] = useState([]);
  const [recent, setRecent] = useState([]);
  const [users, setUsers] = useState([]);
  const [suites, setSuites] = useState([]);
  const [functions, setFunctions] = useState([]);
  const [skip, setSkip] = useState(() => new Set());           // test ids the user un-ticked
  const [userSkip, setUserSkip] = useState(() => new Set());   // test-user ids the user un-ticked
  const [activeSuite, setActiveSuite] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [run, setRun] = useState(null);
  const [filter, setFilter] = useState("all");
  const [watch, setWatch] = useState(null);
  const [media, setMedia] = useState(null);
  const [builder, setBuilder] = useState(null);
  const [fnForm, setFnForm] = useState(null);
  const [suiteName, setSuiteName] = useState(null);
  const [toasts, setToasts] = useState([]);
  const fileInput = useRef(null);

  const notify = useCallback((msg, kind = "ok") => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === "err" ? 7000 : 3500);
  }, []);

  // the application being tested: remembered in the database settings, falls back to the first one
  const activeApp = useMemo(() => apps?.find((a) => a.id === settings.activeAppId) || apps?.[0] || null, [apps, settings.activeAppId]);
  const appId = activeApp?.id;
  const multiUser = activeApp?.auth_type === "apex_login";

  const loadApps = useCallback(() => api.listApps().then(setApps).catch(() => { setApps((a) => a || []); }), []);
  const loadAppData = useCallback((id) => {
    if (!id) return;
    api.listUploads(id).then(setRecent).catch(() => {});
    api.listCustom(id).then(setCustom).catch(() => {});
    api.listUsers(id).then(setUsers).catch(() => {});
    api.listSuites(id).then(setSuites).catch(() => {});
    api.listFunctions(id).then(setFunctions).catch(() => {});
  }, []);

  const refreshMeta = useCallback(() => {
    api.getConfig().then(setConfig).catch(() => notify("Cannot reach the backend. Start it with: python server.py", "err"));
    loadApps();
    loadAppData(appId);
  }, [notify, loadApps, loadAppData, appId]);

  useEffect(() => {
    api.getSettings().catch(() => ({})).then((s) => { setSettings({ ...DEFAULTS, ...s }); setSettingsLoaded(true); });
  }, []);
  useEffect(() => { refreshMeta(); }, [refreshMeta]);

  // switching application starts from a clean Studio (its own tests, users, workbooks and results)
  const prevApp = useRef(undefined);
  useEffect(() => {
    if (prevApp.current !== undefined && appId && prevApp.current !== appId) {
      setUpload(null); setSkip(new Set()); setUserSkip(new Set()); setActiveSuite(null); setRun(null);
      setCustom([]); setRecent([]); setUsers([]); setSuites([]); setFunctions([]);
    }
    if (appId) prevApp.current = appId;
  }, [appId]);

  // settings (including the theme) are stored in PostgreSQL, not in the browser
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
    if (!settingsLoaded) return;
    const t = setTimeout(() => api.saveSettings(settings).catch(() => {}), 600);
    return () => clearTimeout(t);
  }, [settings, settingsLoaded]);

  const runId = run?.id;
  const running = run?.status === "running";
  useEffect(() => {
    if (!runId || !running) return;
    const t = setInterval(() => api.getRun(runId).then(setRun).catch(() => {}), 1500);
    return () => clearInterval(t);
  }, [runId, running]);

  const wasRunning = useRef(false);
  useEffect(() => {
    if (wasRunning.current && run && run.status !== "running") {
      refreshMeta();
      if (run.status === "error") notify(run.error || "The run stopped with an error.", "err");
    }
    wasRunning.current = running;
  }, [running, run, refreshMeta, notify]);

  /* ---- the test library = Excel cases + tests built in the UI */
  const catalog = useMemo(() => [...(upload?.cases || []), ...custom], [upload, custom]);
  const selectedIds = useMemo(() => catalog.filter((c) => !skip.has(c.id)).map((c) => c.id), [catalog, skip]);
  const toggle = (id) => { setActiveSuite(null); setSkip((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; }); };
  const activeUsers = useMemo(() => users.filter((u) => u.enabled), [users]);
  const selectedUsers = useMemo(() => (multiUser ? activeUsers.filter((u) => !userSkip.has(u.id)) : []), [multiUser, activeUsers, userSkip]);
  const missingPw = selectedUsers.filter((u) => !u.credential?.ok);
  const planned = useMemo(() => {
    const sel = catalog.filter((c) => !skip.has(c.id));
    if (!multiUser) return sel.length;
    return selectedUsers.reduce((n, u) => n + sel.filter((c) => applies(c, u)).length, 0);
  }, [catalog, skip, multiUser, selectedUsers]);

  async function handleFile(file) {
    if (!file) return;
    setRun(null);
    if (!appId) { notify("Create an application first (Applications tab).", "err"); return; }
    setUploading(true);
    try { setUpload(await api.uploadExcel(file, appId)); setSkip(new Set()); setActiveSuite(null); refreshMeta(); notify(`${file.name} saved to the database`); }
    catch (e) { setUpload(null); notify(e.message, "err"); }
    finally { setUploading(false); }
  }
  async function pickRecent(id) {
    setRun(null);
    try { setUpload(await api.getUpload(id)); setSkip(new Set()); setActiveSuite(null); } catch (e) { notify(e.message, "err"); }
  }
  async function applySuite(s) {
    let cases = catalog;
    if (s.upload_id && upload?.upload_id !== s.upload_id) {
      try { const up = await api.getUpload(s.upload_id); setUpload(up); cases = [...up.cases, ...custom]; }
      catch (e) { notify(e.message, "err"); }
    }
    const want = new Set(s.case_ids || []);
    setSkip(want.size ? new Set(cases.filter((c) => !want.has(c.id)).map((c) => c.id)) : new Set());
    const wantU = new Set(s.user_ids || []);
    setUserSkip(wantU.size ? new Set(users.filter((u) => !wantU.has(u.id)).map((u) => u.id)) : new Set());
    setActiveSuite(s); setRun(null); setTab("studio");
  }
  async function saveSelectionAsSuite(name) {
    try {
      const s = await api.saveSuite(appId, null, { name, upload_id: upload?.upload_id || null, case_ids: selectedIds,
        user_ids: multiUser && userSkip.size ? selectedUsers.map((u) => u.id) : [] });
      setSuites((l) => [...l, s].sort((a, b) => a.name.localeCompare(b.name))); setActiveSuite(s); setSuiteName(null); notify(`Suite "${s.name}" saved`);
    } catch (e) { notify(e.message, "err"); }
  }
  async function handleRun(ids) {
    const only = ids || selectedIds;
    try {
      const res = await api.startRun({
        application_id: appId, upload_id: upload?.upload_id || null, only, suite_id: ids ? null : activeSuite?.id || null,
        user_ids: multiUser ? selectedUsers.map((u) => u.id) : null, cdp_url: settings.cdpUrl.trim(),
        allow_save: settings.allowSave, headless: settings.headless, slow_mo: Number(settings.slowMo),
      });
      setFilter("all"); setTab("studio");
      setRun({ id: res.run_id, status: "running", cases: res.cases, users: res.users, results: {}, logins: {}, current: null });
    } catch (e) { notify(e.message, "err"); }
  }
  async function openRun(id) {
    try { setRun(await api.getRun(id)); setFilter("all"); setTab("studio"); window.scrollTo({ top: 0 }); }
    catch (e) { notify(e.message, "err"); }
  }
  async function removeCustom(c) {
    try { await api.deleteCustom(c.db_id); setCustom((l) => l.filter((x) => x.id !== c.id)); notify("Test deleted"); }
    catch (e) { notify(e.message, "err"); }
  }
  async function saveBuilder(b, runAfter) {
    const body = { application_id: appId, name: b.name, expected: b.expected, test_key: b.key, params: b.params,
      steps: b.key === "CUSTOM_STEPS" ? b.steps : [], run_as: b.run_as || {} };
    try {
      const saved = await api.saveCustom(b.db_id, body);
      setCustom((l) => (b.db_id ? l.map((x) => (x.db_id === b.db_id ? saved : x)) : [...l, saved]));
      setBuilder(null);
      if (runAfter) { setRun(null); await handleRun([saved.id]); } else notify("Test saved");
    } catch (e) { notify(e.message, "err"); }
  }
  async function saveFn(f) {
    const saved = await api.saveFunction(appId, f.id, { name: f.name, description: f.description, params: f.params, steps: f.steps });
    setFunctions((l) => (f.id ? l.map((x) => (x.id === f.id ? saved : x)) : [...l, saved]).sort((a, b) => a.name.localeCompare(b.name)));
    setFnForm(null); notify(`Function "${saved.name}" saved`);
  }
  const newTest = () => setBuilder({ db_id: null, name: "", expected: "", key: "CUSTOM_STEPS", params: {}, run_as: {},
    steps: [{ action: "open", target: activeApp?.home_page || "", value: "" }] });

  const needsUrl = !config.demo && !/^https?:\/\//.test(activeApp?.base_url || "");
  const usersOk = !multiUser || config.demo || (selectedUsers.length > 0 && missingPw.length === 0);
  const canRun = !!activeApp && selectedIds.length > 0 && planned > 0 && !running && !needsUrl && !config.db_error && usersOk;
  const allSelected = selectedIds.length === catalog.length;
  const roles = useMemo(() => [...new Set(users.map((u) => u.role).filter(Boolean))].sort(), [users]);

  return (
    <>
      <header className="topbar">
        <div className="brand"><span className="logo" />APEX Test Studio{config.demo && <em className="demo-pill">Demo</em>}</div>
        <nav className="tabs">
          <button className={tab === "applications" ? "on" : ""} onClick={() => setTab("applications")}>Applications</button>
          <button className={tab === "studio" ? "on" : ""} onClick={() => setTab("studio")}>Studio</button>
          <button className={tab === "history" ? "on" : ""} onClick={() => setTab("history")}>Dashboard</button>
        </nav>
        <div className="top-right">
          {apps && apps.length > 0 && (
            <label className="app-switch" title={running ? "Wait for the run to finish before switching" : "Application under test"}>
              <Svg name="globe" size={15} />
              <select value={appId || ""} disabled={running} onChange={(e) => { setSettings((s) => ({ ...s, activeAppId: Number(e.target.value) })); setManageId(null); }}>
                {apps.map((a) => <option key={a.id} value={a.id}>{a.name} · {ENV_LABEL[a.environment] || a.environment}</option>)}
              </select>
            </label>
          )}
          <DbChip config={config} />
          <button className="icon-btn" title="Switch theme" aria-label="Switch theme" onClick={() => setSettings((s) => ({ ...s, theme: s.theme === "dark" ? "light" : "dark" }))}>
            <Svg name={settings.theme === "dark" ? "sun" : "moon"} size={17} />
          </button>
        </div>
      </header>

      <main className="shell">
        {config.db_error && (
          <div className="banner err"><b>Database not reachable.</b> {config.db_error}. Check <code>DATABASE_URL</code> in <code>backend/.env</code> and restart the server.</div>
        )}

        {tab === "applications" ? (
          manageId && apps?.some((a) => a.id === manageId) ? (
            <AppDetail app={apps.find((a) => a.id === manageId)} config={config} running={running} notify={notify}
                       onBack={() => setManageId(null)} onReloadApps={loadApps}
                       isActive={manageId === appId} onUse={() => setSettings((s) => ({ ...s, activeAppId: manageId }))}
                       onOpenSuite={(s) => applySuite(s)} onChanged={() => { if (manageId === appId) loadAppData(appId); }} />
          ) : (
            <Applications apps={apps} activeId={appId} running={running} notify={notify} onReload={loadApps}
                          onManage={(id) => setManageId(id)}
                          onUse={(id) => { setSettings((s) => ({ ...s, activeAppId: id })); setTab("studio"); }} />
          )
        ) : tab === "history" ? (
          <Dashboard appId={appId} apps={apps} onOpen={openRun} onChanged={refreshMeta} notify={notify} onMedia={setMedia}
                     groupBy={settings.dashGroup || "user"} setGroupBy={(g) => setSettings((s) => ({ ...s, dashGroup: g }))} />
        ) : apps && apps.length === 0 ? (
          <div className="card empty"><Svg name="globe" size={30} /><p>Register the application you want to test first.</p>
            <button className="run-btn inline" onClick={() => setTab("applications")}>Open Applications</button></div>
        ) : (
          <>
            <section className="hero">
              <div>
                <h1>Automated UI testing</h1>
                <p>Every selected test runs once per test user: sign in, run, save the evidence, sign out - then the next user starts in a clean browser.</p>
                {activeApp && <p className="now-testing"><Svg name="globe" size={14} /> Testing <b>{activeApp.name}</b>
                  <span className={"env-pill " + activeApp.environment}>{ENV_LABEL[activeApp.environment]}</span>
                  <span className={"auth-pill " + activeApp.auth_type}>{AUTH_LABEL[activeApp.auth_type]}</span></p>}
              </div>
              <RunRing run={run} />
            </section>

            <div className="grid">
              <div className="side">
                <section className="card control">
                  <div className="card-head"><h2>Test library</h2>{activeApp && <small className="muted">{activeApp.name}</small>}</div>
                  <div className={"drop" + (dragOver ? " over" : "")}
                       onClick={() => fileInput.current?.click()}
                       onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                       onDragLeave={() => setDragOver(false)}
                       onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files[0]); }}>
                    <span className="drop-ico"><Svg name="upload" size={20} /></span>
                    <strong>{uploading ? "Reading workbook…" : "Drop an Excel file here"}</strong>
                    <span>or click to browse · .xlsx with a Test_Cases sheet</span>
                    <input ref={fileInput} type="file" accept=".xlsx,.xlsm" hidden
                           onChange={(e) => { handleFile(e.target.files[0]); e.target.value = ""; }} />
                  </div>

                  {upload && (
                    <div className="loaded"><span className="tick">✓</span><div><b>{plural(upload.cases.length, "test case")} loaded</b><small>{upload.filename}</small></div></div>
                  )}
                  {upload?.unsupported?.length > 0 && (
                    <div className="banner warn">No automation yet for <b>{upload.unsupported.join(", ")}</b>; they will be marked Skipped.</div>
                  )}
                  {recent.length > 0 && (
                    <div className="recent">
                      <small>Recent workbooks</small>
                      <div>{recent.map((u) => (
                        <button key={u.id} className={"chip" + (upload?.upload_id === u.id ? " on" : "")} onClick={() => pickRecent(u.id)} title={fmtDate(u.created_at)}>
                          {u.filename} <em>{u.n}</em>
                        </button>))}
                      </div>
                    </div>
                  )}
                  {(suites.length > 0 || catalog.length > 0) && (
                    <div className="recent">
                      <small>Suites</small>
                      <div>
                        {suites.map((s) => (
                          <button key={s.id} className={"chip suite" + (activeSuite?.id === s.id ? " on" : "")} onClick={() => applySuite(s)} title={s.description || "Select this suite's tests and users"}>
                            <Svg name="layers" size={12} /> {s.name} <em>{s.case_ids?.length || "all"}</em>
                          </button>))}
                        {catalog.length > 0 && (suiteName === null
                          ? <button className="chip add" onClick={() => setSuiteName("")} disabled={!selectedIds.length}><Svg name="plus" size={12} /> Save selection</button>
                          : <span className="inline-form">
                              <input type="text" autoFocus placeholder="Suite name" value={suiteName} onChange={(e) => setSuiteName(e.target.value)}
                                     onKeyDown={(e) => { if (e.key === "Enter" && suiteName.trim()) saveSelectionAsSuite(suiteName.trim()); if (e.key === "Escape") setSuiteName(null); }} />
                              <button className="mini" disabled={!suiteName.trim()} onClick={() => saveSelectionAsSuite(suiteName.trim())}>Save</button>
                              <button className="mini icon" onClick={() => setSuiteName(null)} aria-label="Cancel"><Svg name="x" size={12} /></button>
                            </span>)}
                      </div>
                    </div>
                  )}

                  <button className="link-btn" onClick={() => setShowSettings((v) => !v)}>{showSettings ? "Hide run settings" : "Run settings"}</button>
                  {showSettings && (
                    <div className="settings">
                      <div className="field"><label>Application under test</label>
                        <div className="app-url"><b>{activeApp?.name}</b><span>{activeApp?.base_url || "no Base URL yet"}</span>
                          <button className="text-btn" onClick={() => { setManageId(appId); setTab("applications"); }}>Change</button></div></div>
                      {activeApp?.auth_type === "chrome_session" && <Field label="Chrome debugging address"><input type="text" value={settings.cdpUrl}
                        onChange={(e) => setSettings({ ...settings, cdpUrl: e.target.value })} /></Field>}
                      <Field label="Speed">
                        <select value={settings.slowMo} onChange={(e) => setSettings({ ...settings, slowMo: Number(e.target.value) })}>
                          <option value={0}>Fastest</option><option value={60}>Normal (easy to follow in the video)</option><option value={200}>Slow</option>
                        </select></Field>
                      <label className="check"><input type="checkbox" checked={settings.allowSave} onChange={(e) => setSettings({ ...settings, allowSave: e.target.checked })} />Allow tests that click Save (test users only)</label>
                      <label className="check"><input type="checkbox" checked={settings.headless} onChange={(e) => setSettings({ ...settings, headless: e.target.checked })} />Run hidden (headless)</label>
                      {activeApp?.auth_type === "chrome_session" && <p className="note">Legacy mode: start Chrome with <code>--remote-debugging-port=9222</code> and log in first. Switch the application to <b>Automatic login</b> to run as several users.</p>}
                    </div>
                  )}

                  <button className="run-btn" disabled={!canRun} onClick={() => handleRun()}>
                    <Svg name="play" size={14} />
                    {running ? `Running… ${Object.keys(run.results || {}).length}/${runTotal(run)}`
                      : selectedIds.length === 0 ? "Select tests to run"
                      : multiUser && selectedUsers.length === 0 ? "Select test users"
                      : multiUser ? `Run ${plural(selectedIds.length, "test")} × ${plural(selectedUsers.length, "user")}`
                      : allSelected ? `Run all ${plural(selectedIds.length, "test")}` : `Run ${selectedIds.length} selected`}
                  </button>
                  {multiUser && !running && selectedIds.length > 0 && selectedUsers.length > 0 && <p className="note center">{plural(planned, "execution")} · each with its own video</p>}
                  <button className="ghost-btn" onClick={newTest}><Svg name="plus" size={15} /> Create a test case</button>
                  {needsUrl && catalog.length > 0 && !running && <p className="note">This application has no Base URL yet. <button className="text-btn" onClick={() => { setManageId(appId); setTab("applications"); }}>Add it in Applications</button></p>}
                </section>

                <RunAsPanel app={activeApp} users={users} skip={userSkip} demo={config.demo} running={running}
                            onToggle={(id) => { setActiveSuite(null); setUserSkip((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; }); }}
                            onAll={(on) => setUserSkip(on ? new Set() : new Set(activeUsers.map((u) => u.id)))}
                            onManage={() => { setManageId(appId); setTab("applications"); }} />

                <section className="card">
                  <div className="card-head"><h2><Svg name="fn" size={15} /> Reusable functions</h2>
                    <button className="text-btn" onClick={() => setFnForm({ id: null, name: "", description: "", params: [], steps: [{ action: "open", target: "", value: "" }] })}><Svg name="plus" size={14} /> New</button></div>
                  {functions.length === 0 ? <p className="note">Save step sequences you repeat (for example "Open the week and add a project") and use them in any test with the <b>Use function</b> step.</p> : (
                    <ul className="fn-list">{functions.map((f) => (
                      <li key={f.id}><button className="fn-name" onClick={() => setFnForm({ ...f })}><Svg name="fn" size={13} />{f.name}</button>
                        <small>{plural(f.steps.length, "step")}{f.params.length ? ` · ${f.params.map((p) => p.name).join(", ")}` : ""}</small></li>))}
                    </ul>)}
                </section>
              </div>

              <section className="card results">
                {run ? (
                  <ResultsView run={run} filter={filter} setFilter={setFilter} groupBy={settings.groupBy || "user"}
                               setGroupBy={(g) => setSettings((s) => ({ ...s, groupBy: g }))}
                               onWatch={setWatch} onMedia={setMedia} onBack={() => setRun(null)} />
                ) : (
                  <>
                    <div className="card-head">
                      <h2>Select tests to run</h2>
                      {catalog.length > 0 && <span className="muted small">{selectedIds.length} of {catalog.length} selected{activeSuite ? ` · suite ${activeSuite.name}` : ""}</span>}
                    </div>
                    {catalog.length === 0 ? (
                      <div className="empty"><Svg name="film" size={30} /><p>Upload an Excel file or create a test case to get started.</p></div>
                    ) : (
                      <>
                        <div className="toolbar">
                          <div className="filters">
                            <button onClick={() => { setSkip(new Set()); setActiveSuite(null); }} disabled={allSelected}>Select all</button>
                            <button onClick={() => { setSkip(new Set(catalog.map((c) => c.id))); setActiveSuite(null); }} disabled={selectedIds.length === 0}>Clear</button>
                          </div>
                          <small className="muted">Tick the tests to run. Tests with a <b>Runs as</b> list only run for those roles or users.</small>
                        </div>
                        <div className="wall">
                          {catalog.map((c) => (
                            <CaseCard key={c.id} c={c} mode="select" users={users} checked={!skip.has(c.id)} onToggle={() => toggle(c.id)}
                                      canRun={canRun} onRunOne={() => handleRun([c.id])}
                                      onEdit={() => setBuilder({ db_id: c.db_id, name: c.name, expected: c.expected || "", key: c.key, params: c.params || {},
                                        run_as: c.run_as_cfg || {}, steps: c.steps?.length ? c.steps : [{ action: "open", target: "", value: "" }] })}
                                      onDelete={() => removeCustom(c)} />
                          ))}
                        </div>
                      </>
                    )}
                  </>
                )}
              </section>
            </div>
          </>
        )}
      </main>

      {watch && run && <Theater startKey={watch} run={run} onClose={() => setWatch(null)} />}
      {media && <MediaModal m={media} onClose={() => setMedia(null)} />}
      {builder && <Builder initial={builder} app={activeApp} users={users} roles={roles} functions={functions} settings={settings} config={config}
                           canRun={!running && !needsUrl && !config.db_error && usersOk} notify={notify}
                           onClose={() => setBuilder(null)} onSave={saveBuilder} />}
      {fnForm && <FunctionForm initial={fnForm} functions={functions} onClose={() => setFnForm(null)} onSave={saveFn}
                               onDelete={async (f) => { try { await api.deleteFunction(f.id); setFunctions((l) => l.filter((x) => x.id !== f.id)); setFnForm(null); notify("Function deleted"); } catch (e) { notify(e.message, "err"); } }} />}
      <div className="toasts">{toasts.map((t) => <div key={t.id} className={"toast " + t.kind}>{t.msg}</div>)}</div>
    </>
  );
}

/* ------------------------------------------------------------------ run results: one entry per (user, test case) */
function runEntries(run) {
  const byId = Object.fromEntries((run.cases || []).map((c) => [c.id, c]));
  const out = [];
  if (run.users?.length) {
    run.users.forEach((u) => (u.cases || []).forEach((cid) => {
      const key = `${u.key}::${cid}`;
      out.push({ key, user: u, c: byId[cid] || { id: cid, name: cid }, r: run.results?.[key] });
    }));
  } else {
    (run.cases || []).forEach((c) => { const key = `::${c.id}`; out.push({ key, user: null, c, r: run.results?.[key] }); });
  }
  return out;
}
const runTotal = (run) => (run ? runEntries(run).length : 0);

function countOf(entries) {
  const c = { pass: 0, fail: 0, skip: 0, reg: 0, fixed: 0, sec: 0, total: entries.length };
  entries.forEach(({ r }) => {
    if (!r) return;
    if (r.status === "PASS") c.pass++; else if (r.status === "FAIL") c.fail++; else if (r.status === "SKIP") c.skip++;
    if (isReg(r)) c.reg++;
    if (isFixed(r)) c.fixed++;
    if (r.findings?.length) c.sec += r.findings.length;
  });
  c.done = c.pass + c.fail + c.skip;
  c.notRun = Math.max(c.total - c.done, 0);
  return c;
}

function RunRing({ run }) {
  const entries = run ? runEntries(run) : [];
  const c = countOf(entries);
  return <Ring counts={c} done={c.done} running={run?.status === "running"} />;
}

function ResultsView({ run, filter, setFilter, groupBy, setGroupBy, onWatch, onMedia, onBack }) {
  const running = run.status === "running";
  const entries = useMemo(() => runEntries(run), [run]);
  const counts = countOf(entries);
  const logins = run.logins || {};
  const findings = useMemo(() => {
    const out = [];
    entries.forEach((e) => (e.r?.findings || []).forEach((f) => out.push({ ...f, entry: e })));
    Object.values(logins).forEach((l) => (l.findings || []).forEach((f) => out.push({ ...f, login: l })));
    const rank = { critical: 0, high: 1, medium: 2, low: 3 };
    return out.sort((a, b) => (rank[a.severity] ?? 9) - (rank[b.severity] ?? 9));
  }, [entries, logins]);
  const visible = entries.filter(({ r }) => {
    if (filter === "all") return true;
    if (!r) return false;
    if (filter === "REG") return isReg(r);
    if (filter === "SEC") return r.findings?.length > 0;
    return r.status === filter;
  });
  const loginFails = Object.values(logins).filter((l) => l.status === "FAIL");
  const multi = (run.users || []).length > 0 && !(run.users.length === 1 && ["chrome", "anon"].includes(run.users[0].key));

  const groups = useMemo(() => {
    if (groupBy === "matrix") return [];
    const map = new Map();
    visible.forEach((e) => {
      let k, label, sub;
      if (groupBy === "case") { k = e.c.id; label = e.c.name; sub = e.c.id; }
      else if (groupBy === "role") { k = (e.user?.role || "-").toUpperCase(); label = e.user?.role || "No role"; sub = ""; }
      else { k = e.user?.key || "-"; label = e.user?.display_name || e.user?.username || "All tests"; sub = e.user?.role || ""; }
      if (!map.has(k)) map.set(k, { k, label, sub, items: [] });
      map.get(k).items.push(e);
    });
    return [...map.values()];
  }, [visible, groupBy]);

  return (
    <>
      <div className="card-head">
        <h2>Results{run.suite_name ? <small className="muted"> · {run.suite_name}</small> : null}</h2>
        <span className={"badge " + (run.status || "")}>{running ? "Running" : run.status === "error" ? "Stopped" : "Finished"}</span>
      </div>
      {run.status === "error" && <div className="banner err">{run.error}</div>}
      <div className="stats">
        <Stat k="pass" label="Passed" v={counts.pass} /><Stat k="fail" label="Failed" v={counts.fail} />
        <Stat k="skip" label="Skipped" v={counts.skip} /><Stat k="idle" label="Not run" v={counts.notRun} />
      </div>

      {multi && (
        <div className="login-strip">
          {run.users.map((u) => {
            const l = logins[u.key];
            const st = l ? (l.status === "OK" ? "ok" : "bad") : run.current_user === u.key ? "busy" : "wait";
            const ue = entries.filter((e) => e.user?.key === u.key);
            const uc = countOf(ue);
            return (
              <button key={u.key} className={"login-chip " + st} disabled={!l}
                      onClick={() => l && onMedia({ title: `Sign-in · ${u.username}`, video: l.video, shot: l.shot,
                        lines: [["Login", `${l.status} - ${l.detail || ""}`], ["Sign-out", l.logout || "-"], ["Landing page", l.landing_url || "-"]] })}
                      title={l ? `${l.detail || ""}${l.logout ? "\n" + l.logout : ""}` : "Waiting"}>
                <span className="avatar">{initials(u.display_name || u.username)}</span>
                <span className="lc-main"><b>{u.username}</b><small>{u.role || "no role"}</small></span>
                <span className="lc-state">{st === "ok" ? `${uc.pass}/${uc.total}` : st === "bad" ? "login failed" : st === "busy" ? <span className="pulse" /> : "queued"}</span>
              </button>);
          })}
        </div>
      )}

      {(loginFails.length > 0 || findings.length > 0 || counts.reg > 0 || counts.fixed > 0) && (
        <div className="alerts">
          {loginFails.map((l) => (
            <div key={l.user_key} className="alert-row login" onClick={() => onMedia({ title: `Login failed · ${l.username}`, video: l.video, shot: l.shot, lines: [["Details", l.detail]] })}>
              <span className="sev high">Login</span><b>{l.username}</b><span className="muted">{l.detail}</span><span className="go">Evidence →</span>
            </div>))}
          {findings.slice(0, 6).map((f, i) => (
            <div key={i} className="alert-row" onClick={() => (f.entry?.r?.video ? onWatch(f.entry.key) : f.login && onMedia({ title: f.title, video: f.login.video, shot: f.login.shot, lines: [["Details", f.detail]] }))}>
              <span className={"sev " + f.severity}>{f.severity}</span><b>{f.title}</b><span className="muted">{f.username}{f.role ? ` · ${f.role}` : ""}{f.entry ? ` · ${f.entry.c.id}` : ""}</span><span className="go">Evidence →</span>
            </div>))}
          {findings.length > 6 && <button className="text-btn" onClick={() => setFilter("SEC")}>Show all {findings.length} findings</button>}
          {(counts.reg > 0 || counts.fixed > 0) && (
            <div className="radar">
              <b>Compared with run {run.prev_run}</b>
              {counts.reg > 0 && <button className="tag bad" onClick={() => setFilter("REG")}>{plural(counts.reg, "regression")}</button>}
              {counts.fixed > 0 && <span className="tag good">{counts.fixed} fixed</span>}
            </div>
          )}
        </div>
      )}

      <div className="toolbar">
        <div className="filters">
          {FILTERS.map(([k, label]) => (
            <button key={k} className={filter === k ? "on" : ""} onClick={() => setFilter(k)}>
              {label}{k === "REG" && counts.reg > 0 && <em>{counts.reg}</em>}{k === "SEC" && counts.sec > 0 && <em>{counts.sec}</em>}
            </button>))}
        </div>
        <div className="seg-tabs">
          {GROUPS.filter(([k]) => multi || k === "case").map(([k, label]) => (
            <button key={k} className={(multi ? groupBy : "case") === k ? "on" : ""} onClick={() => setGroupBy(k)}>{label}</button>))}
        </div>
      </div>

      {multi && groupBy === "matrix" ? (
        <Matrix run={run} entries={visible} onWatch={onWatch} />
      ) : (
        (multi ? groups : [{ k: "all", label: "", items: visible }]).map((g) => {
          const gc = countOf(g.items);
          return (
            <div key={g.k} className="group">
              {g.label && (
                <div className="group-head">
                  {groupBy === "user" && <span className="avatar">{initials(g.label)}</span>}
                  <b>{g.label}</b>{g.sub && <span className="role-chip">{g.sub}</span>}
                  <span className="g-count"><i className="g">{gc.pass}</i><i className="r">{gc.fail}</i><i className="a">{gc.skip}</i> of {gc.total}</span>
                </div>)}
              <div className="wall">
                {g.items.map((e) => (
                  <CaseCard key={e.key} c={e.c} r={e.r} user={groupBy === "user" ? null : e.user} mode="results"
                            active={running && run.current === e.c.id && (!e.user || run.current_user === e.user.key)} onWatch={() => onWatch(e.key)} />
                ))}
              </div>
            </div>);
        })
      )}
      {visible.length === 0 && <p className="note">Nothing matches this filter.</p>}

      <div className="exports">
        {!running && Object.keys(run.results || {}).length > 0 && <>
          <a href={`/api/runs/${run.id}/report`} target="_blank" rel="noreferrer">Open HTML report</a>
          <a href={`/api/runs/${run.id}/csv`}>Download CSV</a></>}
        <button className="text-btn push" disabled={running} onClick={onBack}><Svg name="back" size={14} /> Back to test list</button>
      </div>
    </>
  );
}

function Matrix({ run, entries, onWatch }) {
  const users = run.users || [];
  const caseIds = [...new Set(entries.map((e) => e.c.id))];
  const byKey = Object.fromEntries(entries.map((e) => [e.key, e]));
  const names = Object.fromEntries(entries.map((e) => [e.c.id, e.c.name]));
  return (
    <div className="matrix-wrap">
      <table className="matrix">
        <thead><tr><th>Test case</th>{users.map((u) => <th key={u.key}><span>{u.username}</span><small>{u.role}</small></th>)}</tr></thead>
        <tbody>
          {caseIds.map((cid) => (
            <tr key={cid}>
              <td><code>{cid}</code><span>{names[cid]}</span></td>
              {users.map((u) => {
                const e = byKey[`${u.key}::${cid}`];
                if (!e) return <td key={u.key} className="na" title="Does not apply to this user">–</td>;
                const st = e.r ? e.r.status.toLowerCase() : "idle";
                return (
                  <td key={u.key} className={"cell " + st + (e.r?.findings?.length ? " sec" : "") + (isReg(e.r) ? " reg" : "")}
                      onClick={() => e.r?.video && onWatch(e.key)} title={e.r ? `${e.r.status}: ${e.r.detail}` : "Not run yet"}>
                    {e.r ? e.r.status : "·"}{e.r?.findings?.length ? <Svg name="shield" size={11} /> : null}
                  </td>);
              })}
            </tr>))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ pieces */
function Field({ label, children, hint }) { return <div className="field"><label>{label}</label>{children}{hint && <small className="hint">{hint}</small>}</div>; }

function Stat({ k, label, v }) {
  const n = useCountUp(v);
  return <div className={"stat " + k}><small>{label}</small><b>{n}</b></div>;
}

function DbChip({ config }) {
  const d = config.db;
  const used = d ? Math.min(100, (d.db_mb / d.limit_mb) * 100) : 0;
  return (
    <div className={"dbchip" + (config.db_error ? " bad" : d ? " ok" : "")} title={d ? `${d.version}\n${d.runs} runs, ${d.media} files (${d.media_mb} MB evidence)` : ""}>
      <Svg name="db" size={15} /><span className="dot" />
      <div>
        <b>{config.db_error ? "Database offline" : d ? `PostgreSQL · ${d.database}` : "Connecting…"}</b>
        {d && <small>{d.db_mb} / {d.limit_mb} MB · {d.runs} runs</small>}
      </div>
      {d && <div className="meter"><i style={{ width: used + "%" }} className={used > 80 ? "hot" : ""} /></div>}
    </div>
  );
}

function Ring({ counts, done, running }) {
  const R = 54, C = 2 * Math.PI * R, total = counts.total || 1;
  let offset = 0;
  const rate = counts.total ? Math.round((counts.pass / counts.total) * 100) : 0;
  const shown = useCountUp(rate, 600);
  return (
    <div className="ring">
      <svg viewBox="0 0 130 130">
        <circle cx="65" cy="65" r={R} className="track" />
        {[["pass", counts.pass], ["fail", counts.fail], ["skip", counts.skip]].filter(([, n]) => n > 0).map(([k, n]) => {
          const len = (n / total) * C;
          const el = <circle key={k} cx="65" cy="65" r={R} className={"arc " + k} strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-offset} />;
          offset += len; return el;
        })}
      </svg>
      <div className="ring-mid">
        <b>{counts.total ? shown : "–"}{counts.total ? <sup>%</sup> : null}</b>
        <small>{running ? `${done}/${counts.total} done` : counts.total ? "pass rate" : "no run yet"}</small>
      </div>
    </div>
  );
}

function RunAs({ c, users }) {
  if (!c.run_as?.length) return null;
  const name = (t) => users?.find((u) => String(u.id) === String(t))?.username || t;
  return <div className="runas"><em>Runs as</em>{c.run_as.map((t) => <span key={t} className="role-chip">{name(t)}</span>)}</div>;
}

function CaseCard({ c, r, user, mode, users, checked, onToggle, active, onWatch, canRun, onRunOne, onEdit, onDelete }) {
  const [confirm, setConfirm] = useState(false);
  const vid = useRef(null);
  const sel = mode === "select";
  const st = r ? r.status.toLowerCase() : active ? "run" : "idle";
  const click = () => (sel ? onToggle() : r?.video && onWatch());
  const kind = c.key === "CUSTOM_STEPS" ? `${c.steps?.length || 0} steps` : ALL_CHECKS.find((x) => x.key === c.key)?.label || c.key;
  return (
    <article className={"case " + (sel ? (checked ? "sel" : "off") : st)} onClick={click}>
      <div className="case-media"
           onMouseEnter={() => vid.current?.play().catch(() => {})}
           onMouseLeave={() => { if (vid.current) { vid.current.pause(); vid.current.currentTime = 0.4; } }}>
        {!sel && r?.video ? (
          <>
            <video ref={vid} src={r.video + "#t=0.4"} poster={r.shot || undefined} muted loop playsInline preload="metadata" />
            <span className="play"><Svg name="play" size={16} /></span>
          </>
        ) : (
          <div className="ph">
            {active ? <span className="pulse" /> : <Svg name="film" size={22} />}
            <small>{sel ? (c.custom ? `Custom · ${kind}` : c.key) : active ? "recording…" : r ? (r.detail?.startsWith("Not run") ? "blocked" : "no video") : "waiting"}</small>
          </div>
        )}
        {sel ? <span className="check-box" aria-hidden>{checked ? "✓" : ""}</span>
             : <span className={"pill " + st}>{r ? r.status : active ? "RUNNING" : "QUEUED"}</span>}
        <div className="flags">
          {c.custom && <span className="flag custom">Custom</span>}
          {r?.findings?.length > 0 && <span className="flag sec"><Svg name="shield" size={10} /> Security</span>}
          {isReg(r) && <span className="flag bad">Regression</span>}
          {isFixed(r) && <span className="flag good">Fixed</span>}
        </div>
      </div>
      <div className="case-body">
        <div className="case-title"><code>{c.id}</code><span>{c.name}</span></div>
        {user && <div className="who"><span className="avatar sm">{initials(user.display_name || user.username)}</span>{user.username}{user.role && <span className="role-chip">{user.role}</span>}</div>}
        {sel && <RunAs c={c} users={users} />}
        {c.expected && <p><em>Expected</em>{c.expected}</p>}
        {r && <p className="actual"><em>Actual</em>{r.detail}</p>}
        {r?.findings?.map((f, i) => <p key={i} className="finding"><span className={"sev " + f.severity}>{f.severity}</span>{f.title}</p>)}
        {r && r.secs ? <small className="secs">{r.secs}s</small> : null}
        {sel && (
          <div className="card-actions" onClick={(e) => e.stopPropagation()}>
            <button className="mini" disabled={!canRun} onClick={onRunOne} title="Run only this test (for every selected user) and record the video"><Svg name="play" size={11} /> Run only this</button>
            {c.custom && <>
              <button className="mini icon" onClick={onEdit} title="Edit" aria-label="Edit test"><Svg name="edit" size={13} /></button>
              {confirm
                ? <button className="mini danger" onClick={onDelete} onBlur={() => setConfirm(false)} autoFocus>Delete?</button>
                : <button className="mini icon" onClick={() => setConfirm(true)} title="Delete" aria-label="Delete test"><Svg name="trash" size={13} /></button>}
            </>}
          </div>
        )}
      </div>
    </article>
  );
}

function Theater({ startKey, run, onClose }) {
  const [cur, setCur] = useState(startKey);
  const [mode, setMode] = useState("video");
  const ref = useRef(null);
  const list = useMemo(() => runEntries(run).filter((e) => e.r?.video), [run]);
  const idx = list.findIndex((e) => e.key === cur);
  const e = list[idx];
  const go = useCallback((d) => { if (list.length) { setCur(list[(idx + d + list.length) % list.length].key); setMode("video"); } }, [idx, list]);
  useEffect(() => {
    const k = (ev) => { if (ev.key === "Escape") onClose(); if (ev.key === "ArrowRight") go(1); if (ev.key === "ArrowLeft") go(-1); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [go, onClose]);
  if (!e) return null;
  const r = e.r;
  return (
    <div className="overlay" onClick={onClose}>
      <div className="theater" onClick={(ev) => ev.stopPropagation()}>
        <div className="stage">
          {mode === "video" ? <video key={r.video} ref={ref} src={r.video} controls autoPlay /> : <img src={r.shot} alt="Final screenshot" />}
        </div>
        <aside>
          <button className="x" onClick={onClose} aria-label="Close"><Svg name="x" /></button>
          <span className={"pill " + r.status.toLowerCase()}>{r.status}</span>
          <h3>{r.test_case_id}</h3><p className="tname">{r.name}</p>
          {e.user && <div className="who big"><span className="avatar">{initials(e.user.display_name || e.user.username)}</span><div><b>{e.user.username}</b><small>{e.user.role || "no role"}</small></div></div>}
          {r.expected && <div className="kv"><em>Expected</em>{r.expected}</div>}
          <div className="kv"><em>Actual</em>{r.detail}</div>
          {r.findings?.map((f, i) => <div key={i} className="kv sec"><em><span className={"sev " + f.severity}>{f.severity}</span> Security finding</em><b>{f.title}</b><div className="muted">{f.detail}</div></div>)}
          {r.data != null && r.data !== "" && <div className="kv"><em>Sample data</em><code>{r.data}</code></div>}
          <div className="seg">
            <button className={mode === "video" ? "on" : ""} onClick={() => setMode("video")}>Video</button>
            {r.shot && <button className={mode === "shot" ? "on" : ""} onClick={() => setMode("shot")}>Screenshot</button>}
          </div>
          {mode === "video" && (
            <div className="seg">{[1, 1.5, 2].map((s) => <button key={s} onClick={() => { if (ref.current) ref.current.playbackRate = s; }}>{s}×</button>)}</div>
          )}
          <div className="nav">
            <button onClick={() => go(-1)}>← Prev</button><span>{idx + 1} / {list.length}</span><button onClick={() => go(1)}>Next →</button>
          </div>
          <a className="dl" href={r.video} download>Download video</a>
        </aside>
      </div>
    </div>
  );
}

function MediaModal({ m, onClose }) {
  const [mode, setMode] = useState(m.video ? "video" : "shot");
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="theater" onClick={(e) => e.stopPropagation()}>
        <div className="stage">
          {mode === "video" && m.video ? <video src={m.video} controls autoPlay /> : m.shot ? <img src={m.shot} alt="Screenshot" /> : <p className="note">No recording for this item.</p>}
        </div>
        <aside>
          <button className="x" onClick={onClose} aria-label="Close"><Svg name="x" /></button>
          <h3 className="mm-title">{m.title}</h3>
          {(m.lines || []).map(([k, v], i) => <div key={i} className="kv"><em>{k}</em>{v}</div>)}
          <div className="seg">
            {m.video && <button className={mode === "video" ? "on" : ""} onClick={() => setMode("video")}>Video</button>}
            {m.shot && <button className={mode === "shot" ? "on" : ""} onClick={() => setMode("shot")}>Screenshot</button>}
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ studio: who runs */
function RunAsPanel({ app, users, skip, demo, running, onToggle, onAll, onManage }) {
  if (!app) return null;
  const active = users.filter((u) => u.enabled);
  const chosen = active.filter((u) => !skip.has(u.id));
  if (app.auth_type !== "apex_login") {
    return (
      <section className="card">
        <div className="card-head"><h2><Svg name="users" size={15} /> Run as</h2></div>
        <p className="note">{app.auth_type === "none" ? "This application is public - tests run without a login." :
          "This application still uses your manually logged-in Chrome. Switch it to Automatic login and add test users to run every test as each user."}</p>
        <button className="ghost-btn" onClick={onManage}><Svg name="gear" size={14} /> Set up automatic login</button>
      </section>);
  }
  return (
    <section className="card">
      <div className="card-head"><h2><Svg name="users" size={15} /> Run as</h2>
        <small className="muted">{chosen.length} of {active.length} users</small></div>
      {active.length === 0 ? (
        <>
          <p className="note">Add the users the tests should sign in as - one per role you want to check (for example an employee, a manager and an admin).</p>
          <button className="ghost-btn" onClick={onManage}><Svg name="plus" size={14} /> Add test users</button>
        </>
      ) : (
        <>
          <ul className="user-pick">
            {active.map((u) => {
              const on = !skip.has(u.id);
              const bad = !u.credential?.ok && !demo;
              return (
                <li key={u.id} className={(on ? "on" : "") + (bad ? " bad" : "")}>
                  <label>
                    <input type="checkbox" checked={on} disabled={running} onChange={() => onToggle(u.id)} />
                    <span className="avatar">{initials(u.display_name || u.username)}</span>
                    <span className="up-main"><b>{u.username}</b><small>{bad ? u.credential?.note : u.display_name && u.display_name !== u.username ? u.display_name : u.credential?.kind === "env" ? `password from ${u.credential.name}` : "password encrypted"}</small></span>
                    {u.role && <span className="role-chip">{u.role}</span>}
                    <span className={"dot-st " + (u.last_login_status === "OK" ? "ok" : u.last_login_status === "FAIL" ? "bad" : "")} title={u.last_login_status ? `Last login ${u.last_login_status}: ${u.last_login_detail || ""}` : "Not signed in yet"} />
                  </label>
                </li>);
            })}
          </ul>
          <div className="row-actions">
            <button className="text-btn" disabled={running} onClick={() => onAll(chosen.length !== active.length)}>{chosen.length === active.length ? "Clear" : "Select all"}</button>
            <button className="text-btn" onClick={onManage}>Manage users</button>
          </div>
        </>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ create / edit a test */
function StepsEditor({ steps, onChange, functions, exclude }) {
  const setStep = (i, patch) => onChange(steps.map((st, n) => (n === i ? { ...st, ...patch } : st)));
  const move = (i, d) => { const a = [...steps], j = i + d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; onChange(a); };
  const fns = functions.filter((f) => f.name !== exclude);
  return (
    <div className="steps">
      {steps.map((st, i) => {
        const a = ACTIONS.find((x) => x.k === st.action) || ACTIONS[0];
        const fn = st.action === "call" ? fns.find((f) => f.name.toLowerCase() === String(st.target || "").toLowerCase()) : null;
        return (
          <div className={"step" + (st.action === "assert" ? " assert" : "") + (st.action === "call" ? " call" : "")} key={i}>
            <span className="num">{i + 1}</span>
            <select value={st.action} onChange={(e) => setStep(i, { action: e.target.value, ...(e.target.value === "assert" ? { subject: st.subject || "text", op: st.op || "contains" } : {}) })}>
              {ACTIONS.filter((x) => x.k !== "call" || fns.length || st.action === "call").map((x) => <option key={x.k} value={x.k}>{x.label}</option>)}
            </select>
            {st.action === "assert" ? (
              <div className="step-in assert">
                <select value={st.subject || "text"} onChange={(e) => setStep(i, { subject: e.target.value })}>{SUBJECTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
                {!NO_TARGET.has(st.subject || "text") && <input type="text" placeholder={st.subject === "item" ? "P4_HOURS" : "Label, text or #selector"} value={st.target || ""} onChange={(e) => setStep(i, { target: e.target.value })} />}
                {!STATE_SUBJ.has(st.subject) && <select value={st.op || "contains"} onChange={(e) => setStep(i, { op: e.target.value })}>{OPS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>}
                {!STATE_SUBJ.has(st.subject) && !["empty", "not_empty"].includes(st.op) && <input type="text" placeholder="Expected value" value={st.value || ""} onChange={(e) => setStep(i, { value: e.target.value })} />}
              </div>
            ) : st.action === "call" ? (
              <div className="step-in two">
                <select value={fn?.name || st.target || ""} onChange={(e) => setStep(i, { target: e.target.value })}>
                  <option value="">Choose a function…</option>{fns.map((f) => <option key={f.id} value={f.name}>{f.name}</option>)}
                  {st.target && !fn && <option value={st.target}>{st.target} (missing)</option>}
                </select>
                <input type="text" placeholder={fn?.params?.length ? fn.params.map((p) => `${p.name}=${p.default || "…"}`).join("; ") : "No parameters"} value={st.value || ""} onChange={(e) => setStep(i, { value: e.target.value })} />
              </div>
            ) : (
              <div className={"step-in" + (a.t && a.v ? " two" : "")}>
                {a.t && <input type="text" placeholder={a.t + (a.tph ? ` (e.g. ${a.tph})` : "")} value={st.target || ""} onChange={(e) => setStep(i, { target: e.target.value })} />}
                {a.v && <input type="text" placeholder={a.v + (a.vph ? ` (${a.vph})` : "")} value={st.value || ""} onChange={(e) => setStep(i, { value: e.target.value })} />}
              </div>
            )}
            <div className="step-act">
              <button onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up"><Svg name="up" size={13} /></button>
              <button onClick={() => move(i, 1)} disabled={i === steps.length - 1} aria-label="Move down"><Svg name="down" size={13} /></button>
              <button onClick={() => onChange(steps.filter((_, n) => n !== i))} aria-label="Remove step"><Svg name="x" size={13} /></button>
            </div>
          </div>
        );
      })}
      <div className="row-actions">
        <button className="text-btn" onClick={() => onChange([...steps, { action: "click", target: "", value: "" }])}><Svg name="plus" size={14} /> Add step</button>
        <button className="text-btn" onClick={() => onChange([...steps, { action: "assert", subject: "text", op: "contains", target: "", value: "" }])}><Svg name="check" size={14} /> Add check</button>
        {fns.length > 0 && <button className="text-btn" onClick={() => onChange([...steps, { action: "call", target: fns[0].name, value: "" }])}><Svg name="fn" size={14} /> Use function</button>}
      </div>
    </div>
  );
}

function Builder({ initial, app, users, roles, functions, settings, config, canRun, notify, onClose, onSave }) {
  const [b, setB] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState({ open: !initial.db_id, prompt: "", inspect: false, page: app?.home_page || "", user: "", busy: false, out: null });
  const [elements, setElements] = useState(null);
  const check = ALL_CHECKS.find((x) => x.key === b.key);
  const isSteps = b.key === "CUSTOM_STEPS";
  const ra = b.run_as || {};
  const raMode = ra.users?.length ? "users" : ra.roles?.length ? "roles" : "all";
  const valid = b.name.trim() && (!isSteps || b.steps.length > 0);
  async function submit(runAfter) { setBusy(true); await onSave(b, runAfter); setBusy(false); }
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  const toggleIn = (list, v) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  const multi = app?.auth_type === "apex_login";

  async function generate() {
    setAi((s) => ({ ...s, busy: true, out: null }));
    try {
      const out = await api.aiGenerate({ application_id: app.id, prompt: ai.prompt, inspect: ai.inspect, page: ai.page, user_id: ai.user || null });
      setAi((s) => ({ ...s, busy: false, out }));
      if (out.page_info) setElements(out.page_info);
    } catch (e) { setAi((s) => ({ ...s, busy: false })); notify(e.message, "err"); }
  }
  function applyGenerated(append) {
    const o = ai.out;
    setB((s) => ({ ...s, name: s.name.trim() ? s.name : o.name, expected: s.expected.trim() ? s.expected : o.expected || "",
      steps: append ? [...s.steps, ...o.steps] : o.steps, run_as: o.run_as?.roles?.length && !s.run_as?.roles?.length ? { roles: o.run_as.roles } : s.run_as }));
    setAi((s) => ({ ...s, out: null, open: false }));
  }
  async function readPage() {
    setElements({ loading: true });
    try { setElements(await api.inspectPage(app.id, { page: ai.page, user_id: ai.user || null })); }
    catch (e) { setElements(null); notify(e.message, "err"); }
  }
  const addStep = (st) => setB((s) => ({ ...s, steps: [...s.steps, st] }));

  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet wide" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <h3>{b.db_id ? "Edit test case" : "Create a test case"}</h3>
          <button className="x flat" onClick={onClose} aria-label="Close"><Svg name="x" /></button>
        </div>
        <div className="sheet-body">
          <div className="two-col">
            <Field label="Name"><input type="text" autoFocus placeholder="e.g. Save button is disabled for future weeks" value={b.name} onChange={(e) => setB({ ...b, name: e.target.value })} /></Field>
            <Field label="Type">
              <select value={b.key} onChange={(e) => setB({ ...b, key: e.target.value, params: {} })}>
                <option value="CUSTOM_STEPS">Custom steps (build it yourself)</option>
                <optgroup label="Checks for any APEX app">{GENERIC.map((x) => <option key={x.key} value={x.key}>{x.label}</option>)}</optgroup>
                <optgroup label="Timesheet app checks">{BUILTIN.map((x) => <option key={x.key} value={x.key}>{x.label}</option>)}</optgroup>
              </select>
            </Field>
          </div>
          <Field label="Expected result (shown in the report)"><input type="text" placeholder="What should happen?" value={b.expected} onChange={(e) => setB({ ...b, expected: e.target.value })} /></Field>

          {multi && (
            <div className="runas-edit">
              <div className="ra-head"><b>Runs as</b>
                <div className="seg-tabs small">
                  {[["all", "Every user"], ["roles", "Some roles"], ["users", "Some users"]].map(([k, l]) => (
                    <button key={k} className={raMode === k ? "on" : ""} onClick={() => setB({ ...b, run_as: k === "all" ? {} : k === "roles" ? { roles: roles.slice(0, 1) } : { users: users.slice(0, 1).map((u) => u.id) } })}>{l}</button>))}
                </div>
              </div>
              {raMode === "roles" && <div className="chips">{roles.length === 0 && <span className="note">Give your test users a role first.</span>}
                {roles.map((r) => <button key={r} className={"chip" + (ra.roles?.includes(r) ? " on" : "")} onClick={() => setB({ ...b, run_as: { roles: toggleIn(ra.roles || [], r) } })}>{r}</button>)}</div>}
              {raMode === "users" && <div className="chips">
                {users.map((u) => <button key={u.id} className={"chip" + (ra.users?.includes(u.id) ? " on" : "")} onClick={() => setB({ ...b, run_as: { users: toggleIn(ra.users || [], u.id) } })}>{u.username}{u.role ? ` · ${u.role}` : ""}</button>)}</div>}
              <small className="hint">{raMode === "all" ? "The test runs once for every selected test user." : "The test is skipped for the other users."}{b.key === "PAGE_ACCESS" ? " Role-based access checks usually run for every user." : ""}</small>
            </div>
          )}

          {isSteps ? (
            <>
              <div className={"ai-box" + (ai.open ? " open" : "")}>
                <button className="ai-toggle" onClick={() => setAi((s) => ({ ...s, open: !s.open }))}>
                  <Svg name="spark" size={15} /> <b>Write the steps for me</b>
                  <small>{config.ai ? `AI (${config.ai_model})` : "offline rule parser - add ANTHROPIC_API_KEY for AI"}</small>
                </button>
                {ai.open && (
                  <div className="ai-body">
                    <textarea rows={3} placeholder={'Describe the test, e.g. "Open the timesheet, type 25 into Hours, click Save and expect \'Hours cannot be more than 24\'. P4_TOTAL should stay 40."'}
                              value={ai.prompt} onChange={(e) => setAi({ ...ai, prompt: e.target.value })} />
                    <div className="ai-opts">
                      <label className="check"><input type="checkbox" checked={ai.inspect} onChange={(e) => setAi({ ...ai, inspect: e.target.checked })} />Read the page first</label>
                      <input type="text" className="slim" placeholder="page alias (blank = home)" value={ai.page} onChange={(e) => setAi({ ...ai, page: e.target.value })} />
                      {multi && users.length > 0 && <select className="slim" value={ai.user} onChange={(e) => setAi({ ...ai, user: e.target.value })}>
                        <option value="">as {users.find((u) => u.enabled)?.username || "first user"}</option>{users.filter((u) => u.enabled).map((u) => <option key={u.id} value={u.id}>as {u.username}</option>)}</select>}
                      <button className="mini" onClick={readPage} disabled={elements?.loading}><Svg name="search" size={12} /> {elements?.loading ? "Reading…" : "Show page elements"}</button>
                      <button className="run-btn inline" disabled={ai.busy || ai.prompt.trim().length < 6} onClick={generate}><Svg name="spark" size={13} /> {ai.busy ? "Writing steps…" : "Generate steps"}</button>
                    </div>
                    {ai.out && (
                      <div className="ai-out">
                        <div className="ai-out-head"><b>{ai.out.name}</b><small>{ai.out.source === "ai" ? `AI · ${ai.out.model}` : "rule parser"} · {plural(ai.out.steps.length, "step")}</small></div>
                        <ol>{ai.out.steps.map((s, i) => <li key={i}>{describeStep(s)}</li>)}</ol>
                        {ai.out.problems?.length > 0 && <div className="banner warn">Left out: {ai.out.problems.join("; ")}</div>}
                        {ai.out.note && <p className="note">{ai.out.note}</p>}
                        <div className="row-actions"><button className="mini" disabled={!ai.out.steps.length} onClick={() => applyGenerated(false)}>Use these steps</button>
                          <button className="mini" disabled={!ai.out.steps.length} onClick={() => applyGenerated(true)}>Add to the end</button></div>
                      </div>)}
                    {elements && !elements.loading && (
                      <div className="elements">
                        <small>Page elements{elements.title ? ` · ${elements.title}` : ""} - click to add a step</small>
                        <div className="chips">
                          {(elements.items || []).filter((x) => x.visible !== false).map((x) => <button key={x.id} className="chip el" onClick={() => addStep({ action: x.type === "select" ? "choose" : "type", target: "#" + x.id, value: "" })} title={`${x.type}${x.readonly ? " · read-only" : ""}`}>#{x.id}{x.label ? ` · ${x.label}` : ""}</button>)}
                          {(elements.buttons || []).map((x, i) => <button key={"b" + i} className="chip el btn" onClick={() => addStep({ action: "click", target: x.text || "#" + x.id, value: "" })}>{x.text || "#" + x.id}</button>)}
                          {(elements.pages || []).map((x) => <button key={"p" + x.ref} className="chip el page" onClick={() => addStep({ action: "open", target: x.ref, value: "" })}>open {x.ref}</button>)}
                        </div>
                      </div>)}
                  </div>)}
              </div>
              <div className="steps-head"><b>Steps</b><small>Run in order for each user; the test stops at the first step or check that fails. Use {"{{username}}"}, {"{{role}}"}, {"{{today}}"} in any value.</small></div>
              <StepsEditor steps={b.steps} onChange={(steps) => setB((s) => ({ ...s, steps }))} functions={functions} />
            </>
          ) : (
            <div className="steps">
              {check?.note && <p className="note top">{check.note}</p>}
              {check?.fields.map((f) => (
                <Field key={f.k} label={f.label}>
                  {f.options
                    ? <select value={b.params[f.k] || f.options[0]} onChange={(e) => setB({ ...b, params: { ...b.params, [f.k]: e.target.value } })}>{f.options.map((o) => <option key={o}>{o}</option>)}</select>
                    : <input type="text" placeholder={f.ph} value={b.params[f.k] || ""} onChange={(e) => setB({ ...b, params: { ...b.params, [f.k]: e.target.value } })} />}
                </Field>))}
              {check?.saves && <div className="banner warn">This check saves hours. Turn on <b>Allow tests that click Save</b> in Run settings{settings.allowSave ? " (on)" : ""}.</div>}
            </div>
          )}
        </div>
        <div className="sheet-foot">
          <button className="ghost-btn" onClick={onClose}>Cancel</button>
          <button className="ghost-btn" disabled={!valid || busy} onClick={() => submit(false)}>Save</button>
          <button className="run-btn inline" disabled={!valid || busy || !canRun} onClick={() => submit(true)} title={canRun ? "" : "Set the Base URL and test users first"}>
            <Svg name="play" size={13} /> Save &amp; run with video
          </button>
        </div>
      </div>
    </div>
  );
}

function describeStep(s) {
  const a = ACTIONS.find((x) => x.k === s.action)?.label || s.action;
  if (s.action === "assert") {
    const subj = SUBJECTS.find(([k]) => k === s.subject)?.[1] || s.subject;
    const op = STATE_SUBJ.has(s.subject) ? "" : OPS.find(([k]) => k === s.op)?.[1] || s.op || "";
    return `Check: ${subj}${s.target ? ` "${s.target}"` : ""} ${op} ${s.value ? `"${s.value}"` : ""}`.trim();
  }
  if (s.action === "call") return `Use function "${s.target}"${s.value ? ` with ${s.value}` : ""}`;
  return `${a}${s.target ? ` "${s.target}"` : ""}${s.value ? ` → ${s.value}` : ""}`;
}

function FunctionForm({ initial, functions, onClose, onSave, onDelete }) {
  const [f, setF] = useState({ ...initial, paramText: (initial.params || []).map((p) => (p.default ? `${p.name}=${p.default}` : p.name)).join(", ") });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const params = f.paramText.split(",").map((s) => s.trim()).filter(Boolean).map((s) => { const [n, ...d] = s.split("="); return { name: n.trim(), default: d.join("=").trim() }; });
  async function submit() {
    setBusy(true); setErr("");
    try { await onSave({ ...f, params }); } catch (e) { setErr(e.message); setBusy(false); }
  }
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head"><h3>{f.id ? "Edit function" : "New reusable function"}</h3><button className="x flat" onClick={onClose} aria-label="Close"><Svg name="x" /></button></div>
        <div className="sheet-body">
          <div className="two-col">
            <Field label="Name"><input type="text" autoFocus placeholder="e.g. Enter hours" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="Parameters (optional)" hint="Use them in steps as {{hours}}"><input type="text" placeholder="hours=8, day=Mon" value={f.paramText} onChange={(e) => setF({ ...f, paramText: e.target.value })} /></Field>
          </div>
          <Field label="Description (optional)"><input type="text" placeholder="What does it do?" value={f.description || ""} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <div className="steps-head"><b>Steps</b><small>Any test can run these with the <b>Use function</b> step.</small></div>
          <StepsEditor steps={f.steps} onChange={(steps) => setF((s) => ({ ...s, steps }))} functions={functions} exclude={initial.name} />
          {err && <div className="banner err">{err}</div>}
        </div>
        <div className="sheet-foot">
          {f.id && (confirm ? <button className="ghost-btn danger" onClick={() => onDelete(f)}>Delete function?</button>
            : <button className="ghost-btn" onClick={() => setConfirm(true)}><Svg name="trash" size={13} /> Delete</button>)}
          <span className="spacer" />
          <button className="ghost-btn" onClick={onClose}>Cancel</button>
          <button className="run-btn inline" disabled={!f.name.trim() || !f.steps.length || busy} onClick={submit}>Save function</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ application manager */
function Applications({ apps, activeId, running, notify, onReload, onUse, onManage }) {
  const [form, setForm] = useState(null);
  const [conn, setConn] = useState({});                // app id -> last Test Connection result
  const [confirm, setConfirm] = useState(null);

  async function test(a) {
    setConn((c) => ({ ...c, [a.id]: { loading: true } }));
    try { const r = await api.testConnection(a.base_url); setConn((c) => ({ ...c, [a.id]: r })); }
    catch (e) { setConn((c) => ({ ...c, [a.id]: { ok: false, error: e.message } })); }
  }
  async function remove(a) {
    try { await api.deleteApp(a.id); setConfirm(null); notify(`${a.name} deleted`); onReload(); }
    catch (e) { setConfirm(null); notify(e.message, "err"); }
  }
  async function save(f) {
    const saved = await api.saveApp(f.id, appBody(f));
    setForm(null); onReload();
    notify(`${saved.name} added - now add its test users`); onManage(saved.id);
  }
  return (
    <>
      <section className="hero slim">
        <div><h1>Applications</h1><p>Register every Oracle APEX application you test - its URL, how to sign in, the test users per role, suites and reusable functions.</p></div>
        <button className="run-btn inline" onClick={() => setForm({ ...BLANK_APP })}><Svg name="plus" size={14} /> Add application</button>
      </section>
      {!apps ? <p className="note">Loading…</p> : (
        <div className="apps-grid">
          {apps.map((a) => {
            const c = conn[a.id], active = a.id === activeId, lr = a.last_run;
            return (
              <article key={a.id} className={"card app-card" + (active ? " active" : "")}>
                <div className="app-top">
                  <h3>{a.name}</h3>
                  <span className={"env-pill " + a.environment}>{ENV_LABEL[a.environment] || a.environment}</span>
                  {active && <span className="badge finished">In use</span>}
                </div>
                <div className="app-link">{a.base_url ? <a href={a.base_url} target="_blank" rel="noreferrer">{a.base_url}</a> : <span className="warn-text">No Base URL yet - click Edit</span>}</div>
                <div className="app-meta"><span className={"auth-pill " + a.auth_type}><Svg name={a.auth_type === "apex_login" ? "key" : "globe"} size={11} /> {AUTH_LABEL[a.auth_type] || a.auth_type}</span>
                  {a.home_page && <span className="muted small">home: {a.home_page}</span>}</div>
                {a.description && <p className="app-desc">{a.description}</p>}
                {a.auth_type === "apex_login" && Number(a.active_users) === 0 && <div className="banner warn slim">No test users yet - add at least one to run tests.</div>}
                {a.auth_type === "chrome_session" && <div className="banner warn slim">Uses your logged-in Chrome. Switch to <b>Automatic login</b> to test as several users.</div>}
                <div className="app-stats five">
                  <div><b>{a.active_users ?? 0}</b><small>users</small></div>
                  <div><b>{a.tests}</b><small>tests</small></div>
                  <div><b>{a.suites ?? 0}</b><small>suites</small></div>
                  <div><b>{a.runs}</b><small>runs</small></div>
                  <div><b>{lr ? `${lr.total ? Math.round((lr.pass / lr.total) * 100) : 0}%` : "-"}</b><small>pass rate</small></div>
                </div>
                {c && (
                  <div className={"conn " + (c.loading ? "" : c.ok ? "ok" : "bad")}>
                    {c.loading ? "Checking…" : c.ok ? `✓ ${c.note} HTTP ${c.status} · ${c.ms} ms` : `✕ Could not connect: ${c.error || c.note}`}
                  </div>
                )}
                <div className="card-actions">
                  <button className="mini primary" onClick={() => onManage(a.id)}><Svg name="users" size={12} /> Manage</button>
                  <button className="mini" disabled={active || running} onClick={() => onUse(a.id)}><Svg name="play" size={11} /> {active ? "Selected" : "Use in Studio"}</button>
                  <button className="mini" disabled={!a.base_url || c?.loading} onClick={() => test(a)}><Svg name="plug" size={12} /> Test connection</button>
                  {confirm === a.id
                    ? <button className="mini danger" onClick={() => remove(a)} onBlur={() => setConfirm(null)} autoFocus>Delete app + its tests and users?</button>
                    : <button className="mini icon" onClick={() => setConfirm(a.id)} title="Delete" aria-label="Delete application"><Svg name="trash" size={13} /></button>}
                </div>
              </article>
            );
          })}
        </div>
      )}
      {form && <AppForm initial={form} onClose={() => setForm(null)} onSave={save} />}
    </>
  );
}

const appBody = (f) => ({ name: f.name, base_url: f.base_url, environment: f.environment, auth_type: f.auth_type, description: f.description,
  home_page: f.home_page || "", login_config: f.login_config || {} });

function AppDetail({ app, config, running, notify, onBack, onReloadApps, isActive, onUse, onOpenSuite, onChanged }) {
  const [form, setForm] = useState(null);
  const [users, setUsers] = useState(null);
  const [suites, setSuites] = useState([]);
  const [userForm, setUserForm] = useState(null);
  const [tests, setTests] = useState({});            // user id -> test-login result
  const [confirm, setConfirm] = useState(null);
  const load = useCallback(() => {
    api.listUsers(app.id).then(setUsers).catch((e) => { setUsers([]); notify(e.message, "err"); });
    api.listSuites(app.id).then(setSuites).catch(() => {});
  }, [app.id, notify]);
  useEffect(() => { load(); }, [load]);
  const lc = app.login_config || {};
  const custom = LOGIN_FIELDS.filter(([k]) => lc[k]);
  const roles = [...new Set((users || []).map((u) => u.role).filter(Boolean))].sort();

  async function saveApp(f) {
    await api.saveApp(f.id, appBody(f));
    setForm(null); onReloadApps(); notify("Application saved");
  }
  async function saveUser(u) {
    const body = { username: u.username.trim(), display_name: u.display_name, role: u.role.trim(), enabled: u.enabled, notes: u.notes,
      credential: u.mode === "env" ? { mode: "env", name: u.env_name.trim() } : u.password ? { mode: "vault", password: u.password } : { mode: u.id ? "keep" : "vault", password: "" } };
    await api.saveUser(app.id, u.id, body);
    setUserForm(null); load(); onReloadApps(); onChanged(); notify(u.id ? "Test user saved" : `${body.username} added`);
  }
  async function toggleUser(u) {
    try { await api.saveUser(app.id, u.id, { username: u.username, display_name: u.display_name, role: u.role, notes: u.notes, enabled: !u.enabled, credential: { mode: "keep" } }); load(); onChanged(); onReloadApps(); }
    catch (e) { notify(e.message, "err"); }
  }
  async function removeUser(u) {
    try { await api.deleteUser(u.id); setConfirm(null); load(); onChanged(); onReloadApps(); notify(`${u.username} removed (and its saved password)`); }
    catch (e) { setConfirm(null); notify(e.message, "err"); }
  }
  async function tryLogin(u) {
    setTests((t) => ({ ...t, [u.id]: { loading: true } }));
    try { const r = await api.testLogin(u.id, { headless: true }); setTests((t) => ({ ...t, [u.id]: r })); load(); }
    catch (e) { setTests((t) => ({ ...t, [u.id]: { ok: false, detail: e.message } })); load(); }
  }
  async function removeSuite(s) {
    try { await api.deleteSuite(s.id); setSuites((l) => l.filter((x) => x.id !== s.id)); onChanged(); notify("Suite deleted"); } catch (e) { notify(e.message, "err"); }
  }

  return (
    <>
      <section className="hero slim">
        <div>
          <button className="text-btn back" onClick={onBack}><Svg name="back" size={14} /> All applications</button>
          <h1>{app.name}</h1>
          <p className="now-testing"><span className={"env-pill " + app.environment}>{ENV_LABEL[app.environment]}</span>
            <span className={"auth-pill " + app.auth_type}>{AUTH_LABEL[app.auth_type]}</span>
            <a href={app.base_url} target="_blank" rel="noreferrer">{app.base_url}</a></p>
        </div>
        <div className="hero-actions">
          <button className="ghost-btn" onClick={() => setForm({ ...app })}><Svg name="edit" size={14} /> Edit settings</button>
          {!isActive && <button className="run-btn inline" disabled={running} onClick={onUse}>Use in Studio</button>}
        </div>
      </section>

      <div className="grid detail">
        <div className="side">
          <section className="card">
            <div className="card-head"><h2><Svg name="key" size={15} /> Sign-in</h2><button className="text-btn" onClick={() => setForm({ ...app })}>Edit</button></div>
            <dl className="kvs">
              <dt>Method</dt><dd>{AUTH_LABEL[app.auth_type]}</dd>
              <dt>Home page</dt><dd>{app.home_page || <span className="muted">app default</span>}</dd>
              {app.auth_type === "apex_login" && <>
                <dt>Login form</dt><dd>{custom.length ? custom.map(([k, l]) => <div key={k}><small className="muted">{l}:</small> <code>{lc[k]}</code></div>) : <span className="muted">detected automatically (APEX login page, P9999_USERNAME / P9999_PASSWORD, two-step forms)</span>}</dd>
                <dt>Each user</dt><dd className="muted">new private browser → sign in → verify (APEX session, APP_USER) → tests → sign out → check the old session is dead → close</dd>
              </>}
            </dl>
            {app.auth_type !== "apex_login" && <div className="banner warn">Switch the method to <b>Automatic login</b> (Edit) to run tests as the users below.</div>}
          </section>
          <section className="card">
            <div className="card-head"><h2><Svg name="lock" size={15} /> Password storage</h2></div>
            <p className="note top">Passwords are never stored in plain text and never sent back to the browser. Choose per user:</p>
            <ul className="bullets">
              <li><b>Encrypted secret store</b> - typed once here, encrypted (Fernet/AES) with a key kept outside the database ({config.secret_key === "env" ? "ATS_SECRET_KEY in backend/.env" : "backend/.ats_secret_key"}).</li>
              <li><b>Environment variable</b> - the password lives only in <code>backend/.env</code> or your CI secret store, e.g. <code>ATS_PW_MANAGER=…</code>.</li>
            </ul>
          </section>
        </div>

        <div className="main-col">
          <section className="card">
            <div className="card-head"><h2><Svg name="users" size={15} /> Test users</h2>
              <button className="run-btn inline" onClick={() => setUserForm({ id: null, username: "", display_name: "", role: "", enabled: true, notes: "", mode: "vault", password: "", env_name: "" })}><Svg name="plus" size={13} /> Add test user</button></div>
            {!users ? <p className="note">Loading…</p> : users.length === 0 ? (
              <div className="empty slim"><Svg name="users" size={26} /><p>Add one user per role you want to test, e.g. an employee, a manager and an administrator.</p></div>
            ) : (
              <div className="user-table">
                {users.map((u) => {
                  const t = tests[u.id];
                  return (
                    <div key={u.id} className={"user-row" + (u.enabled ? "" : " off")}>
                      <span className="avatar">{initials(u.display_name || u.username)}</span>
                      <div className="ur-main"><b>{u.username}</b><small>{[u.display_name !== u.username ? u.display_name : "", u.notes].filter(Boolean).join(" · ")}</small></div>
                      <span className="role-chip">{u.role || "no role"}</span>
                      <span className={"cred " + (u.credential?.ok ? "ok" : "bad")} title={u.credential?.note}>
                        <Svg name={u.credential?.kind === "env" ? "key" : "lock"} size={12} />{u.credential?.kind === "env" ? u.credential.name : u.credential?.ok ? "encrypted" : "no password"}</span>
                      <span className={"last " + (u.last_login_status === "OK" ? "ok" : u.last_login_status === "FAIL" ? "bad" : "")} title={u.last_login_detail || ""}>
                        {u.last_login_status ? `${u.last_login_status === "OK" ? "✓ signed in" : "✕ login failed"} · ${fmtDate(u.last_login_at)}` : "never signed in"}</span>
                      <div className="ur-act">
                        <button className="mini" disabled={app.auth_type !== "apex_login" || t?.loading || running || !u.credential?.ok} onClick={() => tryLogin(u)}><Svg name="key" size={11} /> {t?.loading ? "Signing in…" : "Test login"}</button>
                        <label className="switch" title={u.enabled ? "Active" : "Disabled"}><input type="checkbox" checked={u.enabled} onChange={() => toggleUser(u)} /><i /></label>
                        <button className="mini icon" onClick={() => setUserForm({ ...u, mode: u.credential?.kind === "env" ? "env" : "vault", password: "", env_name: u.credential?.name || "" })} aria-label="Edit user"><Svg name="edit" size={13} /></button>
                        {confirm === u.id ? <button className="mini danger" onClick={() => removeUser(u)} onBlur={() => setConfirm(null)} autoFocus>Delete?</button>
                          : <button className="mini icon" onClick={() => setConfirm(u.id)} aria-label="Delete user"><Svg name="trash" size={13} /></button>}
                      </div>
                      {t && !t.loading && (
                        <div className={"login-test " + (t.ok ? "ok" : "bad")}>
                          {t.shot && <img src={t.shot} alt="After sign-in" />}
                          <div><b>{t.ok ? "Login works" : "Login failed"}</b><p>{t.detail}</p>{t.logout && <p className="muted">{t.logout}</p>}
                            {t.findings?.map((f, i) => <p key={i}><span className={"sev " + f.severity}>{f.severity}</span> {f.title}</p>)}</div>
                          <button className="x flat" onClick={() => setTests((s) => ({ ...s, [u.id]: null }))} aria-label="Close"><Svg name="x" size={13} /></button>
                        </div>)}
                    </div>);
                })}
              </div>
            )}
          </section>

          <section className="card">
            <div className="card-head"><h2><Svg name="layers" size={15} /> Test suites</h2><small className="muted">Create them in Studio: select tests and users, then "Save selection"</small></div>
            {suites.length === 0 ? <p className="note">No suites yet. A suite is a named set of tests (and optionally users) - e.g. Smoke, Security, Regression.</p> : (
              <div className="table">
                {suites.map((s) => (
                  <div className="row suite-row" key={s.id}>
                    <div className="r-main"><b>{s.name}</b><small>{s.description || "-"}</small></div>
                    <span className="muted small">{s.case_ids?.length ? plural(s.case_ids.length, "test") : "all tests"} · {s.user_ids?.length ? plural(s.user_ids.length, "user") : "all users"}</span>
                    <div className="r-act">
                      <button className="mini primary" disabled={!isActive || running} title={isActive ? "" : "Use this application in Studio first"} onClick={() => onOpenSuite(s)}><Svg name="play" size={11} /> Open in Studio</button>
                      <button className="mini icon" onClick={() => removeSuite(s)} aria-label="Delete suite"><Svg name="trash" size={13} /></button>
                    </div>
                  </div>))}
              </div>)}
          </section>
        </div>
      </div>

      {form && <AppForm initial={form} onClose={() => setForm(null)} onSave={saveApp} />}
      {userForm && <UserForm initial={userForm} roles={roles} onClose={() => setUserForm(null)} onSave={saveUser} />}
    </>
  );
}

function UserForm({ initial, roles, onClose, onSave }) {
  const [u, setU] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const hadVault = initial.id && initial.credential?.kind === "vault" && initial.credential?.ok;
  const valid = u.username.trim() && (u.mode === "env" ? /^[A-Za-z_][A-Za-z0-9_]*$/.test(u.env_name.trim()) : u.password || hadVault);
  async function submit() {
    setBusy(true); setErr("");
    try { await onSave(u); } catch (e) { setErr(e.message); setBusy(false); }
  }
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  const suggested = "ATS_PW_" + (u.username || "USER").toUpperCase().replace(/[^A-Z0-9]+/g, "_");
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet narrow" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head"><h3>{u.id ? "Edit test user" : "Add test user"}</h3><button className="x flat" onClick={onClose} aria-label="Close"><Svg name="x" /></button></div>
        <div className="sheet-body">
          <div className="two-col">
            <Field label="Username (as typed on the login page)"><input type="text" autoFocus autoComplete="off" value={u.username} onChange={(e) => setU({ ...u, username: e.target.value })} placeholder="e.g. TEST_MANAGER" /></Field>
            <Field label="Role"><input type="text" list="role-list" value={u.role} onChange={(e) => setU({ ...u, role: e.target.value })} placeholder="e.g. MANAGER" />
              <datalist id="role-list">{roles.map((r) => <option key={r} value={r} />)}</datalist></Field>
          </div>
          <Field label="Display name (optional)"><input type="text" value={u.display_name} onChange={(e) => setU({ ...u, display_name: e.target.value })} placeholder="e.g. Manager - Finance" /></Field>
          <div className="field"><label>Password</label>
            <div className="seg-tabs small">
              <button className={u.mode === "vault" ? "on" : ""} onClick={() => setU({ ...u, mode: "vault" })}><Svg name="lock" size={12} /> Encrypted secret store</button>
              <button className={u.mode === "env" ? "on" : ""} onClick={() => setU({ ...u, mode: "env", env_name: u.env_name || suggested })}><Svg name="key" size={12} /> Environment variable</button>
            </div>
            {u.mode === "vault" ? (
              <>
                <input type="password" autoComplete="new-password" value={u.password} onChange={(e) => setU({ ...u, password: e.target.value })}
                       placeholder={hadVault ? "•••••••• saved - type to replace" : "Password"} />
                <small className="hint">Encrypted before it is stored. It is never shown again or sent back to the browser.</small>
              </>
            ) : (
              <>
                <input type="text" value={u.env_name} onChange={(e) => setU({ ...u, env_name: e.target.value })} placeholder={suggested} />
                <small className="hint">Add <code>{(u.env_name || suggested)}=the-password</code> to <code>backend/.env</code> (git-ignored) and restart the server. Nothing about the password is stored in the database.</small>
              </>
            )}
          </div>
          <Field label="Notes (optional)"><input type="text" value={u.notes} onChange={(e) => setU({ ...u, notes: e.target.value })} placeholder="e.g. Has two projects assigned" /></Field>
          <label className="check"><input type="checkbox" checked={u.enabled} onChange={(e) => setU({ ...u, enabled: e.target.checked })} />Active (included in runs)</label>
          {err && <div className="banner err">{err}</div>}
        </div>
        <div className="sheet-foot">
          <button className="ghost-btn" onClick={onClose}>Cancel</button>
          <button className="run-btn inline" disabled={!valid || busy} onClick={submit}>{u.id ? "Save user" : "Add user"}</button>
        </div>
      </div>
    </div>
  );
}

function AppForm({ initial, onClose, onSave }) {
  const [f, setF] = useState({ ...BLANK_APP, ...initial, login_config: { ...(initial.login_config || {}) } });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [probe, setProbe] = useState(null);
  const [adv, setAdv] = useState(Object.keys(initial.login_config || {}).length > 0);
  const urlOk = /^https?:\/\/\S+$/.test(f.base_url.trim());
  const valid = f.name.trim() && urlOk;
  async function submit() {
    setBusy(true); setErr("");
    try { await onSave({ ...f, name: f.name.trim(), base_url: f.base_url.trim() }); }
    catch (e) { setErr(e.message); setBusy(false); }
  }
  async function check() {
    setProbe({ loading: true });
    try { setProbe(await api.testConnection(f.base_url.trim())); } catch (e) { setProbe({ ok: false, error: e.message }); }
  }
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  const setLc = (k, v) => setF((s) => ({ ...s, login_config: { ...s.login_config, [k]: v } }));
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head"><h3>{f.id ? "Edit application" : "Add application"}</h3>
          <button className="x flat" onClick={onClose} aria-label="Close"><Svg name="x" /></button></div>
        <div className="sheet-body">
          <div className="two-col">
            <Field label="Application name"><input type="text" autoFocus placeholder="e.g. Timesheet App" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="Environment">
              <select value={f.environment} onChange={(e) => setF({ ...f, environment: e.target.value })}>
                {Object.entries(ENV_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select></Field>
          </div>
          <Field label="Base URL" hint="Friendly URL (…/ords/r/workspace/app) or classic (…/ords/f?p=100). Pasting any page URL works - the session part is removed.">
            <input type="text" placeholder="https://oracleapex.com/ords/r/your_workspace/timesheet-app" value={f.base_url}
              onChange={(e) => { setF({ ...f, base_url: e.target.value }); setProbe(null); }} /></Field>
          <div className="probe">
            <button className="mini" disabled={!urlOk || probe?.loading} onClick={check}><Svg name="plug" size={12} /> Test connection</button>
            {probe && <span className={"conn inline " + (probe.loading ? "" : probe.ok ? "ok" : "bad")}>
              {probe.loading ? "Checking…" : probe.ok ? `✓ ${probe.note} HTTP ${probe.status} · ${probe.ms} ms` : `✕ ${probe.error || probe.note}`}</span>}
          </div>
          <div className="two-col">
            <Field label="Authentication">
              <select value={f.auth_type} onChange={(e) => setF({ ...f, auth_type: e.target.value })}>
                <option value="apex_login">Automatic login with test users (recommended)</option>
                <option value="none">No login (public application)</option>
                <option value="chrome_session">Logged-in Chrome on port 9222 (legacy)</option>
              </select></Field>
            <Field label="Home page (alias or number)"><input type="text" placeholder="e.g. timesheet or 1" value={f.home_page || ""} onChange={(e) => setF({ ...f, home_page: e.target.value })} /></Field>
          </div>
          {f.auth_type === "apex_login" && (
            <div className="adv">
              <button className="link-btn slim" onClick={() => setAdv((v) => !v)}>{adv ? "Hide" : "Show"} login form settings (only for non-standard login pages)</button>
              {adv && <div className="settings grid2">
                {LOGIN_FIELDS.map(([k, label, ph]) => (
                  <Field key={k} label={label}><input type="text" placeholder={ph} value={f.login_config[k] || ""} onChange={(e) => setLc(k, e.target.value)} /></Field>))}
              </div>}
            </div>
          )}
          <Field label="Description (optional)"><input type="text" placeholder="What is this application?" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          {err && <div className="banner err">{err}</div>}
        </div>
        <div className="sheet-foot">
          <button className="ghost-btn" onClick={onClose}>Cancel</button>
          <button className="run-btn inline" disabled={!valid || busy} onClick={submit}>{f.id ? "Save changes" : "Add application"}</button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ dashboard */
function Dashboard({ appId, apps, onOpen, onChanged, notify, onMedia, groupBy, setGroupBy }) {
  const [runs, setRuns] = useState(null);
  const [an, setAn] = useState(null);
  const [dash, setDash] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [all, setAll] = useState(false);
  const appName = apps?.find((a) => a.id === appId)?.name;
  const scopeId = all ? null : appId;
  const group = !all && groupBy === "application" ? "user" : groupBy;
  const load = useCallback(() => {
    api.listRuns(scopeId).then(setRuns).catch((e) => { setRuns([]); notify(e.message, "err"); });
    api.getAnalytics(scopeId).then(setAn).catch((e) => { setAn({ trend: [], problem_tests: [] }); notify(e.message, "err"); });
  }, [notify, scopeId]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.getDashboard(scopeId, group).then(setDash).catch((e) => notify(e.message, "err")); }, [scopeId, group, notify]);
  async function del(id) {
    try { await api.deleteRun(id); setConfirm(null); notify("Run deleted"); load(); onChanged(); }
    catch (e) { setConfirm(null); notify(e.message, "err"); }
  }
  const groupOpts = [["application", "Application"], ["user", "User"], ["role", "Role"], ["case", "Test case"]].filter(([k]) => all || k !== "application");
  return (
    <>
      <section className="hero slim"><div><h1>Results dashboard</h1><p>The newest {dash?.runs || 0} runs grouped by application, user, role or test case - with login failures, security findings and regressions.</p></div>
        <label className="check scope"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} />All applications{!all && appName ? ` (now: ${appName})` : ""}</label></section>

      <section className="card">
        <div className="card-head"><h2>Grouped results</h2>
          <div className="seg-tabs">{groupOpts.map(([k, l]) => <button key={k} className={group === k ? "on" : ""} onClick={() => setGroupBy(k)}>{l}</button>)}</div></div>
        {!dash ? <p className="note">Loading…</p> : dash.rows.length === 0 ? <p className="note">No runs yet. Start one from the Studio tab.</p> : (
          <div className="dash-table">
            <div className="dt-head"><span>{groupOpts.find(([k]) => k === group)?.[1]}</span><span>Results</span><span>Pass rate</span><span>Login fails</span><span>Findings</span><span>Regressions</span><span>Last</span></div>
            {dash.rows.map((r) => (
              <div className="dt-row" key={r.key}>
                <span className="dt-name">{group === "user" && <span className="avatar sm">{initials(r.label)}</span>}<b>{r.label}</b>{r.sub && <small>{r.sub}</small>}</span>
                <span className="dt-bar"><span className="mini-bar"><i className="p" style={{ width: `${(r.pass / (r.total || 1)) * 100}%` }} /><i className="f" style={{ width: `${(r.fail / (r.total || 1)) * 100}%` }} /><i className="s" style={{ width: `${(r.skip / (r.total || 1)) * 100}%` }} /></span>
                  <small><i className="g">{r.pass}</i> · <i className="r">{r.fail}</i> · <i className="a">{r.skip}</i></small></span>
                <span><b className={r.rate == null ? "muted" : r.rate >= 90 ? "g" : r.rate >= 60 ? "a" : "r"}>{r.rate == null ? "-" : `${r.rate}%`}</b></span>
                <span className={r.login_fail ? "r" : "muted"}>{r.login_fail || "-"}</span>
                <span className={r.findings ? "r" : "muted"}>{r.findings ? <><Svg name="shield" size={12} /> {r.findings}</> : "-"}</span>
                <span className={r.regressions ? "r" : "muted"}>{r.regressions || "-"}{r.fixed ? <small className="g"> +{r.fixed} fixed</small> : null}</span>
                <span>{r.last ? <span className={"pill-s " + r.last.toLowerCase()}>{r.last}</span> : "-"}</span>
              </div>))}
          </div>)}
      </section>

      {dash && (
        <div className="grid three">
          <section className="card">
            <div className="card-head"><h2><Svg name="shield" size={15} /> Security findings</h2><small className="muted">{dash.findings.length}</small></div>
            {dash.findings.length === 0 ? <p className="note">No findings in these runs.</p> : (
              <ul className="ev-list">{dash.findings.map((f, i) => (
                <li key={i} onClick={() => onMedia({ title: f.title, video: f.video, shot: f.shot, lines: [["Severity", f.severity], ["User", `${f.username || "-"}${f.role ? ` · ${f.role}` : ""}`], ["Test", `${f.test_case_id} ${f.name || ""}`], ["Details", f.detail || "-"], ["Seen", `${plural(f.runs, "run")} · last ${fmtDate(f.started_at)}`]] })}>
                  <span className={"sev " + f.severity}>{f.severity}</span><div><b>{f.title}</b><small>{f.username}{f.role ? ` · ${f.role}` : ""} · {f.test_case_id}{all ? ` · ${f.application}` : ""}{f.runs > 1 ? ` · ${f.runs} runs` : ""}</small></div></li>))}
              </ul>)}
          </section>
          <section className="card">
            <div className="card-head"><h2><Svg name="key" size={15} /> Login failures</h2><small className="muted">{dash.login_failures.length}</small></div>
            {dash.login_failures.length === 0 ? <p className="note">Every user signed in.</p> : (
              <ul className="ev-list">{dash.login_failures.map((l, i) => (
                <li key={i} onClick={() => onMedia({ title: `Login failed · ${l.username}`, video: l.video, shot: l.shot, lines: [["Details", l.detail], ["Run", `${l.run_id} · ${fmtDate(l.started_at)}`]] })}>
                  <span className="sev high">login</span><div><b>{l.username}{l.role ? ` · ${l.role}` : ""}</b><small>{l.detail} · {fmtDate(l.started_at)}</small></div></li>))}
              </ul>)}
          </section>
          <section className="card">
            <div className="card-head"><h2>Regressions</h2><small className="muted">passed before, failing now</small></div>
            {dash.regressions.length === 0 ? <p className="note">No regressions.</p> : (
              <ul className="ev-list">{dash.regressions.map((r, i) => (
                <li key={i} onClick={() => onMedia({ title: `Regression · ${r.test_case_id}`, video: r.video, shot: r.shot, lines: [["Test", r.name], ["User", `${r.username || "-"}${r.role ? ` · ${r.role}` : ""}`], ["Now", r.detail], ["Run", `${r.run_id} · ${fmtDate(r.started_at)}`]] })}>
                  <span className="sev medium">FAIL</span><div><b>{r.test_case_id} · {r.name}</b><small>{r.username}{r.role ? ` · ${r.role}` : ""} · {fmtDate(r.started_at)}</small></div></li>))}
              </ul>)}
          </section>
        </div>
      )}

      <div className="grid hist">
        <section className="card">
          <div className="card-head"><h2>Pass-rate trend</h2><small className="muted">last {an?.trend?.length || 0} runs · click a bar to open it</small></div>
          <Trend data={an?.trend || []} onOpen={onOpen} />
        </section>
        <section className="card">
          <div className="card-head"><h2>Most failing tests</h2></div>
          {(an?.problem_tests || []).length === 0 ? <p className="note">No failures recorded.</p> : (
            <ul className="probs">{an.problem_tests.map((p) => (
              <li key={p.test_case_id}><code>{p.test_case_id}</code><span>{p.name}</span><b>{p.fails}/{p.runs}</b>
                <div className="pbar"><i style={{ width: `${(p.fails / p.runs) * 100}%` }} /></div></li>))}
            </ul>)}
        </section>
      </div>
      <section className="card">
        <div className="card-head"><h2>Run history</h2><button className="text-btn" onClick={load}>Refresh</button></div>
        {!runs ? <p className="note">Loading…</p> : runs.length === 0 ? <p className="note">No runs yet. Start one from the Studio tab.</p> : (
          <div className="table">
            {runs.map((r) => (
              <div className="row" key={r.id}>
                <div className="r-main"><b>{fmtDate(r.started_at)}</b><small>{r.application_name ? r.application_name + " · " : ""}{r.suite_name || r.filename}{r.users ? ` · ${plural(r.users, "user")}` : ""}{r.demo ? " · demo" : ""}</small></div>
                <span className="mini-bar"><i className="p" style={{ width: `${(r.pass / (r.total || 1)) * 100}%` }} /><i className="f" style={{ width: `${(r.fail / (r.total || 1)) * 100}%` }} /><i className="s" style={{ width: `${(r.skip / (r.total || 1)) * 100}%` }} /></span>
                <div className="r-num"><b className="g">{r.pass}</b><b className="r">{r.fail}</b><b className="a">{r.skip}</b><small>{pctOf(r)}%</small>
                  {r.login_fail > 0 && <span className="tag bad" title="Login failures">{r.login_fail} login</span>}
                  {r.findings > 0 && <span className="tag bad" title="Security findings"><Svg name="shield" size={10} /> {r.findings}</span>}</div>
                <span className={"badge " + r.status}>{r.status}</span>
                <div className="r-act">
                  <button className="mini" onClick={() => onOpen(r.id)}>Open</button>
                  <a className="mini" href={`/api/runs/${r.id}/report`} target="_blank" rel="noreferrer">Report</a>
                  <a className="mini" href={`/api/runs/${r.id}/csv`}>CSV</a>
                  {confirm === r.id
                    ? <button className="mini danger" onClick={() => del(r.id)} onBlur={() => setConfirm(null)} autoFocus>Confirm delete</button>
                    : <button className="mini icon" onClick={() => setConfirm(r.id)} title="Delete run" aria-label="Delete run"><Svg name="trash" size={13} /></button>}
                </div>
              </div>))}
          </div>)}
      </section>
    </>
  );
}

function Trend({ data, onOpen }) {
  if (!data.length) return <div className="empty"><p>Run your tests to see the trend.</p></div>;
  const W = 640, H = 220, Pd = 28, bw = Math.min(34, (W - 2 * Pd) / data.length - 8);
  const max = Math.max(...data.map((d) => d.total), 1);
  const x = (i) => Pd + (i + 0.5) * ((W - 2 * Pd) / data.length);
  const line = data.map((d, i) => `${x(i)},${H - Pd - (d.pass / (d.total || 1)) * (H - 2 * Pd)}`).join(" ");
  return (
    <svg className="trend" viewBox={`0 0 ${W} ${H}`}>
      {[0, 0.5, 1].map((g) => <line key={g} x1={Pd} x2={W - Pd} y1={H - Pd - g * (H - 2 * Pd)} y2={H - Pd - g * (H - 2 * Pd)} className="grid-l" />)}
      {data.map((d, i) => {
        const h = (n) => (n / max) * (H - 2 * Pd);
        let y = H - Pd;
        const bars = [["pass", d.pass], ["fail", d.fail], ["skip", d.skip]].map(([k, n]) => { y -= h(n); return <rect key={k} x={x(i) - bw / 2} y={y} width={bw} height={Math.max(h(n), 0)} rx="2" className={"b " + k} />; });
        return (
          <g key={d.id} className="bar-g" role="button" tabIndex={0} onClick={() => onOpen(d.id)} onKeyDown={(e) => e.key === "Enter" && onOpen(d.id)}>
            <title>{`${fmtDate(d.started_at)}: ${d.pass} pass, ${d.fail} fail, ${d.skip} skip`}</title>
            <rect x={x(i) - bw} y={Pd / 2} width={bw * 2} height={H - Pd} className="hit" />
            {bars}<text x={x(i)} y={H - 8} textAnchor="middle">{new Date(d.started_at).toLocaleDateString([], { day: "2-digit", month: "short" })}</text>
          </g>);
      })}
      <polyline points={line} className="rate-line" />
      {data.map((d, i) => <circle key={d.id} cx={x(i)} cy={H - Pd - (d.pass / (d.total || 1)) * (H - 2 * Pd)} r="3" className="rate-dot" />)}
    </svg>
  );
}
