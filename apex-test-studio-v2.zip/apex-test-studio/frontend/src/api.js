async function j(res) {
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body;
}
const get = (u) => fetch(u).then(j);
const send = (method, u, body) =>
  fetch(u, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) }).then(j);

export const getConfig = () => get("/api/config");
export const getSettings = () => get("/api/settings");
export const saveSettings = (s) => send("PUT", "/api/settings", s);

const scope = (appId) => (appId ? `?application_id=${appId}` : "");

/* applications */
export const listApps = () => get("/api/applications");
export const saveApp = (id, body) => (id ? send("PUT", `/api/applications/${id}`, body) : send("POST", "/api/applications", body));
export const deleteApp = (id) => send("DELETE", `/api/applications/${id}`);
export const testConnection = (base_url) => send("POST", "/api/applications/test", { base_url });
export const inspectPage = (appId, body) => send("POST", `/api/applications/${appId}/inspect`, body);

/* test users - the API only ever accepts a password, it never returns one */
export const listUsers = (appId) => get(`/api/applications/${appId}/users`);
export const saveUser = (appId, id, body) => (id ? send("PUT", `/api/users/${id}`, body) : send("POST", `/api/applications/${appId}/users`, body));
export const deleteUser = (id) => send("DELETE", `/api/users/${id}`);
export const testLogin = (id, body) => send("POST", `/api/users/${id}/test-login`, body || {});

/* suites and reusable functions */
export const listSuites = (appId) => get(`/api/applications/${appId}/suites`);
export const saveSuite = (appId, id, body) => (id ? send("PUT", `/api/suites/${id}`, body) : send("POST", `/api/applications/${appId}/suites`, body));
export const deleteSuite = (id) => send("DELETE", `/api/suites/${id}`);
export const listFunctions = (appId) => get(`/api/applications/${appId}/functions`);
export const saveFunction = (appId, id, body) => (id ? send("PUT", `/api/functions/${id}`, body) : send("POST", `/api/applications/${appId}/functions`, body));
export const deleteFunction = (id) => send("DELETE", `/api/functions/${id}`);

/* tests */
export const uploadExcel = (file, appId) =>
  fetch(`/api/upload?filename=${encodeURIComponent(file.name)}&application_id=${appId}`, { method: "POST", body: file }).then(j);
export const listUploads = (appId) => get(`/api/uploads${scope(appId)}`);
export const getUpload = (id) => get(`/api/uploads/${id}`);
export const listCustom = (appId) => get(`/api/custom${scope(appId)}`);
export const saveCustom = (id, body) => (id ? send("PUT", `/api/custom/${id}`, body) : send("POST", "/api/custom", body));
export const deleteCustom = (id) => send("DELETE", `/api/custom/${id}`);
export const aiGenerate = (body) => send("POST", "/api/ai/generate", body);

/* runs and dashboard */
export const startRun = (payload) => send("POST", "/api/runs", payload);
export const getRun = (id) => get(`/api/runs/${id}`);
export const listRuns = (appId) => get(`/api/runs${scope(appId)}`);
export const deleteRun = (id) => send("DELETE", `/api/runs/${id}`);
export const getAnalytics = (appId) => get(`/api/analytics${scope(appId)}`);
export const getDashboard = (appId, group) => get(`/api/dashboard?group=${group}${appId ? `&application_id=${appId}` : ""}`);
