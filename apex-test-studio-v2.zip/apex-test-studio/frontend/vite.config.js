import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// In dev, forward API + video requests to the Python backend (python server.py on :8000)
// Fixed file names in dist/ (assets/app.js, assets/app.css) so the committed build stays stable.
export default defineConfig({
  plugins: [react()],
  server: { proxy: { "/api": "http://localhost:8000", "/media": "http://localhost:8000" } },
  build: { rollupOptions: { output: { entryFileNames: "assets/app.js", chunkFileNames: "assets/[name].js", assetFileNames: "assets/app[extname]" } } },
});
